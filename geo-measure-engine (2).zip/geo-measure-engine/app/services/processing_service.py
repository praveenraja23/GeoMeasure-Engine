"""Orchestrates processing of one uploaded file (runs inside the Celery worker).

State machine:  QUEUED -> PROCESSING -> COMPLETED | PARTIALLY_COMPLETED | FAILED

Transaction strategy: one short transaction to mark PROCESSING, one transaction *per
feature batch* (features + measurements + job progress), one to finalise. A very large
file therefore never holds a single huge transaction, and a crash loses at most the
current batch. Re-running is safe because every write is an upsert on a deterministic key.
"""

from __future__ import annotations

import logging
import tempfile
import time
import uuid
from collections.abc import Callable
from contextlib import AbstractContextManager
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import redis.exceptions
from celery.exceptions import SoftTimeLimitExceeded
from sqlalchemy import Engine
from sqlalchemy.exc import DBAPIError, OperationalError
from sqlalchemy.orm import Session

from app.core import metrics
from app.core.config import Settings
from app.core.exceptions import (
    CorruptGeodataError,
    CRSTransformationError,
    GeoMeasureError,
    MissingCRSError,
    ProcessingError,
    RetryableProcessingError,
)
from app.core.logging import file_id_var, job_id_var
from app.core.telemetry import span
from app.db.locks import advisory_lock
from app.domain.enums import (
    TERMINAL_FILE_STATUSES,
    ErrorCode,
    FileStatus,
    FileType,
    JobStatus,
)
from app.geospatial.crs.resolver import CRSResolutionStrategy, MeasurementPlan, crs_code
from app.geospatial.pipeline import FeaturePipeline
from app.geospatial.readers.base import DatasetInfo
from app.geospatial.readers.factory import GeoFileReaderFactory
from app.repositories.feature_repository import FeatureRepository
from app.repositories.file_repository import FileRepository
from app.repositories.job_repository import JobRepository
from app.repositories.measurement_repository import MeasurementRepository
from app.services.storage import FileStorage
from app.utils.file_validation import ArchiveLimits, extract_shapefile

logger = logging.getLogger(__name__)

SessionScope = Callable[[], AbstractContextManager[Session]]


@dataclass(frozen=True, slots=True)
class ProcessingOutcome:
    file_id: uuid.UUID
    status: str
    feature_count: int = 0
    skipped: bool = False
    reason: str | None = None

    def as_dict(self) -> dict[str, object]:
        return {
            "file_id": str(self.file_id),
            "status": self.status,
            "feature_count": self.feature_count,
            "skipped": self.skipped,
            "reason": self.reason,
        }


def classify_exception(exc: BaseException) -> GeoMeasureError:
    """Map any exception to a domain error; only infrastructure faults are retryable."""
    if isinstance(exc, GeoMeasureError):
        return exc
    if isinstance(exc, SoftTimeLimitExceeded):
        return ProcessingError("Processing exceeded the configured time limit")
    if isinstance(exc, FileNotFoundError):
        return ProcessingError("The stored upload could not be found")
    if isinstance(exc, OperationalError) or (
        isinstance(exc, DBAPIError) and exc.connection_invalidated
    ):
        return RetryableProcessingError("Database temporarily unavailable")
    if isinstance(exc, redis.exceptions.RedisError | OSError | TimeoutError):
        return RetryableProcessingError("Storage or messaging backend temporarily unavailable")
    return ProcessingError("Unexpected processing error; see service logs")


class ProcessingService:
    def __init__(
        self,
        *,
        engine: Engine,
        session_scope: SessionScope,
        storage: FileStorage,
        readers: GeoFileReaderFactory,
        pipeline: FeaturePipeline,
        resolver: CRSResolutionStrategy,
        settings: Settings,
    ) -> None:
        self._engine = engine
        self._scope = session_scope
        self._storage = storage
        self._readers = readers
        self._pipeline = pipeline
        self._resolver = resolver
        self._settings = settings

    # --------------------------------------------------------------------- API
    def process(
        self, file_id: uuid.UUID, *, job_id: uuid.UUID | None, attempt: int, is_final_attempt: bool
    ) -> ProcessingOutcome:
        file_id_var.set(str(file_id))
        with advisory_lock(self._engine, file_id) as acquired:
            if not acquired:
                logger.info("processing_skipped_locked")
                return ProcessingOutcome(
                    file_id, "SKIPPED", skipped=True, reason="locked_by_other_worker"
                )
            return self._process_locked(file_id, job_id, attempt, is_final_attempt)

    # ---------------------------------------------------------------- internals
    def _process_locked(
        self, file_id: uuid.UUID, job_id: uuid.UUID | None, attempt: int, is_final: bool
    ) -> ProcessingOutcome:
        with self._scope() as s:
            record = FileRepository(s).get(file_id)
            if record is None:
                return ProcessingOutcome(file_id, "SKIPPED", skipped=True, reason="file_deleted")
            if record.status in TERMINAL_FILE_STATUSES:
                return ProcessingOutcome(
                    file_id, record.status.value, skipped=True, reason="already_finished"
                )
            jobs = JobRepository(s)
            if job_id is None:
                latest = jobs.latest_for_file(file_id)
                job_id = latest.id if latest else jobs.create(file_id).id
            now = datetime.now(UTC)
            FileRepository(s).update(
                file_id,
                status=FileStatus.PROCESSING,
                processing_started_at=now,
                processing_completed_at=None,
                error_code=None,
                error_message=None,
            )
            jobs.update(
                job_id,
                status=JobStatus.PROCESSING,
                attempt=attempt,
                started_at=now,
                completed_at=None,
                error_code=None,
                error_message=None,
            )
            file_type, storage_key = record.file_type, record.storage_path
        job_id_var.set(str(job_id))
        logger.info("processing_started", extra={"attempt": attempt, "file_type": file_type.value})

        started = time.perf_counter()
        try:
            feature_count = self._run(file_id, job_id, file_type, storage_key)
            outcome = self._finalise(file_id, job_id, started, feature_count)
        except BaseException as exc:
            if isinstance(exc, KeyboardInterrupt | SystemExit):
                raise
            return self._handle_failure(file_id, job_id, file_type, started, exc, attempt, is_final)
        metrics.PROCESSING_JOBS.labels(file_type.value, outcome.status).inc()
        if outcome.status == FileStatus.FAILED.value:
            metrics.PROCESSING_JOBS_FAILED.labels(
                file_type.value, outcome.reason or ErrorCode.PROCESSING_FAILED.value
            ).inc()
        metrics.PROCESSING_DURATION.labels(file_type.value).observe(time.perf_counter() - started)
        logger.info(
            "processing_finished",
            extra={
                "status": outcome.status,
                "feature_count": outcome.feature_count,
                "duration_ms": int((time.perf_counter() - started) * 1000),
            },
        )
        return outcome

    def _run(self, file_id: uuid.UUID, job_id: uuid.UUID, file_type: FileType, key: str) -> int:
        s = self._settings
        s.effective_temp_dir.mkdir(parents=True, exist_ok=True)
        limits = ArchiveLimits(
            s.max_zip_entries, s.max_extracted_size_bytes, s.max_compression_ratio
        )
        reader = self._readers.for_type(file_type)

        # Both context managers guarantee cleanup on success, failure and retry.
        with (
            self._storage.local_path(key) as stored,
            tempfile.TemporaryDirectory(dir=s.effective_temp_dir, prefix="geo-") as tmp,
        ):
            with span("file.extract"):
                dataset: Path = (
                    extract_shapefile(stored, Path(tmp), limits)
                    if file_type is FileType.SHAPEFILE
                    else stored
                )
            with span("file.inspect"):
                info = reader.inspect(dataset)
            if info.feature_count == 0:
                raise CorruptGeodataError("The dataset contains no features")

            plan, plan_error = self._resolve_plan(info)
            self._record_crs(file_id, job_id, info, plan)

            with span("file.process_batches"):
                for batch in reader.read_batches(dataset, s.feature_batch_size):
                    processed = self._pipeline.process_batch(
                        batch.frame, batch.start_index, info.crs, plan, plan_error
                    )
                    with span("db.persist_batch"), self._scope() as session:
                        FeatureRepository(session).upsert_batch(file_id, processed)
                        MeasurementRepository(session).upsert_batch(file_id, processed)
                        JobRepository(session).update(
                            job_id,
                            processed_features=min(
                                batch.start_index + len(processed), info.feature_count
                            ),
                        )
                    self._count_metrics(file_type, processed)
                    logger.info(
                        "batch_persisted",
                        extra={
                            "batch_start": batch.start_index,
                            "processed_features": batch.start_index + len(processed),
                        },
                    )
        return info.feature_count

    def _resolve_plan(
        self, info: DatasetInfo
    ) -> tuple[MeasurementPlan | None, GeoMeasureError | None]:
        with span("crs.resolve"):
            try:
                return self._resolver.resolve(info.crs, info.bounds), None
            except (MissingCRSError, CRSTransformationError) as exc:
                # Not fatal: features are still stored where possible and report the CRS error.
                return None, exc

    def _record_crs(
        self, file_id: uuid.UUID, job_id: uuid.UUID, info: DatasetInfo, plan: MeasurementPlan | None
    ) -> None:
        values: dict[str, object] = {
            "feature_count": 0,  # authoritative count is written at finalisation
            "source_crs": crs_code(info.crs) if info.crs else None,
            "source_crs_name": info.crs.name if info.crs else None,
        }
        if plan:
            values.update(
                measurement_crs=crs_code(plan.primary_crs),
                measurement_crs_name=plan.primary_crs.name,
                measurement_units=plan.units,
                crs_selection_reason=plan.reason,
            )
        with self._scope() as session:
            FileRepository(session).update(file_id, **values)
            JobRepository(session).update(
                job_id, total_features=info.feature_count, processed_features=0
            )

    @staticmethod
    def _count_metrics(file_type: FileType, processed: list) -> None:  # type: ignore[type-arg]
        for item in processed:
            m = item.measurement
            metrics.FEATURES_PROCESSED.labels(
                file_type.value, item.geometry_type, m.status.value
            ).inc()
            if m.error_code:
                metrics.MEASUREMENT_FAILURES.labels(item.geometry_type, m.error_code.value).inc()

    # ----------------------------------------------------------- finalisation
    def _finalise(
        self, file_id: uuid.UUID, job_id: uuid.UUID, started: float, expected: int
    ) -> ProcessingOutcome:
        duration_ms = int((time.perf_counter() - started) * 1000)
        with self._scope() as session:
            counts = MeasurementRepository(session).counts(file_id)
            if counts.total != expected:
                logger.warning("feature_count_mismatch", extra={"feature_count": counts.total})
            if counts.failed == 0 and counts.total > 0:
                status, error_code, message = FileStatus.COMPLETED, None, None
            elif counts.successful == 0:
                status = FileStatus.FAILED
                error_code = counts.top_error_code or ErrorCode.PROCESSING_FAILED.value
                message = "No feature could be measured successfully"
            else:
                status, error_code, message = FileStatus.PARTIALLY_COMPLETED, None, None
            self._write_terminal(
                session,
                file_id,
                job_id,
                status,
                counts.total,
                counts.successful,
                counts.failed,
                error_code,
                message,
                duration_ms,
            )
        return ProcessingOutcome(file_id, status.value, counts.total, reason=error_code)

    @staticmethod
    def _write_terminal(
        session: Session,
        file_id: uuid.UUID,
        job_id: uuid.UUID,
        status: FileStatus,
        total: int,
        ok: int,
        failed: int,
        error_code: str | None,
        message: str | None,
        duration_ms: int,
    ) -> None:
        now = datetime.now(UTC)
        FileRepository(session).update(
            file_id,
            status=status,
            feature_count=total,
            successful_feature_count=ok,
            failed_feature_count=failed,
            processing_completed_at=now,
            error_code=error_code,
            error_message=message,
        )
        JobRepository(session).update(
            job_id,
            status=JobStatus(status.value),
            completed_at=now,
            duration_ms=duration_ms,
            error_code=error_code,
            error_message=message,
        )

    def _handle_failure(
        self,
        file_id: uuid.UUID,
        job_id: uuid.UUID,
        file_type: FileType,
        started: float,
        exc: BaseException,
        attempt: int,
        is_final: bool,
    ) -> ProcessingOutcome:
        error = classify_exception(exc)
        if (
            isinstance(error, ProcessingError)
            and error.__class__ is ProcessingError
            and not isinstance(exc, GeoMeasureError)
        ):
            logger.error("processing_unexpected_error", exc_info=exc)
        else:
            logger.warning(
                "processing_error", extra={"error_code": error.code.value, "attempt": attempt}
            )

        if error.retryable and not is_final:
            try:
                with self._scope() as s:
                    FileRepository(s).update(
                        file_id, status=FileStatus.QUEUED, error_message=f"Retrying: {error.detail}"
                    )
                    JobRepository(s).update(
                        job_id, status=JobStatus.QUEUED, error_message=error.detail
                    )
            except Exception:
                logger.exception("retry_state_update_failed")
            raise error from exc

        if error.retryable:
            error = ProcessingError(f"{error.detail}; gave up after {attempt} attempt(s)")
        duration_ms = int((time.perf_counter() - started) * 1000)
        try:
            with self._scope() as session:
                counts = MeasurementRepository(session).counts(file_id)  # keep counters consistent
                self._write_terminal(
                    session,
                    file_id,
                    job_id,
                    FileStatus.FAILED,
                    counts.total,
                    counts.successful,
                    counts.failed,
                    error.code.value,
                    error.detail,
                    duration_ms,
                )
        except Exception:
            logger.exception("failure_state_update_failed")
        metrics.PROCESSING_JOBS.labels(file_type.value, FileStatus.FAILED.value).inc()
        metrics.PROCESSING_JOBS_FAILED.labels(file_type.value, error.code.value).inc()
        metrics.PROCESSING_DURATION.labels(file_type.value).observe(time.perf_counter() - started)
        return ProcessingOutcome(file_id, FileStatus.FAILED.value, reason=error.code.value)
