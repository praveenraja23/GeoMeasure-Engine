"""Composition root: the only place concrete implementations are wired together."""

from __future__ import annotations

from functools import lru_cache

from app.core.config import Settings, get_settings
from app.db.session import get_engine, session_scope
from app.geospatial.crs.resolver import MeasurementCRSResolver
from app.geospatial.crs.transformer import GeometryTransformer
from app.geospatial.geometry.normalizer import FeatureNormalizer
from app.geospatial.geometry.validator import GeometryValidator
from app.geospatial.measurements.engine import MeasurementEngine
from app.geospatial.pipeline import FeaturePipeline
from app.geospatial.readers.factory import GeoFileReaderFactory
from app.services.processing_service import ProcessingService
from app.services.storage import FileStorage, LocalFileStorage


@lru_cache
def get_storage() -> FileStorage:
    return LocalFileStorage(get_settings().file_storage_path)


def build_pipeline(settings: Settings) -> FeaturePipeline:
    return FeaturePipeline(
        FeatureNormalizer(settings.max_properties_bytes, settings.max_property_value_chars),
        GeometryValidator(),
        MeasurementEngine(),
        GeometryTransformer(),
        settings.max_vertices_per_feature,
    )


def build_processing_service(settings: Settings | None = None) -> ProcessingService:
    settings = settings or get_settings()
    return ProcessingService(
        engine=get_engine(),
        session_scope=session_scope,
        storage=get_storage(),
        readers=GeoFileReaderFactory(),
        pipeline=build_pipeline(settings),
        resolver=MeasurementCRSResolver(settings.utm_max_lon_span_deg),
        settings=settings,
    )
