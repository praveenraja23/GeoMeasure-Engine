"""Upload ingestion, retrieval and deletion of file records."""

from __future__ import annotations

import logging
import uuid
from collections.abc import Iterator
from typing import BinaryIO

from sqlalchemy import update
from sqlalchemy.orm import Session

from app.core import metrics
from app.core.config import Settings
from app.core.exceptions import (
    CorruptGeodataError,
    FileBusyError,
    FileRecordNotFoundError,
    GeoMeasureError,
    JobNotFoundError,
)
from app.core.security import sanitize_display_filename
from app.core.telemetry import span
from app.db.models import FileRecord, ProcessingJob
from app.domain.enums import FileStatus, FileType
from app.repositories.file_repository import FileRepository
from app.repositories.job_repository import JobRepository
from app.services.queue import JobQueue
from app.services.storage import FileStorage
from app.utils.file_validation import (
    ArchiveLimits,
    detect_file_type,
    inspect_shapefile_archive,
    validate_kml,
)

logger = logging.getLogger(__name__)
_CHUNK = 1024 * 1024
_SUFFIX = {FileType.KML: ".kml", FileType.SHAPEFILE: ".zip"}


def _chunks(stream: BinaryIO) -> Iterator[bytes]:
    while chunk := stream.read(_CHUNK):
        yield chunk


class FileService:
    def __init__(
        self, session: Session, storage: FileStorage, queue: JobQueue, settings: Settings
    ) -> None:
        self._session = session
        self._files = FileRepository(session)
        self._jobs = JobRepository(session)
        self._storage = storage
        self._queue = queue
        self._settings = settings

    # ------------------------------------------------------------------ upload
    def ingest(
        self,
        *,
        stream: BinaryIO,
        filename: str | None,
        content_type: str | None,
        request_id: str | None,
    ) -> tuple[FileRecord, ProcessingJob]:
        """size -> extension/content-type -> stream to disk + SHA-256 -> structure -> persist -> enqueue."""
        original = sanitize_display_filename(filename)
        fmt_label = "unknown"
        try:
            file_type = detect_file_type(original, content_type)
            fmt_label = file_type.value
            file_id = uuid.uuid4()
            key = f"{file_id}{_SUFFIX[file_type]}"

            with span("upload.store"):
                stored = self._storage.write(
                    key, _chunks(stream), self._settings.max_upload_size_bytes
                )
            try:
                if stored.size_bytes == 0:
                    raise CorruptGeodataError("Uploaded file is empty")
                with span("upload.validate"), self._storage.local_path(key) as path:
                    if file_type is FileType.SHAPEFILE:
                        inspect_shapefile_archive(path, self._archive_limits())
                    else:
                        validate_kml(path)
            except BaseException:
                self._storage.delete(key)
                raise
        except GeoMeasureError:
            metrics.UPLOADED_FILES.labels(fmt_label, "rejected").inc()
            raise

        record = FileRecord(
            id=file_id,
            filename=key,
            original_filename=original,
            file_type=file_type,
            file_size_bytes=stored.size_bytes,
            sha256=stored.sha256,
            status=FileStatus.UPLOADED,
            storage_path=key,
        )
        try:
            self._files.add(record)
            job = self._jobs.create(file_id)
            self._session.commit()
        except BaseException:
            self._session.rollback()
            self._storage.delete(key)
            raise

        # Enqueue only after the commit so the worker can always see the rows.
        try:
            self._queue.enqueue(file_id, job.id, request_id)
        except GeoMeasureError:
            self._files.delete(file_id)  # also cascades the job
            self._session.commit()
            self._storage.delete(key)
            metrics.UPLOADED_FILES.labels(fmt_label, "rejected").inc()
            raise

        # Conditional update: never clobber a status the (fast) worker already advanced.
        self._session.execute(
            update(FileRecord)
            .where(FileRecord.id == file_id, FileRecord.status == FileStatus.UPLOADED)
            .values(status=FileStatus.QUEUED)
        )
        self._session.commit()
        self._session.refresh(record)
        metrics.UPLOADED_FILES.labels(fmt_label, "accepted").inc()
        metrics.UPLOAD_BYTES.labels(fmt_label).inc(stored.size_bytes)
        logger.info(
            "file_uploaded",
            extra={
                "original_filename": original,
                "file_size_bytes": stored.size_bytes,
                "file_type": fmt_label,
            },
        )
        return record, job

    # --------------------------------------------------------------- retrieval
    def get(self, file_id: uuid.UUID) -> tuple[FileRecord, ProcessingJob | None]:
        found = self._files.get_with_latest_job(file_id)
        if found is None:
            raise FileRecordNotFoundError(f"No file with id {file_id}")
        return found

    def require(self, file_id: uuid.UUID) -> FileRecord:
        return self.get(file_id)[0]

    def get_job(self, job_id: uuid.UUID) -> ProcessingJob:
        job = self._jobs.get(job_id)
        if job is None:
            raise JobNotFoundError(f"No job with id {job_id}")
        return job

    # ------------------------------------------------------------------ delete
    def delete(self, file_id: uuid.UUID) -> None:
        """DB rows first (one transaction, cascading), then the stored object."""
        record = self.require(file_id)
        if record.status is FileStatus.PROCESSING:
            raise FileBusyError("The file is being processed; retry after it finishes.")
        key = record.storage_path
        self._files.delete(file_id)
        self._session.commit()
        try:
            self._storage.delete(key)
        except OSError:
            # Row is gone; the orphaned object is removed by the cleanup sweep.
            logger.warning("orphaned_object_after_delete")

    def _archive_limits(self) -> ArchiveLimits:
        s = self._settings
        return ArchiveLimits(s.max_zip_entries, s.max_extracted_size_bytes, s.max_compression_ratio)
