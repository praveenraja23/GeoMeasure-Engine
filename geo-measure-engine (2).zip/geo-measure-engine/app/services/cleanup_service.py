"""Retention: delete expired uploads and sweep orphaned stored objects."""

from __future__ import annotations

import logging
import time
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import FileRecord
from app.domain.enums import FileStatus
from app.repositories.file_repository import FileRepository
from app.services.storage import FileStorage

logger = logging.getLogger(__name__)


class CleanupService:
    def __init__(self, session: Session, storage: FileStorage) -> None:
        self._session = session
        self._storage = storage

    def purge_expired(self, retention_days: int) -> int:
        """Delete files (rows + stored object) older than the retention window. Never touches PROCESSING files."""
        cutoff = datetime.now(UTC) - timedelta(days=retention_days)
        repo = FileRepository(self._session)
        removed = 0
        for record in repo.older_than(cutoff):
            if record.status is FileStatus.PROCESSING:
                continue
            key = record.storage_path
            repo.delete(record.id)
            self._session.commit()
            self._storage.delete(key)
            removed += 1
        logger.info("retention_purge_done")
        return removed

    def sweep_orphans(self, min_age_seconds: int = 3600) -> int:
        """Remove stored objects that have no database row (e.g. a crash between write and commit)."""
        known = set(self._session.scalars(select(FileRecord.storage_path)))
        removed = 0
        for key in self._storage.list_keys():
            if key in known:
                continue
            path_age = self._age_seconds(key)
            if path_age is not None and path_age >= min_age_seconds:
                self._storage.delete(key)
                removed += 1
        return removed

    def _age_seconds(self, key: str) -> float | None:
        try:
            with self._storage.local_path(key) as path:
                return time.time() - path.stat().st_mtime
        except FileNotFoundError:
            return None
