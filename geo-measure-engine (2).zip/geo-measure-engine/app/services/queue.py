from __future__ import annotations

import uuid
from typing import Protocol

import redis.exceptions
from kombu.exceptions import KombuError

from app.core.exceptions import ServiceUnavailableError


class JobQueue(Protocol):
    def enqueue(self, file_id: uuid.UUID, job_id: uuid.UUID, request_id: str | None) -> str: ...


class CeleryJobQueue:
    def enqueue(self, file_id: uuid.UUID, job_id: uuid.UUID, request_id: str | None) -> str:
        from app.tasks.processing_tasks import (
            process_geospatial_file,
        )

        try:
            result = process_geospatial_file.apply_async(
                args=[str(file_id)],
                kwargs={"job_id": str(job_id), "request_id": request_id},
                retry=True,
                retry_policy={"max_retries": 2, "interval_start": 0.1, "interval_step": 0.2},
            )
        except (KombuError, redis.exceptions.RedisError, OSError) as exc:
            raise ServiceUnavailableError(
                "The processing queue is currently unavailable; please retry shortly."
            ) from exc
        return str(result.id)
