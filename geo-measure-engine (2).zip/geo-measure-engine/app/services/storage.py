"""Storage abstraction with a local-filesystem implementation.

``S3FileStorage`` would implement the same protocol: ``write`` -> multipart upload,
``local_path`` -> download to a temp file for GDAL, ``delete`` -> DeleteObject.
"""

from __future__ import annotations

import os
from collections.abc import Iterable, Iterator
from contextlib import AbstractContextManager, contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from app.core.exceptions import FileTooLargeError
from app.core.security import resolve_within
from app.utils.hashing import StreamingSha256


@dataclass(frozen=True, slots=True)
class StoredObject:
    key: str
    size_bytes: int
    sha256: str


class FileStorage(Protocol):
    def write(self, key: str, chunks: Iterable[bytes], max_bytes: int) -> StoredObject: ...
    def local_path(self, key: str) -> AbstractContextManager[Path]: ...
    def exists(self, key: str) -> bool: ...
    def delete(self, key: str) -> None: ...
    def list_keys(self) -> list[str]: ...


class LocalFileStorage:
    def __init__(self, root: Path) -> None:
        self._root = root
        self._root.mkdir(parents=True, exist_ok=True)

    def write(self, key: str, chunks: Iterable[bytes], max_bytes: int) -> StoredObject:
        final = resolve_within(self._root, key)
        partial = final.with_name(final.name + ".part")
        digest = StreamingSha256()
        size = 0
        fd = os.open(partial, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            with os.fdopen(fd, "wb") as out:
                for chunk in chunks:
                    size += len(chunk)
                    if size > max_bytes:
                        raise FileTooLargeError(
                            f"Upload exceeds the {max_bytes // (1024 * 1024)} MB limit"
                        )
                    digest.update(chunk)
                    out.write(chunk)
            os.replace(partial, final)
        except BaseException:
            partial.unlink(missing_ok=True)
            raise
        return StoredObject(key, size, digest.hexdigest())

    @contextmanager
    def local_path(self, key: str) -> Iterator[Path]:
        path = resolve_within(self._root, key)
        if not path.is_file():
            raise FileNotFoundError(key)
        yield path

    def exists(self, key: str) -> bool:
        return resolve_within(self._root, key).is_file()

    def delete(self, key: str) -> None:
        resolve_within(self._root, key).unlink(missing_ok=True)

    def list_keys(self) -> list[str]:
        return sorted(
            p.name for p in self._root.iterdir() if p.is_file() and not p.name.endswith(".part")
        )
