"""Strongly typed, immutable application settings (12-factor: env driven)."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_MB = 1024 * 1024
# Sentinel used to *reject* unsafe production config; it is not a credential.
_PLACEHOLDER_SECRET = "change-me"  # noqa: S105  # nosec B105


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        frozen=True,
        env_ignore_empty=True,  # `TEMP_DIR=` in an env file means "unset", not Path("")
    )

    # --- application -------------------------------------------------------
    app_name: str = "GeoMeasure Engine"
    app_env: Literal["development", "test", "production"] = "development"
    debug: bool = False
    log_level: str = "INFO"
    problem_type_base_url: str = "https://geo-measure.example/problems"

    # --- infrastructure ----------------------------------------------------
    database_url: str
    redis_url: str = "redis://localhost:6379/0"
    celery_broker_url: str | None = None
    celery_result_backend: str | None = None
    celery_task_always_eager: bool = False
    redis_socket_timeout_seconds: float = Field(default=5.0, gt=0)

    # --- storage -----------------------------------------------------------
    file_storage_path: Path = Path.home() / ".local/share/geo-measure-engine/uploads"
    temp_dir: Path | None = None
    retention_days: int = Field(default=30, ge=1)

    # --- ingestion limits --------------------------------------------------
    max_upload_size_mb: int = Field(default=100, ge=1)
    max_zip_entries: int = Field(default=50, ge=1)
    max_extracted_size_mb: int = Field(default=500, ge=1)
    max_compression_ratio: int = Field(default=100, ge=1)

    # --- processing limits -------------------------------------------------
    feature_batch_size: int = Field(default=1000, ge=1, le=5000)
    max_vertices_per_feature: int = Field(default=2_000_000, ge=1)
    max_properties_bytes: int = Field(default=32_768, ge=256)
    max_property_value_chars: int = Field(default=4096, ge=16)
    utm_max_lon_span_deg: float = Field(default=6.0, gt=0, le=60)

    # --- pagination --------------------------------------------------------
    default_page_size: int = Field(default=50, ge=1)
    max_page_size: int = Field(default=500, ge=1)
    max_geojson_page_size: int = Field(default=1000, ge=1)

    # --- database pool / timeouts -----------------------------------------
    db_pool_size: int = Field(default=5, ge=1)
    db_max_overflow: int = Field(default=10, ge=0)
    db_pool_recycle_seconds: int = Field(default=1800, ge=30)
    db_pool_timeout_seconds: int = Field(default=30, ge=1)
    db_connect_timeout_seconds: int = Field(default=10, ge=1)
    db_statement_timeout_ms: int = Field(default=120_000, ge=1000)

    # --- celery ------------------------------------------------------------
    task_soft_time_limit_seconds: int = Field(default=3600, ge=10)
    task_time_limit_seconds: int = Field(default=3900, ge=15)
    task_max_retries: int = Field(default=3, ge=0)
    task_retry_backoff_seconds: int = Field(default=5, ge=1)
    task_retry_backoff_max_seconds: int = Field(default=300, ge=1)

    # --- observability -----------------------------------------------------
    metrics_enabled: bool = True
    worker_metrics_port: int = Field(default=9100, ge=0, le=65535)
    enable_tracing: bool = False
    otel_exporter_otlp_endpoint: str | None = None

    @model_validator(mode="after")
    def _check_consistency(self) -> Settings:
        if self.task_time_limit_seconds <= self.task_soft_time_limit_seconds:
            raise ValueError("TASK_TIME_LIMIT_SECONDS must exceed TASK_SOFT_TIME_LIMIT_SECONDS")
        if self.default_page_size > self.max_page_size:
            raise ValueError("DEFAULT_PAGE_SIZE must not exceed MAX_PAGE_SIZE")
        if self.app_env == "production":
            if self.debug:
                raise ValueError("DEBUG must be false when APP_ENV=production")
            if _PLACEHOLDER_SECRET in self.database_url:
                raise ValueError("DATABASE_URL still contains the placeholder credential")
        return self

    # --- derived values ----------------------------------------------------
    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def max_upload_size_bytes(self) -> int:
        return self.max_upload_size_mb * _MB

    @property
    def max_extracted_size_bytes(self) -> int:
        return self.max_extracted_size_mb * _MB

    @property
    def effective_broker_url(self) -> str:
        return self.celery_broker_url or self.redis_url

    @property
    def effective_result_backend(self) -> str:
        return self.celery_result_backend or self.redis_url

    @property
    def effective_temp_dir(self) -> Path:
        return self.temp_dir or (self.file_storage_path.parent / "tmp")


@lru_cache
def get_settings() -> Settings:
    return Settings()
