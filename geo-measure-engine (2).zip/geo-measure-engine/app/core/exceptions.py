"""Domain exceptions mapped to stable machine-readable error codes."""

from __future__ import annotations

from typing import Any, ClassVar

from app.domain.enums import ErrorCode


class GeoMeasureError(Exception):
    """Base class. Subclasses fix HTTP status, error code and retry semantics."""

    status_code: ClassVar[int] = 500
    error_code: ClassVar[ErrorCode] = ErrorCode.PROCESSING_FAILED
    title: ClassVar[str] = "Processing failed"
    retryable: ClassVar[bool] = False

    def __init__(
        self,
        detail: str | None = None,
        *,
        error_code: ErrorCode | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(detail or self.title)
        self.detail = detail or self.title
        self.code: ErrorCode = error_code or self.error_code
        self.extra = extra or {}


class UnsupportedFileTypeError(GeoMeasureError):
    status_code = 415
    error_code = ErrorCode.INVALID_FILE_TYPE
    title = "Unsupported file type"


class FileTooLargeError(GeoMeasureError):
    status_code = 413
    error_code = ErrorCode.FILE_TOO_LARGE
    title = "Upload exceeds the configured size limit"


class InvalidArchiveError(GeoMeasureError):
    status_code = 400
    error_code = ErrorCode.INVALID_ARCHIVE
    title = "Invalid archive"


class UnsafeArchiveError(GeoMeasureError):
    status_code = 400
    error_code = ErrorCode.UNSAFE_ARCHIVE
    title = "Unsafe archive rejected"


class UnsafeContentError(GeoMeasureError):
    status_code = 400
    error_code = ErrorCode.UNSAFE_CONTENT
    title = "Unsafe file content rejected"


class MissingShapefileComponentError(GeoMeasureError):
    status_code = 400
    error_code = ErrorCode.MISSING_SHAPEFILE_COMPONENT
    title = "Shapefile component missing"


class MultipleShapefilesError(GeoMeasureError):
    status_code = 400
    error_code = ErrorCode.MULTIPLE_SHAPEFILES
    title = "Archive contains multiple Shapefiles"


class CorruptGeodataError(GeoMeasureError):
    status_code = 400
    error_code = ErrorCode.CORRUPT_GEODATA
    title = "Geospatial data could not be read"


class MissingCRSError(GeoMeasureError):
    status_code = 422
    error_code = ErrorCode.CRS_UNKNOWN
    title = "Coordinate reference system could not be determined"


class CRSTransformationError(GeoMeasureError):
    status_code = 422
    error_code = ErrorCode.CRS_TRANSFORMATION_FAILED
    title = "Coordinate transformation failed"


class UnsupportedGeometryError(GeoMeasureError):
    status_code = 422
    error_code = ErrorCode.UNSUPPORTED_GEOMETRY
    title = "Unsupported geometry"


class GeometryRepairError(GeoMeasureError):
    status_code = 422
    error_code = ErrorCode.GEOMETRY_REPAIR_FAILED
    title = "Geometry could not be repaired"


class MeasurementError(GeoMeasureError):
    status_code = 422
    error_code = ErrorCode.MEASUREMENT_FAILED
    title = "Measurement failed"


class FileRecordNotFoundError(GeoMeasureError):
    """Named to avoid shadowing the builtin ``FileNotFoundError``."""

    status_code = 404
    error_code = ErrorCode.FILE_NOT_FOUND
    title = "File not found"


class JobNotFoundError(GeoMeasureError):
    status_code = 404
    error_code = ErrorCode.JOB_NOT_FOUND
    title = "Job not found"


class FileBusyError(GeoMeasureError):
    status_code = 409
    error_code = ErrorCode.FILE_BUSY
    title = "File is currently being processed"


class InvalidQueryError(GeoMeasureError):
    status_code = 422
    error_code = ErrorCode.INVALID_QUERY
    title = "Invalid query parameters"


class ServiceUnavailableError(GeoMeasureError):
    status_code = 503
    error_code = ErrorCode.QUEUE_UNAVAILABLE
    title = "Processing queue unavailable"


class ProcessingError(GeoMeasureError):
    status_code = 500
    error_code = ErrorCode.PROCESSING_FAILED
    title = "Processing failed"


class RetryableProcessingError(ProcessingError):
    """Transient infrastructure failure (database, Redis, storage). Celery retries these."""

    retryable = True
    title = "Transient processing failure"
