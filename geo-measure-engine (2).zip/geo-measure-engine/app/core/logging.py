"""Structured JSON logging with request / job / file correlation."""

from __future__ import annotations

import json
import logging
import sys
from contextvars import ContextVar
from datetime import UTC, datetime
from typing import Any

request_id_var: ContextVar[str | None] = ContextVar("request_id", default=None)
job_id_var: ContextVar[str | None] = ContextVar("job_id", default=None)
file_id_var: ContextVar[str | None] = ContextVar("file_id", default=None)

# Only these ``extra=`` keys are emitted. This is an allow-list on purpose: geometry
# payloads, attribute values, secrets and environment variables can never leak into
# logs through a careless ``extra={...}``.
_ALLOWED_FIELDS = frozenset(
    {
        "duration_ms",
        "feature_count",
        "error_code",
        "original_filename",
        "method",
        "path",
        "status_code",
        "file_type",
        "file_size_bytes",
        "attempt",
        "batch_start",
        "processed_features",
        "status",
        "measurement_crs",
        "source_crs",
        "retry_in_seconds",
    }
)

_RESERVED = frozenset(logging.LogRecord("", 0, "", 0, "", None, None).__dict__) | {
    "message",
    "asctime",
}


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "event": record.getMessage(),
            "request_id": request_id_var.get(),
            "job_id": job_id_var.get(),
            "file_id": file_id_var.get(),
        }
        for key, value in record.__dict__.items():
            if key in _ALLOWED_FIELDS and key not in _RESERVED:
                payload[key] = value
        if record.exc_info:
            payload["stack"] = self.formatException(record.exc_info)
        return json.dumps({k: v for k, v in payload.items() if v is not None}, default=str)


class _GeoMeasureHandler(logging.StreamHandler):  # type: ignore[type-arg]
    """Marker subclass so configure_logging() stays idempotent."""


def configure_logging(level: str = "INFO") -> None:
    root = logging.getLogger()
    root.setLevel(level.upper())
    for handler in list(root.handlers):
        if isinstance(handler, _GeoMeasureHandler):
            root.removeHandler(handler)
    handler = _GeoMeasureHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    root.addHandler(handler)
    # Access logs are emitted by RequestContextMiddleware in the same JSON shape.
    access = logging.getLogger("uvicorn.access")
    access.handlers.clear()
    access.propagate = False


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
