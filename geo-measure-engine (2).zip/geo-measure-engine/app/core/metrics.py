"""Prometheus metrics. Labels are low-cardinality by construction (no ids, no paths)."""

from __future__ import annotations

import os

from prometheus_client import (
    CONTENT_TYPE_LATEST,
    CollectorRegistry,
    Counter,
    Histogram,
    generate_latest,
    multiprocess,
)

UPLOADED_FILES = Counter(
    "uploaded_files_total", "Upload attempts by detected format and outcome", ["format", "outcome"]
)
UPLOAD_BYTES = Counter("upload_bytes_total", "Bytes of accepted uploads", ["format"])
PROCESSING_JOBS = Counter(
    "processing_jobs_total", "Processing job executions by final status", ["format", "status"]
)
PROCESSING_JOBS_FAILED = Counter(
    "processing_jobs_failed_total", "Failed processing jobs by error code", ["format", "error_code"]
)
PROCESSING_DURATION = Histogram(
    "processing_duration_seconds",
    "Wall-clock time to process one file",
    ["format"],
    buckets=(0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30, 60, 120, 300, 900, 3600),
)
FEATURES_PROCESSED = Counter(
    "features_processed_total",
    "Features processed by geometry type and measurement status",
    ["format", "geometry_type", "measurement_status"],
)
MEASUREMENT_FAILURES = Counter(
    "measurement_failures_total",
    "Feature measurements that failed, by geometry type and error code",
    ["geometry_type", "error_code"],
)
API_REQUEST_DURATION = Histogram(
    "api_request_duration_seconds",
    "HTTP request latency by method, route template and status code",
    ["method", "route", "status"],
    buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30),
)


def render_metrics() -> tuple[bytes, str]:
    """Render the registry; aggregates worker processes when multiprocess mode is on."""
    if os.environ.get("PROMETHEUS_MULTIPROC_DIR"):
        registry = CollectorRegistry()
        multiprocess.MultiProcessCollector(registry)  # type: ignore[no-untyped-call]  # prometheus_client ships this class untyped
        return generate_latest(registry), CONTENT_TYPE_LATEST
    return generate_latest(), CONTENT_TYPE_LATEST
