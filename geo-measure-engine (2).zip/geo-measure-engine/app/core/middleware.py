from __future__ import annotations

import logging
import re
import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

from app.core import metrics
from app.core.config import get_settings
from app.core.exceptions import FileTooLargeError
from app.core.logging import request_id_var

logger = logging.getLogger(__name__)
_SAFE_ID = re.compile(r"^[A-Za-z0-9._-]{8,64}$")
# multipart framing + form fields add a little to the file size
_MULTIPART_OVERHEAD = 64 * 1024


class RequestContextMiddleware(BaseHTTPMiddleware):
    """Correlation id, early size rejection, access log and latency metric."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        incoming = request.headers.get("x-request-id", "")
        request_id = incoming if _SAFE_ID.match(incoming) else uuid.uuid4().hex
        token = request_id_var.set(request_id)
        request.state.request_id = request_id
        started = time.perf_counter()
        response: Response | None = None
        try:
            response = self._reject_oversized(request) or await call_next(request)
            return response
        finally:
            duration = time.perf_counter() - started
            status = response.status_code if response else 500
            route = getattr(request.scope.get("route"), "path", "unmatched")
            if request.url.path != "/metrics":
                metrics.API_REQUEST_DURATION.labels(request.method, route, str(status)).observe(
                    duration
                )
            logger.info(
                "http_request",
                extra={
                    "method": request.method,
                    "path": route,
                    "status_code": status,
                    "duration_ms": int(duration * 1000),
                },
            )
            if response is not None:
                response.headers["X-Request-ID"] = request_id
            request_id_var.reset(token)

    @staticmethod
    def _reject_oversized(request: Request) -> Response | None:
        if request.method != "POST":
            return None
        length = request.headers.get("content-length")
        limit = get_settings().max_upload_size_bytes + _MULTIPART_OVERHEAD
        if length and length.isdigit() and int(length) > limit:
            from app.api.errors import problem_response  # noqa: PLC0415

            exc = FileTooLargeError(
                f"Request body exceeds the {get_settings().max_upload_size_mb} MB upload limit"
            )
            return problem_response(
                request, status=exc.status_code, title=exc.title, code=exc.code, detail=exc.detail
            )
        return None
