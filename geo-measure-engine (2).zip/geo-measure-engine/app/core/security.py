"""Small, dependency-free helpers for untrusted names and paths."""

from __future__ import annotations

import re
from pathlib import Path

_CONTROL = re.compile(r"[\x00-\x1f\x7f]")
_MAX_NAME = 255


def sanitize_display_filename(raw: str | None, default: str = "upload") -> str:
    """Return a printable base name for *metadata only*.

    The result is never used to build a filesystem path; stored objects get
    UUID-derived keys.
    """
    if not raw:
        return default
    base = raw.replace("\\", "/").rsplit("/", 1)[-1]
    base = _CONTROL.sub("", base).strip()
    return base[:_MAX_NAME] or default


def resolve_within(root: Path, relative: str) -> Path:
    """Join ``relative`` onto ``root`` and refuse anything that escapes it."""
    root_resolved = root.resolve()
    candidate = (root_resolved / relative).resolve()
    if root_resolved != candidate and root_resolved not in candidate.parents:
        raise ValueError("path escapes storage root")
    return candidate
