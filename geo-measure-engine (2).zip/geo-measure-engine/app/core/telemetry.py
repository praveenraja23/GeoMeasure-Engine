"""Optional OpenTelemetry tracing. The service starts and runs without it."""

from __future__ import annotations

import logging
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any

from app.core.config import Settings

logger = logging.getLogger(__name__)

_tracer: Any = None


def setup_tracing(settings: Settings, service: str, app: Any | None = None) -> bool:
    """Configure tracing when ENABLE_TRACING is set and the ``tracing`` extra is installed."""
    global _tracer  # noqa: PLW0603 - module-level tracer is the standard OTel pattern
    if not settings.enable_tracing:
        return False
    try:
        from opentelemetry import trace
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
    except ImportError:
        logger.warning("tracing_unavailable: install the 'tracing' extra to enable OpenTelemetry")
        return False

    provider = TracerProvider(
        resource=Resource.create({"service.name": f"geo-measure-engine-{service}"})
    )
    endpoint = settings.otel_exporter_otlp_endpoint
    if endpoint:
        url = (
            endpoint
            if endpoint.rstrip("/").endswith("/v1/traces")
            else endpoint.rstrip("/") + "/v1/traces"
        )
        provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=url)))
    else:
        logger.warning("tracing_enabled_without_exporter: OTEL_EXPORTER_OTLP_ENDPOINT is not set")
    trace.set_tracer_provider(provider)
    _tracer = trace.get_tracer("geo_measure_engine")

    if app is not None:
        try:
            from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

            FastAPIInstrumentor.instrument_app(app)
        except ImportError:
            logger.warning("fastapi_instrumentation_unavailable")
    return True


@contextmanager
def span(name: str, **attributes: str | int | float | bool) -> Iterator[None]:
    """Create a child span when tracing is configured; otherwise a no-op."""
    if _tracer is None:
        yield
        return
    with _tracer.start_as_current_span(name) as current:
        for key, value in attributes.items():
            current.set_attribute(key, value)
        yield
