from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    DateTime,
    Index,
    Integer,
    String,
    Text,
    Uuid,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, check_in, enum_column
from app.domain.enums import FileStatus, FileType


class FileRecord(Base):
    __tablename__ = "files"
    __table_args__ = (
        CheckConstraint(check_in("status", FileStatus), name="ck_files_status"),
        CheckConstraint(check_in("file_type", FileType), name="ck_files_file_type"),
        CheckConstraint(
            "feature_count >= 0 AND successful_feature_count >= 0 AND failed_feature_count >= 0",
            name="ck_files_counts_non_negative",
        ),
        # Counters are only authoritative once processing has finished.
        CheckConstraint(
            "status NOT IN ('COMPLETED', 'PARTIALLY_COMPLETED', 'FAILED') "
            "OR feature_count = successful_feature_count + failed_feature_count",
            name="ck_files_counts_consistent",
        ),
        Index("ix_files_status", "status"),
        Index("ix_files_created_at", "created_at"),
        Index("ix_files_sha256", "sha256"),
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    # Internal, UUID-derived object name. The user-supplied name lives in original_filename.
    filename: Mapped[str] = mapped_column(String(80), nullable=False)
    original_filename: Mapped[str] = mapped_column(String(255), nullable=False)
    file_type: Mapped[FileType] = mapped_column(enum_column(FileType), nullable=False)
    file_size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    sha256: Mapped[str] = mapped_column(String(64), nullable=False)
    status: Mapped[FileStatus] = mapped_column(enum_column(FileStatus), nullable=False)

    source_crs: Mapped[str | None] = mapped_column(String(255))
    source_crs_name: Mapped[str | None] = mapped_column(String(255))
    measurement_crs: Mapped[str | None] = mapped_column(String(255))
    measurement_crs_name: Mapped[str | None] = mapped_column(String(255))
    measurement_units: Mapped[str | None] = mapped_column(String(32))
    crs_selection_reason: Mapped[str | None] = mapped_column(Text)

    feature_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )
    successful_feature_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )
    failed_feature_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )
    processing_started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    processing_completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    error_code: Mapped[str | None] = mapped_column(String(64))
    error_message: Mapped[str | None] = mapped_column(Text)
    storage_path: Mapped[str] = mapped_column(String(255), nullable=False)
