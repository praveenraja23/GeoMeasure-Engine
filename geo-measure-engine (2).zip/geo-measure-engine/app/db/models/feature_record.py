from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from geoalchemy2 import Geometry
from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    UniqueConstraint,
    Uuid,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class FeatureRecord(Base):
    __tablename__ = "features"
    __table_args__ = (
        # Idempotency anchor: a retried job upserts on this key instead of duplicating rows.
        UniqueConstraint("file_id", "feature_index", name="uq_features_file_id_feature_index"),
        Index("ix_features_file_id_geometry_type", "file_id", "geometry_type"),
        Index("ix_features_geometry_gist", "geometry", postgresql_using="gist"),
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True)
    file_id: Mapped[uuid.UUID] = mapped_column(
        Uuid, ForeignKey("files.id", ondelete="CASCADE"), nullable=False
    )
    feature_index: Mapped[int] = mapped_column(Integer, nullable=False)
    geometry_type: Mapped[str] = mapped_column(String(32), nullable=False)
    source_geometry_type: Mapped[str | None] = mapped_column(String(32))
    properties: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False, server_default="{}")
    source_crs: Mapped[str | None] = mapped_column(String(255))
    storage_crs: Mapped[str] = mapped_column(String(32), nullable=False, default="EPSG:4326")
    # NULL for NULL/empty/unrepairable geometry or unknown CRS (see README "Failure policy").
    geometry: Mapped[Any | None] = mapped_column(
        Geometry(geometry_type="GEOMETRY", srid=4326, spatial_index=False)
    )
    is_valid_before: Mapped[bool | None] = mapped_column(Boolean)
    is_valid_after: Mapped[bool | None] = mapped_column(Boolean)
    was_repaired: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="false"
    )
    repair_method: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
