from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    Double,
    ForeignKey,
    Index,
    String,
    Text,
    Uuid,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, check_in, enum_column
from app.domain.enums import MeasurementStatus, ValidityStatus


class MeasurementRecord(Base):
    __tablename__ = "measurements"
    __table_args__ = (
        CheckConstraint(
            check_in("measurement_status", MeasurementStatus), name="ck_measurements_status"
        ),
        CheckConstraint(
            check_in("validity_status", ValidityStatus), name="ck_measurements_validity"
        ),
        Index("ix_measurements_file_id_status", "file_id", "measurement_status"),
    )

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True)
    feature_id: Mapped[uuid.UUID] = mapped_column(
        Uuid, ForeignKey("features.id", ondelete="CASCADE"), nullable=False, unique=True
    )
    # Denormalised so a file's measurements can be counted/paged without touching features.
    file_id: Mapped[uuid.UUID] = mapped_column(
        Uuid, ForeignKey("files.id", ondelete="CASCADE"), nullable=False
    )
    measurement_status: Mapped[MeasurementStatus] = mapped_column(
        enum_column(MeasurementStatus), nullable=False
    )
    # Full double precision is stored; rounding is a presentation concern.
    area_m2: Mapped[float | None] = mapped_column(Double)
    area_hectares: Mapped[float | None] = mapped_column(Double)
    length_m: Mapped[float | None] = mapped_column(Double)
    length_km: Mapped[float | None] = mapped_column(Double)
    measurement_crs: Mapped[str | None] = mapped_column(String(255))
    calculation_method: Mapped[str | None] = mapped_column(String(32))
    validity_status: Mapped[ValidityStatus] = mapped_column(
        enum_column(ValidityStatus), nullable=False
    )
    warning: Mapped[str | None] = mapped_column(Text)
    error_code: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
