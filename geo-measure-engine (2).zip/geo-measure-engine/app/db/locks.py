from __future__ import annotations

import uuid
from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import Engine, text


@contextmanager
def advisory_lock(engine: Engine, file_id: uuid.UUID) -> Iterator[bool]:
    """Session-level PostgreSQL advisory lock keyed on the file.

    Prevents two workers (e.g. a redelivered message) from processing the same file at
    once. Yields False when another session holds the lock.
    """
    key = file_id.int & 0x7FFF_FFFF_FFFF_FFFF
    with engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
        acquired = bool(conn.execute(text("SELECT pg_try_advisory_lock(:k)"), {"k": key}).scalar())
        try:
            yield acquired
        finally:
            if acquired:
                conn.execute(text("SELECT pg_advisory_unlock(:k)"), {"k": key})
