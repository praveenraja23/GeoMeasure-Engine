from __future__ import annotations

from enum import Enum as PyEnum

from sqlalchemy import Enum
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Declarative base. Constraint/index names are always explicit (see migrations)."""


def enum_column(enum_cls: type[PyEnum], length: int = 32) -> Enum:
    """Store the enum *value* in a VARCHAR; integrity is enforced by a named CHECK constraint."""
    return Enum(
        enum_cls,
        native_enum=False,
        length=length,
        validate_strings=True,
        values_callable=lambda e: [m.value for m in e],
    )


def check_in(column: str, enum_cls: type[PyEnum]) -> str:
    values = ", ".join(f"'{m.value}'" for m in enum_cls)
    return f"{column} IN ({values})"
