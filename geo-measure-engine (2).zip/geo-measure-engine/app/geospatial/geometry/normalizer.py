"""Turn reader output into format-independent ``NormalizedFeature`` objects.

Normalisation rules (documented in the README):

* NULL geometry  -> kept, ``geometry_type == "Null"``, no geometry.
* Z / M values   -> dropped (measurements are planar 2-D).
* Homogeneous GeometryCollection (e.g. KML ``MultiGeometry`` of polygons)
  -> collapsed to Polygon/MultiPolygon, LineString/MultiLineString or Point/MultiPoint.
* Mixed GeometryCollection -> kept as-is; the measurement engine reports UNSUPPORTED
  (a single feature cannot meaningfully carry both an area and a length here).
* Attribute values -> JSON-safe (numpy scalars, NaN, dates, Decimals, bytes).
"""

from __future__ import annotations

import math
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import date, datetime, time
from decimal import Decimal
from typing import Any

import geopandas as gpd
import numpy as np
import pandas as pd
import shapely
from shapely.geometry.base import BaseGeometry

from app.geospatial.geometry.helpers import (
    NULL_GEOMETRY_TYPE,
    assemble,
    family_of,
    iter_atomic,
)


@dataclass(frozen=True, slots=True)
class NormalizedFeature:
    feature_index: int
    geometry: BaseGeometry | None
    geometry_type: str
    source_geometry_type: str | None
    properties: dict[str, Any]
    warnings: tuple[str, ...] = ()


def unique_columns(columns: list[str]) -> list[str]:
    """Make column names unique (duplicates get ``_2``, ``_3`` ... suffixes)."""
    seen: dict[str, int] = {}
    result: list[str] = []
    for col in columns:
        name = str(col)
        count = seen.get(name, 0) + 1
        seen[name] = count
        result.append(name if count == 1 else f"{name}_{count}")
    return result


def json_safe(value: Any, max_chars: int) -> tuple[Any, bool]:
    """Return ``(json_value, truncated)``. Never raises."""
    try:
        return _json_safe(value, max_chars)
    except Exception:
        return None, False


def _json_safe(value: Any, max_chars: int) -> tuple[Any, bool]:  # noqa: PLR0911
    if value is None or value is pd.NA or value is pd.NaT:
        return None, False
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, bool):
        return value, False
    if isinstance(value, int):
        return value, False
    if isinstance(value, float):
        return (value, False) if math.isfinite(value) else (None, False)
    if isinstance(value, Decimal):
        number = float(value)
        return (number, False) if math.isfinite(number) else (None, False)
    if isinstance(value, pd.Timestamp | datetime | date | time):
        return value.isoformat(), False
    if isinstance(value, bytes | bytearray):
        value = bytes(value).decode("utf-8", errors="replace")
    if isinstance(value, str):
        if not value.strip():
            return None, False
        value = value.replace("\x00", "")
        if len(value) > max_chars:
            return value[:max_chars], True
        return value, False
    if isinstance(value, list | tuple | set | np.ndarray):
        items = [json_safe(v, max_chars)[0] for v in list(value)[:1000]]
        return items, False
    return json_safe(str(value), max_chars)


class FeatureNormalizer:
    def __init__(self, max_properties_bytes: int, max_property_value_chars: int) -> None:
        self._max_props_bytes = max_properties_bytes
        self._max_chars = max_property_value_chars

    def normalize_frame(
        self, frame: gpd.GeoDataFrame, start_index: int
    ) -> Iterator[NormalizedFeature]:
        geom_name = frame.geometry.name
        attr_columns = [c for c in frame.columns if c != geom_name]
        names = unique_columns([str(c) for c in attr_columns])
        attrs = frame[attr_columns]
        geometries = frame.geometry.values
        for offset in range(len(frame)):
            raw = attrs.iloc[offset].tolist() if attr_columns else []
            properties, warnings = self._properties(dict(zip(names, raw, strict=True)))
            geometry, source_type, geom_warnings = self._geometry(geometries[offset])
            yield NormalizedFeature(
                feature_index=start_index + offset,
                geometry=geometry,
                geometry_type=geometry.geom_type if geometry is not None else NULL_GEOMETRY_TYPE,
                source_geometry_type=source_type,
                properties=properties,
                warnings=tuple(geom_warnings + warnings),
            )

    # ------------------------------------------------------------------ geometry
    def _geometry(
        self, raw: BaseGeometry | None
    ) -> tuple[BaseGeometry | None, str | None, list[str]]:
        if raw is None:
            return None, None, []
        source_type = raw.geom_type
        warnings: list[str] = []
        geom = shapely.force_2d(raw)
        if geom.geom_type == "GeometryCollection" and not geom.is_empty:
            atoms = list(iter_atomic(geom))
            families = {family_of(a.geom_type) for a in atoms}
            if len(families) == 1 and None not in families:
                (family,) = families
                geom = assemble(atoms, family)  # type: ignore[arg-type]
            else:
                warnings.append(
                    "Mixed GeometryCollection kept as-is; measurement is not defined for it"
                )
        return geom, source_type, warnings

    # ---------------------------------------------------------------- properties
    def _properties(self, raw: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
        warnings: list[str] = []
        clean: dict[str, Any] = {}
        truncated: list[str] = []
        for key, value in raw.items():
            safe, was_truncated = json_safe(value, self._max_chars)
            clean[key] = safe
            if was_truncated:
                truncated.append(key)
        if truncated:
            warnings.append(
                f"Attribute value(s) truncated to {self._max_chars} characters: "
                + ", ".join(sorted(truncated)[:5])
            )
        size = sum(len(str(k)) + len(str(v)) for k, v in clean.items())
        if size > self._max_props_bytes:
            warnings.append(
                f"Attributes exceed {self._max_props_bytes} bytes; non-null values were dropped"
            )
            clean = dict.fromkeys(clean)
        return clean, warnings
