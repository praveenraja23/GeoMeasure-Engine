"""Shared geometry primitives (no CRS or I/O logic lives here)."""

from __future__ import annotations

from collections.abc import Iterator

import numpy as np
import shapely
from shapely.geometry import (
    GeometryCollection,
    LineString,
    MultiLineString,
    MultiPoint,
    MultiPolygon,
    Point,
    Polygon,
)
from shapely.geometry.base import BaseGeometry

POLYGONAL_TYPES = frozenset({"Polygon", "MultiPolygon"})
LINEAR_TYPES = frozenset({"LineString", "MultiLineString"})
POINTAL_TYPES = frozenset({"Point", "MultiPoint"})

NULL_GEOMETRY_TYPE = "Null"


def iter_atomic(geom: BaseGeometry) -> Iterator[BaseGeometry]:
    """Yield Point/LineString/LinearRing/Polygon members, flattening Multi* and collections."""
    if geom.geom_type in {"MultiPoint", "MultiLineString", "MultiPolygon", "GeometryCollection"}:
        for part in geom.geoms:  # type: ignore[attr-defined]
            yield from iter_atomic(part)
    else:
        yield geom


def has_finite_coordinates(geom: BaseGeometry) -> bool:
    coords = shapely.get_coordinates(geom)
    return bool(np.isfinite(coords).all())


def assemble(parts: list[BaseGeometry], family: str) -> BaseGeometry:
    """Build the narrowest geometry (single or Multi*) for homogeneous ``parts``."""
    if not parts:
        return GeometryCollection()
    if len(parts) == 1:
        return parts[0]
    if family == "polygon":
        return MultiPolygon([p for p in parts if isinstance(p, Polygon)])
    if family == "line":
        return MultiLineString([p for p in parts if isinstance(p, LineString)])
    return MultiPoint([p for p in parts if isinstance(p, Point)])


def family_of(geom_type: str) -> str | None:
    if geom_type in POLYGONAL_TYPES:
        return "polygon"
    if geom_type in LINEAR_TYPES:
        return "line"
    if geom_type in POINTAL_TYPES:
        return "point"
    return None
