"""Geometry validity checks and recorded repair (never silent)."""

from __future__ import annotations

from dataclasses import dataclass

import shapely
from shapely.geometry.base import BaseGeometry

from app.domain.enums import ErrorCode
from app.geospatial.geometry.helpers import (
    assemble,
    family_of,
    has_finite_coordinates,
    iter_atomic,
)

REPAIR_METHOD = "shapely.make_valid(linework)"


@dataclass(frozen=True, slots=True)
class GeometryCheck:
    geometry: BaseGeometry | None
    is_valid_before: bool
    is_valid_after: bool
    was_repaired: bool
    repair_method: str | None
    error_code: ErrorCode | None = None
    message: str | None = None


class GeometryValidator:
    """Validate a non-empty geometry; repair it with GEOS ``MakeValid`` when invalid.

    Repair can change topology (a bow-tie polygon becomes a MultiPolygon of two
    lobes), so the original and repaired validity plus the method are returned and
    persisted by the caller.
    """

    def check(self, geometry: BaseGeometry) -> GeometryCheck:
        if not has_finite_coordinates(geometry):
            return GeometryCheck(
                None,
                False,
                False,
                False,
                None,
                ErrorCode.INVALID_GEOMETRY,
                "Geometry contains NaN or infinite coordinates",
            )
        if shapely.is_valid(geometry):
            return GeometryCheck(geometry, True, True, False, None)

        try:
            repaired = self._restore_family(shapely.make_valid(geometry), geometry)
        except Exception:
            repaired = None
        if repaired is None or repaired.is_empty or not shapely.is_valid(repaired):
            return GeometryCheck(
                None,
                False,
                False,
                False,
                None,
                ErrorCode.GEOMETRY_REPAIR_FAILED,
                "Geometry is invalid and could not be repaired",
            )
        return GeometryCheck(repaired, False, True, True, REPAIR_METHOD)

    @staticmethod
    def _restore_family(repaired: BaseGeometry, original: BaseGeometry) -> BaseGeometry | None:
        """Keep only parts of the original dimensionality.

        ``make_valid`` may return a GeometryCollection that mixes polygons with
        collapsed lines/points. Those degenerate remnants have no area, so they are
        dropped (and the repair is recorded). Mixed collections are left untouched.
        """
        family = family_of(original.geom_type)
        if family is None:
            return repaired
        wanted = {"polygon": "Polygon", "line": "LineString", "point": "Point"}[family]
        parts = [p for p in iter_atomic(repaired) if p.geom_type == wanted and not p.is_empty]
        if not parts:
            return None
        return assemble(parts, family)
