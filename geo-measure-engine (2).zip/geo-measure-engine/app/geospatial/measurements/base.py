"""Measurement contracts: result model, context and calculator protocol."""

from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar, Protocol

from shapely.geometry.base import BaseGeometry

from app.domain.enums import CalculationMethod, ErrorCode, MeasurementStatus

SQM_PER_HECTARE = 10_000.0
M_PER_KM = 1_000.0


@dataclass(frozen=True, slots=True)
class MeasurementContext:
    """What the calculator needs to know about the coordinates it receives."""

    measurement_crs: str
    method: CalculationMethod = CalculationMethod.PROJECTED_CRS


@dataclass(frozen=True, slots=True)
class MeasurementResult:
    status: MeasurementStatus
    area_m2: float | None = None
    area_hectares: float | None = None
    length_m: float | None = None
    length_km: float | None = None
    measurement_crs: str | None = None
    calculation_method: CalculationMethod | None = None
    warning: str | None = None
    error_code: ErrorCode | None = None

    @classmethod
    def area(cls, area_m2: float, context: MeasurementContext) -> MeasurementResult:
        return cls(
            MeasurementStatus.COMPLETED,
            area_m2=area_m2,
            area_hectares=area_m2 / SQM_PER_HECTARE,
            measurement_crs=context.measurement_crs,
            calculation_method=context.method,
        )

    @classmethod
    def length(cls, length_m: float, context: MeasurementContext) -> MeasurementResult:
        return cls(
            MeasurementStatus.COMPLETED,
            length_m=length_m,
            length_km=length_m / M_PER_KM,
            measurement_crs=context.measurement_crs,
            calculation_method=context.method,
        )

    @classmethod
    def not_required(cls, warning: str | None = None) -> MeasurementResult:
        return cls(MeasurementStatus.NOT_REQUIRED, warning=warning)

    @classmethod
    def not_measurable(cls, warning: str) -> MeasurementResult:
        return cls(MeasurementStatus.NOT_MEASURABLE, warning=warning)

    @classmethod
    def unsupported(cls, warning: str) -> MeasurementResult:
        return cls(
            MeasurementStatus.UNSUPPORTED,
            warning=warning,
            error_code=ErrorCode.UNSUPPORTED_GEOMETRY,
        )

    @classmethod
    def failed(cls, error_code: ErrorCode, warning: str) -> MeasurementResult:
        return cls(MeasurementStatus.FAILED, warning=warning, error_code=error_code)


class MeasurementCalculator(Protocol):
    """Computes one kind of measurement for geometry types it declares."""

    geometry_types: ClassVar[frozenset[str]]
    # 2 = area, 1 = length, 0 = nothing to measure. Tells the pipeline which
    # measurement CRS to project the geometry into before calling ``calculate``.
    dimension: ClassVar[int]

    def calculate(
        self, geometry: BaseGeometry, context: MeasurementContext
    ) -> MeasurementResult: ...
