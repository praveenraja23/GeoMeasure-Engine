"""Dispatches a geometry to the calculator registered for its type."""

from __future__ import annotations

from collections.abc import Sequence

from shapely.geometry.base import BaseGeometry

from app.geospatial.measurements.base import (
    MeasurementCalculator,
    MeasurementContext,
    MeasurementResult,
)
from app.geospatial.measurements.line import LineStringMeasurementCalculator
from app.geospatial.measurements.multilinestring import MultiLineStringMeasurementCalculator
from app.geospatial.measurements.multipolygon import MultiPolygonMeasurementCalculator
from app.geospatial.measurements.point import PointMeasurementCalculator
from app.geospatial.measurements.polygon import PolygonMeasurementCalculator


def default_calculators() -> list[MeasurementCalculator]:
    return [
        PolygonMeasurementCalculator(),
        MultiPolygonMeasurementCalculator(),
        LineStringMeasurementCalculator(),
        MultiLineStringMeasurementCalculator(),
        PointMeasurementCalculator(),
    ]


class MeasurementEngine:
    def __init__(self, calculators: Sequence[MeasurementCalculator] | None = None) -> None:
        self._registry: dict[str, MeasurementCalculator] = {}
        for calculator in calculators if calculators is not None else default_calculators():
            for geom_type in calculator.geometry_types:
                if geom_type in self._registry:
                    raise ValueError(f"Duplicate calculator registered for {geom_type}")
                self._registry[geom_type] = calculator

    def supports(self, geometry_type: str) -> bool:
        return geometry_type in self._registry

    def dimension_of(self, geometry_type: str) -> int | None:
        """2 (area) / 1 (length) / 0 (nothing to measure), or None when unsupported."""
        calculator = self._registry.get(geometry_type)
        return calculator.dimension if calculator else None

    def measure(self, geometry: BaseGeometry, context: MeasurementContext) -> MeasurementResult:
        calculator = self._registry.get(geometry.geom_type)
        if calculator is None:
            return MeasurementResult.unsupported(
                f"Measurement is not supported for geometry type {geometry.geom_type}"
            )
        return calculator.calculate(geometry, context)
