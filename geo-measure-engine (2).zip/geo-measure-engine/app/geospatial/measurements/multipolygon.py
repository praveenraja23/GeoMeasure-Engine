from __future__ import annotations

from typing import ClassVar

from shapely.geometry.base import BaseGeometry

from app.geospatial.measurements.base import MeasurementContext, MeasurementResult


class MultiPolygonMeasurementCalculator:
    """Total area of a (valid, therefore non-overlapping) MultiPolygon."""

    geometry_types: ClassVar[frozenset[str]] = frozenset({"MultiPolygon"})
    dimension: ClassVar[int] = 2

    def calculate(self, geometry: BaseGeometry, context: MeasurementContext) -> MeasurementResult:
        if geometry.is_empty:
            return MeasurementResult.not_measurable("Geometry is empty")
        return MeasurementResult.area(float(geometry.area), context)
