from __future__ import annotations

from typing import ClassVar

from shapely.geometry.base import BaseGeometry

from app.geospatial.measurements.base import MeasurementContext, MeasurementResult
from app.geospatial.measurements.line import line_length


class MultiLineStringMeasurementCalculator:
    """Sum of the lengths of all parts."""

    geometry_types: ClassVar[frozenset[str]] = frozenset({"MultiLineString"})
    dimension: ClassVar[int] = 1

    def calculate(self, geometry: BaseGeometry, context: MeasurementContext) -> MeasurementResult:
        if geometry.is_empty:
            return MeasurementResult.not_measurable("Geometry is empty")
        return MeasurementResult.length(line_length(geometry, context), context)
