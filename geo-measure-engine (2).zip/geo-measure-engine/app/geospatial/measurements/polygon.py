from __future__ import annotations

from typing import ClassVar

from shapely.geometry.base import BaseGeometry

from app.geospatial.measurements.base import MeasurementContext, MeasurementResult


class PolygonMeasurementCalculator:
    """Planar area of a Polygon.

    The geometry must already be in a metric projected CRS (see MeasurementCRSResolver);
    ``context.measurement_crs`` records which one.
    """

    geometry_types: ClassVar[frozenset[str]] = frozenset({"Polygon"})
    dimension: ClassVar[int] = 2

    def calculate(self, geometry: BaseGeometry, context: MeasurementContext) -> MeasurementResult:
        if geometry.is_empty:
            return MeasurementResult.not_measurable("Geometry is empty")
        return MeasurementResult.area(float(geometry.area), context)
