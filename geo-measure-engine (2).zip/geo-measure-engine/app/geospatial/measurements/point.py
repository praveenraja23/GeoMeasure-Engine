from __future__ import annotations

from typing import ClassVar

from shapely.geometry.base import BaseGeometry

from app.geospatial.measurements.base import MeasurementContext, MeasurementResult


class PointMeasurementCalculator:
    """Points (and MultiPoints) have no area or length.

    The numeric fields stay ``None`` instead of ``0``: zero would be a fabricated value.
    """

    geometry_types: ClassVar[frozenset[str]] = frozenset({"Point", "MultiPoint"})
    dimension: ClassVar[int] = 0

    def calculate(self, geometry: BaseGeometry, context: MeasurementContext) -> MeasurementResult:
        if geometry.geom_type == "MultiPoint":
            return MeasurementResult.not_required(
                "No measurement is defined for this geometry type"
            )
        return MeasurementResult.not_required()
