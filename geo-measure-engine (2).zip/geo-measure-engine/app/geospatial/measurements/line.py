from __future__ import annotations

from typing import ClassVar

from pyproj import Geod
from shapely.geometry.base import BaseGeometry

from app.domain.enums import CalculationMethod
from app.geospatial.measurements.base import MeasurementContext, MeasurementResult

_WGS84 = Geod(ellps="WGS84")


def line_length(geometry: BaseGeometry, context: MeasurementContext) -> float:
    """Length in metres for either planar (projected) or geodesic (lon/lat) input."""
    if context.method is CalculationMethod.GEODESIC:
        return float(_WGS84.geometry_length(geometry))
    return float(geometry.length)


class LineStringMeasurementCalculator:
    geometry_types: ClassVar[frozenset[str]] = frozenset({"LineString"})
    dimension: ClassVar[int] = 1

    def calculate(self, geometry: BaseGeometry, context: MeasurementContext) -> MeasurementResult:
        if geometry.is_empty:
            return MeasurementResult.not_measurable("Geometry is empty")
        return MeasurementResult.length(line_length(geometry, context), context)
