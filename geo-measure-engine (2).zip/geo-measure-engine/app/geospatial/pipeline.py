"""Per-batch feature pipeline: normalise -> validate/repair -> transform -> measure.

Pure with respect to I/O (no database, no files), which makes it directly unit-testable.
A failure of one feature never aborts the batch: every feature yields a result.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, replace
from typing import Any

import geopandas as gpd
import shapely
from pyproj import CRS
from shapely.geometry.base import BaseGeometry

from app.core.exceptions import GeoMeasureError
from app.core.telemetry import span
from app.domain.enums import CalculationMethod, ErrorCode, ValidityStatus
from app.geospatial.crs.resolver import MeasurementPlan, crs_code
from app.geospatial.crs.transformer import GeometryTransformer
from app.geospatial.geometry.normalizer import FeatureNormalizer, NormalizedFeature
from app.geospatial.geometry.validator import GeometryCheck, GeometryValidator
from app.geospatial.measurements.base import MeasurementContext, MeasurementResult
from app.geospatial.measurements.engine import MeasurementEngine

logger = logging.getLogger(__name__)

STORAGE_CRS = CRS.from_epsg(4326)
STORAGE_CRS_CODE = "EPSG:4326"


@dataclass(frozen=True, slots=True)
class ProcessedFeature:
    feature_index: int
    geometry_type: str
    source_geometry_type: str | None
    properties: dict[str, Any]
    source_crs: str | None
    storage_crs: str
    geometry: BaseGeometry | None  # EPSG:4326, ready for PostGIS
    is_valid_before: bool | None
    is_valid_after: bool | None
    was_repaired: bool
    repair_method: str | None
    validity_status: ValidityStatus
    measurement: MeasurementResult


@dataclass(slots=True)
class _Work:
    feature: NormalizedFeature
    check: GeometryCheck | None = None
    source_geom: BaseGeometry | None = None  # validated/repaired, in the source CRS
    storage_geom: BaseGeometry | None = None  # EPSG:4326
    result: MeasurementResult | None = None
    validity: ValidityStatus = ValidityStatus.NOT_CHECKED


def _source_geoms(works: list[_Work]) -> list[BaseGeometry]:
    """Geometries of works that are known to carry one (callers pre-filter)."""
    return [w.source_geom for w in works if w.source_geom is not None]


class FeaturePipeline:
    def __init__(
        self,
        normalizer: FeatureNormalizer,
        validator: GeometryValidator,
        engine: MeasurementEngine,
        transformer: GeometryTransformer,
        max_vertices: int,
    ) -> None:
        self._normalizer = normalizer
        self._validator = validator
        self._engine = engine
        self._transformer = transformer
        self._max_vertices = max_vertices

    def process_batch(
        self,
        frame: gpd.GeoDataFrame,
        start_index: int,
        source_crs: CRS | None,
        plan: MeasurementPlan | None,
        plan_error: GeoMeasureError | None = None,
    ) -> list[ProcessedFeature]:
        works = [_Work(f) for f in self._normalizer.normalize_frame(frame, start_index)]
        with span("geometry.validate"):
            for work in works:
                self._validate(work)
        with span("crs.transform_storage"):
            self._to_storage(works, source_crs)
        with span("measurement.compute"):
            self._measure(works, source_crs, plan, plan_error)
        return [self._finish(w, source_crs) for w in works]

    # ------------------------------------------------------------------ stages
    def _validate(self, work: _Work) -> None:
        geom = work.feature.geometry
        if geom is None:
            work.result = MeasurementResult.not_measurable("Feature has no geometry (NULL)")
            return
        if geom.is_empty:
            work.result = MeasurementResult.not_measurable("Geometry is empty")
            return
        if shapely.get_num_coordinates(geom) > self._max_vertices:
            work.result = MeasurementResult.failed(
                ErrorCode.GEOMETRY_TOO_COMPLEX,
                f"Geometry exceeds the configured limit of {self._max_vertices} vertices",
            )
            work.validity = ValidityStatus.NOT_CHECKED
            return
        check = self._validator.check(geom)
        work.check = check
        if check.geometry is None:
            code = check.error_code or ErrorCode.INVALID_GEOMETRY
            work.result = MeasurementResult.failed(code, check.message or "Invalid geometry")
            work.validity = ValidityStatus.INVALID
            return
        work.source_geom = check.geometry
        work.validity = ValidityStatus.REPAIRED if check.was_repaired else ValidityStatus.VALID

    def _to_storage(self, works: list[_Work], source_crs: CRS | None) -> None:
        pending = [w for w in works if w.source_geom is not None]
        if not pending or source_crs is None:
            return  # without a CRS the coordinates cannot be placed on the globe
        results = self._transformer.transform(_source_geoms(pending), source_crs, STORAGE_CRS)
        for work, geom in zip(pending, results, strict=True):
            if geom is None:
                work.result = MeasurementResult.failed(
                    ErrorCode.CRS_TRANSFORMATION_FAILED,
                    f"Geometry could not be transformed from {crs_code(source_crs)} to WGS 84",
                )
                work.source_geom = None
            else:
                work.storage_geom = geom

    def _measure(
        self,
        works: list[_Work],
        source_crs: CRS | None,
        plan: MeasurementPlan | None,
        plan_error: GeoMeasureError | None,
    ) -> None:
        groups: dict[int, list[_Work]] = {1: [], 2: []}
        for work in works:
            if work.result is not None or work.source_geom is None:
                continue
            dim = self._engine.dimension_of(work.source_geom.geom_type)
            if dim in groups:
                groups[dim].append(work)
            else:  # point-like (nothing to measure) or unsupported type
                work.result = self._safe_measure(work.source_geom, MeasurementContext("n/a"))

        for dim, group in groups.items():
            if group:
                self._measure_group(group, dim, source_crs, plan, plan_error)

    def _measure_group(
        self,
        group: list[_Work],
        dim: int,
        source_crs: CRS | None,
        plan: MeasurementPlan | None,
        plan_error: GeoMeasureError | None,
    ) -> None:
        if source_crs is None or plan is None:
            error = plan_error
            code = error.code if error else ErrorCode.CRS_UNKNOWN
            message = error.detail if error else "Source CRS is unknown; measurement refused"
            for work in group:
                work.result = MeasurementResult.failed(code, message)
            return

        target = plan.area_crs if dim == 2 else plan.length_crs
        if target is None:  # geodesic length on the WGS 84 ellipsoid
            context = MeasurementContext(STORAGE_CRS_CODE, CalculationMethod.GEODESIC)
            for work in group:
                work.result = (
                    self._safe_measure(work.storage_geom, context)
                    if work.storage_geom is not None
                    else MeasurementResult.failed(
                        ErrorCode.CRS_TRANSFORMATION_FAILED, "No WGS 84 geometry available"
                    )
                )
            return

        context = MeasurementContext(crs_code(target), CalculationMethod.PROJECTED_CRS)
        projected = self._transformer.transform(_source_geoms(group), source_crs, target)
        for work, geom in zip(group, projected, strict=True):
            work.result = (
                self._safe_measure(geom, context)
                if geom is not None
                else MeasurementResult.failed(
                    ErrorCode.CRS_TRANSFORMATION_FAILED,
                    f"Geometry could not be projected to {context.measurement_crs}",
                )
            )

    def _safe_measure(
        self, geom: BaseGeometry | None, context: MeasurementContext
    ) -> MeasurementResult:
        if geom is None:
            return MeasurementResult.failed(ErrorCode.MEASUREMENT_FAILED, "No geometry to measure")
        try:
            return self._engine.measure(geom, context)
        except Exception:
            logger.exception(
                "measurement_error", extra={"error_code": ErrorCode.MEASUREMENT_FAILED}
            )
            return MeasurementResult.failed(
                ErrorCode.MEASUREMENT_FAILED, "Unexpected measurement error"
            )

    # ------------------------------------------------------------------ output
    def _finish(self, work: _Work, source_crs: CRS | None) -> ProcessedFeature:
        feature = work.feature
        result = work.result or MeasurementResult.failed(
            ErrorCode.MEASUREMENT_FAILED, "Feature was not measured"
        )
        if feature.warnings:
            joined = "; ".join(feature.warnings)
            result = replace(
                result, warning=f"{result.warning}; {joined}" if result.warning else joined
            )
        check = work.check
        geometry = work.storage_geom
        geometry_type = (
            geometry.geom_type
            if geometry is not None
            else (
                work.source_geom.geom_type
                if work.source_geom is not None
                else feature.geometry_type
            )
        )
        return ProcessedFeature(
            feature_index=feature.feature_index,
            geometry_type=geometry_type,
            source_geometry_type=feature.source_geometry_type,
            properties=feature.properties,
            source_crs=crs_code(source_crs) if source_crs is not None else None,
            storage_crs=STORAGE_CRS_CODE,
            geometry=geometry,
            is_valid_before=check.is_valid_before if check else None,
            is_valid_after=check.is_valid_after if check else None,
            was_repaired=check.was_repaired if check else False,
            repair_method=check.repair_method if check else None,
            validity_status=work.validity,
            measurement=result,
        )
