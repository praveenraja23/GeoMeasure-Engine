"""Reader contract and the shared OGR-backed implementation."""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import geopandas as gpd
import pandas as pd
import pyogrio
import pyogrio.errors as ogr_errors
from pyproj import CRS
from pyproj.exceptions import CRSError

from app.core.exceptions import CorruptGeodataError
from app.domain.enums import FileType

Bounds = tuple[float, float, float, float]

_OGR_ERRORS = (
    ogr_errors.DataSourceError,
    ogr_errors.DataLayerError,
    ogr_errors.GeometryError,
    ogr_errors.FieldError,
    ogr_errors.FeatureError,
    UnicodeDecodeError,
)


@dataclass(frozen=True, slots=True)
class DatasetInfo:
    feature_count: int
    crs: CRS | None
    bounds: Bounds | None
    layers: tuple[str | None, ...]


@dataclass(frozen=True, slots=True)
class FeatureBatch:
    start_index: int
    frame: gpd.GeoDataFrame


class GeoFileReader(Protocol):
    """What the rest of the system sees; it never knows which format it is reading."""

    file_type: FileType

    def inspect(self, path: Path) -> DatasetInfo: ...

    def read(self, path: Path) -> gpd.GeoDataFrame: ...

    def read_batches(self, path: Path, batch_size: int) -> Iterator[FeatureBatch]: ...


class OgrReader(ABC):
    """pyogrio/GDAL implementation shared by Shapefile and KML."""

    file_type: FileType

    @abstractmethod
    def _layers(self, path: Path) -> list[str | None]:
        """Layer names to read, in order."""

    @abstractmethod
    def _declared_crs(self, layer_crs: CRS | None) -> CRS | None:
        """Apply format semantics to the CRS reported by GDAL."""

    def _read_kwargs(self) -> dict[str, object]:
        return {}

    def _postprocess(self, frame: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        return frame

    # ------------------------------------------------------------------ public
    def inspect(self, path: Path) -> DatasetInfo:
        layers = self._layers(path)
        total = 0
        crs: CRS | None = None
        bounds: Bounds | None = None
        try:
            for layer in layers:
                info = pyogrio.read_info(
                    path, layer=layer, force_feature_count=True, force_total_bounds=True
                )
                total += int(info["features"])
                crs = crs or self._declared_crs(_parse_crs(info.get("crs")))
                bounds = _union(bounds, info.get("total_bounds"))
        except _OGR_ERRORS as exc:
            raise CorruptGeodataError(f"Dataset could not be opened: {_short(exc)}") from exc
        return DatasetInfo(total, crs, bounds, tuple(layers))

    def read(self, path: Path) -> gpd.GeoDataFrame:
        frames = [batch.frame for batch in self.read_batches(path, batch_size=10**9)]
        if not frames:
            return gpd.GeoDataFrame(geometry=[])
        return gpd.GeoDataFrame(pd.concat(frames, ignore_index=True), crs=frames[0].crs)

    def read_batches(self, path: Path, batch_size: int) -> Iterator[FeatureBatch]:
        index = 0
        for layer in self._layers(path):
            try:
                total = int(
                    pyogrio.read_info(path, layer=layer, force_feature_count=True)["features"]
                )
            except _OGR_ERRORS as exc:
                raise CorruptGeodataError(f"Layer could not be read: {_short(exc)}") from exc
            offset = 0
            while offset < total:
                frame = self._read_window(path, layer, offset, min(batch_size, total - offset))
                if frame.empty:
                    break
                yield FeatureBatch(index, frame)
                index += len(frame)
                offset += len(frame)

    # ----------------------------------------------------------------- internals
    def _read_window(
        self, path: Path, layer: str | None, skip: int, limit: int
    ) -> gpd.GeoDataFrame:
        kwargs = {
            "layer": layer,
            "skip_features": skip,
            "max_features": limit,
            "force_2d": True,
            **self._read_kwargs(),
        }
        try:
            return self._postprocess(pyogrio.read_dataframe(path, **kwargs))
        except UnicodeDecodeError:
            # Legacy DBF files without a .cpg are usually Windows-1252, not UTF-8.
            return self._postprocess(pyogrio.read_dataframe(path, encoding="cp1252", **kwargs))
        except _OGR_ERRORS as exc:
            raise CorruptGeodataError(f"Features could not be read: {_short(exc)}") from exc


def _parse_crs(raw: str | None) -> CRS | None:
    if not raw:
        return None
    try:
        return CRS.from_user_input(raw)
    except CRSError:
        return None


def _union(current: Bounds | None, raw: object) -> Bounds | None:
    if raw is None:
        return current
    values = tuple(float(v) for v in raw)  # type: ignore[attr-defined]
    if len(values) != 4 or not all(math.isfinite(v) for v in values):
        return current
    if current is None:
        return values
    return (
        min(current[0], values[0]),
        min(current[1], values[1]),
        max(current[2], values[2]),
        max(current[3], values[3]),
    )


def _short(exc: Exception) -> str:
    return str(exc).splitlines()[0][:200] if str(exc) else exc.__class__.__name__
