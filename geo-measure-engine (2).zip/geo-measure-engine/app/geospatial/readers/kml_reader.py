from __future__ import annotations

from pathlib import Path

import geopandas as gpd
import pyogrio
import pyogrio.errors as ogr_errors
from pyproj import CRS

from app.core.exceptions import CorruptGeodataError
from app.domain.enums import FileType
from app.geospatial.readers.base import OgrReader

_WGS84 = CRS.from_epsg(4326)

# KML presentation attributes that GDAL's KML driver adds to every feature (with default
# values). They describe rendering, not data, so they are dropped. `id` and `description`
# are dropped only when empty; `Name` and any ExtendedData attributes are always kept.
_PRESENTATION_COLUMNS = (
    "timestamp",
    "begin",
    "end",
    "altitudeMode",
    "tessellate",
    "extrude",
    "visibility",
    "drawOrder",
    "icon",
)
_DROP_IF_EMPTY = ("id", "description")


class KMLReader(OgrReader):
    """Reads KML via GDAL's KML driver (every Folder/Document with placemarks is a layer).

    KML coordinates are *defined* as WGS 84 longitude, latitude[, altitude] by the OGC
    KML specification, so the source CRS is fixed to EPSG:4326 irrespective of what the
    driver reports. Only local files are opened: GDAL never dereferences
    ``NetworkLink`` elements.
    """

    file_type = FileType.KML

    def _layers(self, path: Path) -> list[str | None]:
        try:
            layers = pyogrio.list_layers(path)
        except (ogr_errors.DataSourceError, ogr_errors.DataLayerError) as exc:
            raise CorruptGeodataError(f"KML could not be opened: {exc}"[:240]) from exc
        names: list[str | None] = [str(row[0]) for row in layers]
        if not names:
            raise CorruptGeodataError("KML contains no feature layers (no Placemarks found)")
        return names

    def _declared_crs(self, layer_crs: CRS | None) -> CRS | None:
        return _WGS84

    def _postprocess(self, frame: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        drop = [c for c in _PRESENTATION_COLUMNS if c in frame.columns]
        drop += [c for c in _DROP_IF_EMPTY if c in frame.columns and frame[c].isna().all()]
        return frame.drop(columns=drop) if drop else frame
