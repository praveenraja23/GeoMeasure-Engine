from __future__ import annotations

from pathlib import Path

from pyproj import CRS

from app.domain.enums import FileType
from app.geospatial.readers.base import OgrReader


class ShapefileReader(OgrReader):
    """Reads a (securely extracted) ESRI Shapefile.

    The CRS comes only from the ``.prj`` sidecar. If it is missing or unparseable the
    CRS is reported as unknown (``None``); it is never defaulted to WGS 84.
    """

    file_type = FileType.SHAPEFILE

    def _layers(self, path: Path) -> list[str | None]:
        return [None]

    def _declared_crs(self, layer_crs: CRS | None) -> CRS | None:
        return layer_crs
