from __future__ import annotations

from app.domain.enums import FileType
from app.geospatial.readers.base import GeoFileReader
from app.geospatial.readers.kml_reader import KMLReader
from app.geospatial.readers.shapefile_reader import ShapefileReader


class GeoFileReaderFactory:
    def __init__(self) -> None:
        self._readers: dict[FileType, GeoFileReader] = {
            FileType.KML: KMLReader(),
            FileType.SHAPEFILE: ShapefileReader(),
        }

    def for_type(self, file_type: FileType) -> GeoFileReader:
        return self._readers[file_type]
