"""Vectorised coordinate transformation with per-geometry failure isolation."""

from __future__ import annotations

from collections.abc import Sequence
from functools import lru_cache

import numpy as np
import shapely
from pyproj import CRS, Transformer
from shapely.geometry.base import BaseGeometry

from app.geospatial.geometry.helpers import has_finite_coordinates


@lru_cache(maxsize=64)
def _transformer(source: CRS, target: CRS) -> Transformer:
    # always_xy: coordinates are (x=lon/easting, y=lat/northing) regardless of the
    # axis order a CRS definition declares (EPSG:4326 itself says lat/lon).
    return Transformer.from_crs(source, target, always_xy=True)


class GeometryTransformer:
    def transform(
        self, geometries: Sequence[BaseGeometry], source: CRS, target: CRS
    ) -> list[BaseGeometry | None]:
        """Transform ``geometries``; entries whose result is not finite become ``None``."""
        if not geometries:
            return []
        if source == target:
            return list(geometries)

        transformer = _transformer(source, target)
        array = np.empty(len(geometries), dtype=object)
        for i, geom in enumerate(geometries):
            array[i] = geom

        def apply(coords: np.ndarray) -> np.ndarray:
            x, y = transformer.transform(coords[:, 0], coords[:, 1])
            return np.column_stack((x, y))

        transformed = shapely.transform(array, apply)
        return [g if has_finite_coordinates(g) else None for g in transformed]
