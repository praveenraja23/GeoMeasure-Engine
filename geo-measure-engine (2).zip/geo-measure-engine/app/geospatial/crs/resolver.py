"""Selection of the CRS in which measurements are computed.

Planar area/length are only meaningful in a projected CRS with metre units.
Geographic coordinates are angular (degrees); ``geometry.area`` on them is
square degrees, which varies with latitude and is not a physical quantity.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

from pyproj import CRS, Transformer
from pyproj.aoi import AreaOfInterest
from pyproj.database import query_utm_crs_info

from app.core.exceptions import CRSTransformationError, MissingCRSError
from app.domain.enums import CalculationMethod

Bounds = tuple[float, float, float, float]

#: Global equal-area projection (WGS 84 / NSIDC EASE-Grid 2.0 Global, metres).
GLOBAL_EQUAL_AREA_EPSG = 6933
_UTM_LAT_MIN = -80.0
_UTM_LAT_MAX = 84.0


def crs_code(crs: CRS) -> str:
    """``EPSG:xxxx`` when the CRS is identifiable, else its (unregistered) name."""
    authority = crs.to_authority(min_confidence=70)
    return f"{authority[0]}:{authority[1]}" if authority else crs.name


@dataclass(frozen=True, slots=True)
class MeasurementPlan:
    """Outcome of CRS resolution for one dataset.

    ``length_crs is None`` means lengths are computed geodesically on the WGS 84
    ellipsoid (used only when no single projected CRS suits the extent).
    """

    source_crs: CRS
    area_crs: CRS
    length_crs: CRS | None
    strategy: str
    reason: str

    @property
    def length_method(self) -> CalculationMethod:
        return (
            CalculationMethod.GEODESIC
            if self.length_crs is None
            else CalculationMethod.PROJECTED_CRS
        )

    @property
    def units(self) -> str:
        return "metre"

    @property
    def primary_crs(self) -> CRS:
        return self.area_crs


class CRSResolutionStrategy(Protocol):
    """Replaceable component: swap in user-specified / equal-area / geodesic strategies."""

    def resolve(self, source: CRS | None, bounds: Bounds | None) -> MeasurementPlan: ...


class MeasurementCRSResolver:
    """Default strategy: use a metric source CRS as-is, otherwise a local UTM zone.

    Decision table
    --------------
    1. no source CRS                      -> ``MissingCRSError`` (never guessed)
    2. projected, metre, not Mercator     -> source CRS itself
    3. projected, non-metre (feet, ...)   -> reproject to local UTM
    4. projected but distorting (Mercator)-> reproject to local UTM
    5. geographic                         -> local UTM (same method as GeoPandas
                                             ``estimate_utm_crs``: centre of the extent)
    6. extent wider than one UTM zone, or
       outside 80°S–84°N                  -> area in EPSG:6933 (equal-area, metres) and
                                             lengths geodesic on WGS 84
    """

    def __init__(self, max_utm_lon_span_deg: float = 6.0) -> None:
        self._max_span = max_utm_lon_span_deg

    def resolve(self, source: CRS | None, bounds: Bounds | None) -> MeasurementPlan:
        if source is None:
            raise MissingCRSError(
                "The dataset does not declare a coordinate reference system "
                "(for a Shapefile: the .prj file is missing or unreadable)."
            )
        horizontal = self._horizontal(source)
        if horizontal.is_projected and self._is_metric(horizontal):
            if self._is_distorting(horizontal):
                prefix = f"Source CRS {crs_code(horizontal)} is a Mercator projection whose area/length distortion grows with latitude"
            else:
                return MeasurementPlan(
                    horizontal,
                    horizontal,
                    horizontal,
                    "source_projected_metre",
                    f"Source CRS {crs_code(horizontal)} is projected with metre units; used directly",
                )
        elif horizontal.is_projected:
            prefix = f"Source CRS {crs_code(horizontal)} is projected but not in metres"
        elif horizontal.is_geographic:
            prefix = f"Source CRS {crs_code(horizontal)} is geographic (angular units)"
        else:
            raise CRSTransformationError(
                f"CRS type of {crs_code(horizontal)} is not supported for measurement"
            )
        return self._derived_plan(horizontal, bounds, prefix)

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _horizontal(crs: CRS) -> CRS:
        if crs.is_bound:
            crs = crs.source_crs or crs
        if crs.is_compound:
            crs = crs.sub_crs_list[0]
        return crs

    @staticmethod
    def _is_metric(crs: CRS) -> bool:
        return all(math.isclose(axis.unit_conversion_factor, 1.0) for axis in crs.axis_info)

    @staticmethod
    def _is_distorting(crs: CRS) -> bool:
        operation = crs.coordinate_operation
        method = (operation.method_name if operation else "").lower()
        return "mercator" in method and "transverse" not in method and "oblique" not in method

    def _derived_plan(self, source: CRS, bounds: Bounds | None, prefix: str) -> MeasurementPlan:
        global_crs = CRS.from_epsg(GLOBAL_EQUAL_AREA_EPSG)
        if bounds is None:
            return MeasurementPlan(
                source, global_crs, None, "global_equal_area_geodesic",
                f"{prefix}; no valid extent available, using {crs_code(global_crs)} (area) and geodesic length",
            )  # fmt: skip
        west, south, east, north = self._bounds_wgs84(source, bounds)
        lon_span = east - west if east >= west else 360.0 - (west - east)
        if east < west or lon_span > self._max_span or south < _UTM_LAT_MIN or north > _UTM_LAT_MAX:
            return MeasurementPlan(
                source, global_crs, None, "global_equal_area_geodesic",
                f"{prefix}; extent spans {lon_span:.1f}° of longitude "
                f"(lat {south:.1f}..{north:.1f}), too broad for one UTM zone: area in "
                f"{crs_code(global_crs)} (equal-area), length geodesic on WGS 84",
            )  # fmt: skip
        centre_lon, centre_lat = (west + east) / 2, (south + north) / 2
        utm = self._utm_for(centre_lon, centre_lat)
        if utm is None:
            return MeasurementPlan(
                source, global_crs, None, "global_equal_area_geodesic",
                f"{prefix}; no UTM zone covers the extent centre, using {crs_code(global_crs)} and geodesic length",
            )  # fmt: skip
        return MeasurementPlan(
            source, utm, utm, "local_utm",
            f"{prefix}; estimated local UTM CRS {crs_code(utm)} from dataset bounds "
            f"(centre lon={centre_lon:.4f}, lat={centre_lat:.4f})",
        )  # fmt: skip

    @staticmethod
    def _utm_for(lon: float, lat: float) -> CRS | None:
        candidates = query_utm_crs_info(
            datum_name="WGS 84",
            area_of_interest=AreaOfInterest(
                west_lon_degree=lon, south_lat_degree=lat, east_lon_degree=lon, north_lat_degree=lat
            ),
        )
        return CRS.from_epsg(int(candidates[0].code)) if candidates else None

    @staticmethod
    def _bounds_wgs84(source: CRS, bounds: Bounds) -> Bounds:
        if not all(math.isfinite(v) for v in bounds):
            raise CRSTransformationError("Dataset extent contains non-finite coordinates")
        degrees = source.is_geographic and source.axis_info[0].unit_name == "degree"
        if degrees:
            west, south, east, north = bounds
        else:
            try:
                transformer = Transformer.from_crs(source, 4326, always_xy=True)
                west, south, east, north = transformer.transform_bounds(*bounds)
            except Exception as exc:
                raise CRSTransformationError(
                    "Dataset extent could not be transformed to WGS 84"
                ) from exc
        if not all(math.isfinite(v) for v in (west, south, east, north)):
            raise CRSTransformationError("Dataset extent could not be transformed to WGS 84")
        if west < -180.0001 or east > 180.0001 or south < -90.0001 or north > 90.0001:
            raise CRSTransformationError(
                "Dataset extent is outside the valid range of geographic coordinates"
            )
        return west, south, east, north
