from __future__ import annotations

import uuid
from typing import Any

from app.core.config import get_settings
from app.core.exceptions import RetryableProcessingError
from app.core.logging import request_id_var
from app.services.container import build_processing_service
from app.tasks.celery_app import celery_app

_settings = get_settings()


@celery_app.task(
    bind=True,
    name="geo_measure.process_geospatial_file",
    max_retries=_settings.task_max_retries,
)
def process_geospatial_file(
    self: Any, file_id: str, job_id: str | None = None, request_id: str | None = None
) -> dict[str, Any]:
    """Process one uploaded file. Retries only transient infrastructure failures.

    Validation/format/CRS problems are recorded on the file as FAILED and *not* retried:
    running them again can only produce the same result.
    """
    request_id_var.set(request_id)
    retries: int = self.request.retries
    try:
        outcome = build_processing_service().process(
            uuid.UUID(file_id),
            job_id=uuid.UUID(job_id) if job_id else None,
            attempt=retries + 1,
            is_final_attempt=retries >= self.max_retries,
        )
    except RetryableProcessingError as exc:
        backoff = min(
            _settings.task_retry_backoff_seconds * (2**retries),
            _settings.task_retry_backoff_max_seconds,
        )
        raise self.retry(exc=exc, countdown=backoff) from exc
    return outcome.as_dict()
