from __future__ import annotations

import logging
import os
from typing import Any

from celery import Celery
from celery.signals import setup_logging, worker_ready

from app.core.config import get_settings
from app.core.logging import configure_logging
from app.core.telemetry import setup_tracing

settings = get_settings()

celery_app = Celery(
    "geo_measure_engine",
    broker=settings.effective_broker_url,
    backend=settings.effective_result_backend,
    include=["app.tasks.processing_tasks"],
)
celery_app.conf.update(
    task_default_queue="geo_measure",
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    result_expires=3600,
    # A worker that dies mid-task causes redelivery; processing is idempotent, so that is safe.
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    worker_prefetch_multiplier=1,  # geospatial tasks are long and CPU/memory heavy
    task_soft_time_limit=settings.task_soft_time_limit_seconds,
    task_time_limit=settings.task_time_limit_seconds,
    task_always_eager=settings.celery_task_always_eager,
    task_eager_propagates=False,
    broker_connection_retry_on_startup=True,
    broker_transport_options={
        "socket_timeout": settings.redis_socket_timeout_seconds,
        "socket_connect_timeout": settings.redis_socket_timeout_seconds,
        "visibility_timeout": settings.task_time_limit_seconds + 300,
    },
    redis_socket_timeout=settings.redis_socket_timeout_seconds,
    redis_socket_connect_timeout=settings.redis_socket_timeout_seconds,
)


@setup_logging.connect
def _configure_logging(*_: Any, **__: Any) -> None:
    configure_logging(settings.log_level)  # replaces Celery's own logging setup
    setup_tracing(settings, service="worker")


@worker_ready.connect
def _start_metrics_server(*_: Any, **__: Any) -> None:
    if not settings.metrics_enabled or settings.worker_metrics_port == 0:
        return
    from prometheus_client import (  # noqa: PLC0415
        CollectorRegistry,
        multiprocess,
        start_http_server,
    )

    registry = None
    if os.environ.get("PROMETHEUS_MULTIPROC_DIR"):
        registry = CollectorRegistry()
        multiprocess.MultiProcessCollector(registry)  # type: ignore[no-untyped-call]  # prometheus_client ships this class untyped
    start_http_server(
        settings.worker_metrics_port, registry=registry
    ) if registry else start_http_server(settings.worker_metrics_port)
    logging.getLogger(__name__).info("worker_metrics_listening")
