"""RFC 9457 problem-details responses and exception handlers."""

from __future__ import annotations

import logging
from typing import Any, cast

from fastapi import FastAPI, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.config import get_settings
from app.core.exceptions import GeoMeasureError
from app.core.logging import request_id_var
from app.domain.enums import ErrorCode

logger = logging.getLogger(__name__)
PROBLEM_JSON = "application/problem+json"


def problem_response(
    request: Request,
    *,
    status: int,
    title: str,
    code: ErrorCode,
    detail: str | None = None,
    errors: list[dict[str, Any]] | None = None,
) -> JSONResponse:
    base = get_settings().problem_type_base_url.rstrip("/")
    body: dict[str, Any] = {
        "type": f"{base}/{code.value.lower().replace('_', '-')}",
        "title": title,
        "status": status,
        "detail": detail,
        "instance": request.url.path,
        "error_code": code.value,
        "request_id": request_id_var.get() or getattr(request.state, "request_id", None),
    }
    if errors:
        body["errors"] = errors
    return JSONResponse(jsonable_encoder(body), status_code=status, media_type=PROBLEM_JSON)


async def _geo_error(request: Request, exc: Exception) -> JSONResponse:
    exc = cast(GeoMeasureError, exc)
    logger.info(
        "request_rejected", extra={"error_code": exc.code.value, "status_code": exc.status_code}
    )
    return problem_response(
        request, status=exc.status_code, title=exc.title, code=exc.code, detail=exc.detail
    )


async def _validation_error(request: Request, exc: Exception) -> JSONResponse:
    exc = cast(RequestValidationError, exc)
    errors = [
        {"loc": [str(p) for p in e["loc"]], "msg": e["msg"], "type": e["type"]}
        for e in exc.errors()
    ]
    return problem_response(
        request,
        status=422,
        title="Invalid request",
        code=ErrorCode.INVALID_QUERY,
        detail="One or more request parameters are invalid.",
        errors=errors,
    )


async def _http_error(request: Request, exc: Exception) -> JSONResponse:
    exc = cast(StarletteHTTPException, exc)
    code = ErrorCode.FILE_NOT_FOUND if exc.status_code == 404 else ErrorCode.INVALID_QUERY
    title = {404: "Resource not found", 405: "Method not allowed"}.get(
        exc.status_code, "Request error"
    )
    return problem_response(
        request, status=exc.status_code, title=title, code=code, detail=str(exc.detail)
    )


async def _unhandled(request: Request, exc: Exception) -> JSONResponse:
    # Full stack goes to the logs only; the client never sees internals.
    logger.error("unhandled_exception", exc_info=exc)
    detail = f"{type(exc).__name__}" if get_settings().debug else "An unexpected error occurred."
    return problem_response(
        request,
        status=500,
        title="Internal server error",
        code=ErrorCode.INTERNAL_ERROR,
        detail=detail,
    )


def register_exception_handlers(app: FastAPI) -> None:
    app.add_exception_handler(GeoMeasureError, _geo_error)
    app.add_exception_handler(RequestValidationError, _validation_error)
    app.add_exception_handler(StarletteHTTPException, _http_error)
    app.add_exception_handler(Exception, _unhandled)
