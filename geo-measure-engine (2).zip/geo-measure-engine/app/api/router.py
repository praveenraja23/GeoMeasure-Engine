from fastapi import APIRouter

from app.api.v1 import features, files, jobs, measurements

api_router = APIRouter(prefix="/api")
v1_router = APIRouter(prefix="/v1")
# A future /api/v2 router can be mounted next to this one without touching handlers.
for module in (files, measurements, features, jobs):
    v1_router.include_router(module.router)
api_router.include_router(v1_router)
