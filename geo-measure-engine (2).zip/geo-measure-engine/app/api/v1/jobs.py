from __future__ import annotations

import uuid

from fastapi import APIRouter

from app.api.deps import FileServiceDep
from app.api.routing import problems, route
from app.schemas.job import JobResponse

router = APIRouter(prefix="/jobs", tags=["Jobs"])


@route(
    router,
    "GET",
    "/{job_id}",
    response_model=JobResponse,
    summary="Get processing job status and progress",
    description="`progress` is present only when real counts exist; it is updated at batch boundaries.",
    responses={**problems(404, 422)},
)
def get_job(job_id: uuid.UUID, service: FileServiceDep) -> JobResponse:
    return JobResponse.from_record(service.get_job(job_id))
