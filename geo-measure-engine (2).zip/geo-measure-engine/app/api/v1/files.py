from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, File, Response, UploadFile
from fastapi.responses import Response as RawResponse

from app.api.deps import FileServiceDep
from app.api.routing import problems, route
from app.core.logging import request_id_var
from app.schemas.file import FileResponse, FileUploadResponse

router = APIRouter(prefix="/files", tags=["Files"])


@route(
    router,
    "POST",
    "/",
    status_code=202,
    response_model=FileUploadResponse,
    summary="Upload a Shapefile ZIP or KML file",
    description=(
        "Accepts `multipart/form-data` with a `file` field (`.zip` containing one Shapefile, or `.kml`). "
        "The upload is validated (size, extension, content signature, ZIP safety, XML safety), stored under a "
        "UUID-derived name, hashed (SHA-256) and queued for asynchronous processing. Poll "
        "`GET /api/v1/files/{id}/` until `status` is `COMPLETED`, `PARTIALLY_COMPLETED` or `FAILED`."
    ),
    responses={**problems(400, 413, 415, 422, 503)},
)
def upload_file(
    file: Annotated[UploadFile, File(description="`.zip` (one Shapefile) or `.kml`")],
    service: FileServiceDep,
    response: Response,
) -> FileUploadResponse:
    record, job = service.ingest(
        stream=file.file,
        filename=file.filename,
        content_type=file.content_type,
        request_id=request_id_var.get(),
    )
    response.headers["Location"] = f"/api/v1/files/{record.id}/"
    return FileUploadResponse(
        id=record.id,
        filename=record.original_filename,
        file_type=record.file_type,
        file_size_bytes=record.file_size_bytes,
        sha256=record.sha256,
        status=record.status,
        job_id=job.id,
    )


@route(
    router,
    "GET",
    "/{file_id}/",
    response_model=FileResponse,
    summary="Get file information and processing status",
    description="Returns file metadata, processing status, feature counters and the CRS metadata "
    "(`source_crs`, `measurement_crs`, `crs_selection_reason`). `crs` is an alias of `source_crs`.",
    responses={**problems(404, 422)},
)
def get_file(file_id: uuid.UUID, service: FileServiceDep) -> FileResponse:
    record, job = service.get(file_id)
    return FileResponse.from_record(record, job)


@route(
    router,
    "DELETE",
    "/{file_id}/",
    status_code=204,
    response_class=RawResponse,
    summary="Delete a file and all derived data",
    description="Removes the file record, its features, measurements and jobs (one transaction) and then "
    "the stored upload. Returns 409 while the file is being processed.",
    responses={**problems(404, 409, 422)},
)
def delete_file(file_id: uuid.UUID, service: FileServiceDep) -> Response:
    service.delete(file_id)
    return Response(status_code=204)
