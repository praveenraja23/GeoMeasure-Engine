from __future__ import annotations

import logging
from typing import Any

import redis
from fastapi import APIRouter, Response
from fastapi.responses import JSONResponse
from sqlalchemy import text

from app.api.deps import SettingsDep
from app.core.metrics import render_metrics
from app.db.session import get_engine

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Health"])


@router.get("/health/live", summary="Liveness: is the process running?")
def live() -> dict[str, str]:
    """Deliberately dependency-free so a database blip never gets the pod restarted."""
    return {"status": "ok"}


@router.get(
    "/health/ready",
    summary="Readiness: can the service do useful work?",
    responses={503: {"description": "A required dependency is unavailable"}},
)
def ready(settings: SettingsDep) -> JSONResponse:
    checks: dict[str, Any] = {}
    try:
        with get_engine().connect() as conn:
            conn.execute(text("SELECT 1"))
            checks["database"] = "ok"
            checks["postgis"] = conn.execute(text("SELECT PostGIS_Lib_Version()")).scalar()
    except Exception:
        logger.warning("readiness_database_failed")
        checks["database"] = "unavailable"
    if settings.celery_task_always_eager:
        checks["redis"] = "skipped (eager mode)"
    else:
        try:
            client = redis.Redis.from_url(
                settings.effective_broker_url,
                socket_timeout=settings.redis_socket_timeout_seconds,
                socket_connect_timeout=settings.redis_socket_timeout_seconds,
            )
            client.ping()
            checks["redis"] = "ok"
        except Exception:
            logger.warning("readiness_redis_failed")
            checks["redis"] = "unavailable"
    healthy = checks.get("database") == "ok" and checks.get("redis") in {
        "ok",
        "skipped (eager mode)",
    }
    return JSONResponse(
        {"status": "ready" if healthy else "unavailable", "checks": checks},
        status_code=200 if healthy else 503,
    )


@router.get("/metrics", summary="Prometheus metrics (API process)", include_in_schema=True)
def metrics_endpoint() -> Response:
    body, content_type = render_metrics()
    return Response(body, media_type=content_type)
