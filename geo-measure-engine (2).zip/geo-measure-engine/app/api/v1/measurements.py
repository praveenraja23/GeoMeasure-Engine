from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Query

from app.api.deps import DbDep, FileServiceDep, PageDep
from app.api.routing import problems, route
from app.domain.enums import MeasurementStatus
from app.repositories.measurement_repository import MeasurementRepository
from app.schemas.common import GeometryTypeName
from app.schemas.measurement import MeasurementItem, MeasurementListResponse

router = APIRouter(prefix="/files", tags=["Measurements"])


@route(
    router,
    "GET",
    "/{file_id}/measurements/",
    response_model=MeasurementListResponse,
    summary="List per-feature measurements (paginated)",
    description=(
        "Polygons/MultiPolygons report `area_m2` and `area_hectares`; LineStrings/MultiLineStrings report "
        "`length_m` and `length_km`; Points report `NOT_REQUIRED` with null measurements. Values are computed in "
        "`measurement_crs` (metric), never in degrees. No geometry is returned here; use `/features` or `/geojson`."
    ),
    responses={**problems(404, 422)},
)
def list_measurements(
    file_id: uuid.UUID,
    files: FileServiceDep,
    session: DbDep,
    params: PageDep,
    measurement_status: Annotated[
        MeasurementStatus | None, Query(description="Filter by status")
    ] = None,
    geometry_type: Annotated[
        GeometryTypeName | None, Query(description="Filter by geometry type")
    ] = None,
) -> MeasurementListResponse:
    files.require(file_id)
    page = MeasurementRepository(session).page(file_id, params, measurement_status, geometry_type)
    return MeasurementListResponse(
        file_id=file_id,
        items=[MeasurementItem.from_row(r) for r in page.items],
        page=params.page,
        limit=params.limit,
        total=page.total,
        has_next=page.has_next,
    )
