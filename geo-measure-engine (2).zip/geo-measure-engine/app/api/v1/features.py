from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Query, Request

from app.api.deps import DbDep, FileServiceDep, FiltersDep, GeoJsonPageDep, PageDep
from app.api.routing import problems, route
from app.core.exceptions import InvalidQueryError
from app.repositories.feature_repository import FeatureRepository
from app.schemas.feature import (
    FeatureItem,
    FeatureListResponse,
    GeoJSONFeature,
    GeoJSONFeatureCollection,
    GeoJSONLink,
)
from app.utils.pagination import PageParams

router = APIRouter(prefix="/files", tags=["Features"])


@route(
    router,
    "GET",
    "/{file_id}/features",
    response_model=FeatureListResponse,
    summary="List features with geometry and attributes (paginated)",
    description="Geometry is GeoJSON in WGS 84 (lon/lat). Filter with `geometry_type` and/or `bbox` "
    "(`min_lon,min_lat,max_lon,max_lat`, PostGIS `ST_Intersects`).",
    responses={**problems(404, 422)},
)
def list_features(
    file_id: uuid.UUID,
    files: FileServiceDep,
    session: DbDep,
    params: PageDep,
    filters: FiltersDep,
    include_geometry: Annotated[bool, Query(description="Set false for attributes only")] = True,
) -> FeatureListResponse:
    files.require(file_id)
    page = FeatureRepository(session).page(file_id, filters, params, include_geometry)
    return FeatureListResponse(
        file_id=file_id,
        items=[FeatureItem.from_row(r) for r in page.items],
        page=params.page,
        limit=params.limit,
        total=page.total,
        has_next=page.has_next,
    )


@route(
    router,
    "GET",
    "/{file_id}/features/{feature_id}",
    response_model=FeatureItem,
    summary="Get one feature by its index",
    responses={**problems(404, 422)},
)
def get_feature(
    file_id: uuid.UUID, feature_id: int, files: FileServiceDep, session: DbDep
) -> FeatureItem:
    files.require(file_id)
    row = FeatureRepository(session).get_by_index(file_id, feature_id)
    if row is None:
        raise (
            InvalidQueryError(f"Feature {feature_id} does not exist in this file")
            if feature_id < 0
            else _missing(feature_id)
        )
    return FeatureItem.from_row(row)


def _missing(feature_id: int) -> Exception:
    from app.core.exceptions import FileRecordNotFoundError  # noqa: PLC0415

    return FileRecordNotFoundError(f"Feature {feature_id} does not exist in this file")


@route(
    router,
    "GET",
    "/{file_id}/geojson",
    response_model=GeoJSONFeatureCollection,
    response_model_exclude_none=False,
    summary="Export features as a GeoJSON FeatureCollection (paginated)",
    description="RFC 7946 GeoJSON, coordinates in WGS 84 lon/lat. `properties` are the original attributes. "
    "Paginated (`page`, `limit`) so the response size stays bounded; `links.next` points to the next page. "
    "Inspired by OGC API - Features; not an OGC-conformant implementation.",
    responses={**problems(404, 422)},
)
def geojson(
    request: Request,
    file_id: uuid.UUID,
    files: FileServiceDep,
    session: DbDep,
    params: GeoJsonPageDep,
    filters: FiltersDep,
) -> GeoJSONFeatureCollection:
    files.require(file_id)
    page = FeatureRepository(session).page(file_id, filters, params, include_geometry=True)
    features = [
        GeoJSONFeature(
            id=r.feature.feature_index, geometry=r.geometry_geojson, properties=r.feature.properties
        )
        for r in page.items
    ]
    links = [GeoJSONLink(rel="self", href=str(request.url))]
    if page.has_next:
        links.append(
            GeoJSONLink(
                rel="next",
                href=str(
                    request.url.include_query_params(page=params.page + 1, limit=params.limit)
                ),
            )
        )
    return GeoJSONFeatureCollection(
        features=features, numberMatched=page.total, numberReturned=len(features), links=links
    )


__all__ = ["PageParams", "router"]
