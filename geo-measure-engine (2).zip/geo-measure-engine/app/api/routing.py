from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeVar

from fastapi import APIRouter

from app.schemas.common import ProblemDetails

F = TypeVar("F", bound=Callable[..., Any])


def problems(*statuses: int) -> dict[int | str, dict[str, Any]]:
    """OpenAPI ``responses`` entries for RFC 9457 error bodies."""
    return {
        s: {"model": ProblemDetails, "content": {"application/problem+json": {}}} for s in statuses
    }


def route(router: APIRouter, method: str, path: str, **kwargs: Any) -> Callable[[F], F]:
    """Register ``path`` and its trailing-slash twin (the twin is hidden from OpenAPI).

    curl does not follow redirects by default, so both ``/files/{id}`` and ``/files/{id}/``
    must answer directly instead of relying on a 307.
    """

    def decorator(fn: F) -> F:
        router.add_api_route(path, fn, methods=[method], **kwargs)
        alt = path[:-1] if path.endswith("/") and len(path) > 1 else path + "/"
        twin = {
            k: v
            for k, v in kwargs.items()
            if k in {"response_model", "status_code", "response_class"}
        }
        router.add_api_route(alt, fn, methods=[method], include_in_schema=False, **twin)
        return fn

    return decorator
