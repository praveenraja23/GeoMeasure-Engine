from __future__ import annotations

from collections.abc import Iterator
from typing import Annotated

from fastapi import Depends, Query
from pydantic import ValidationError
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.core.exceptions import InvalidQueryError
from app.db.session import get_session_factory
from app.repositories.feature_repository import FeatureFilters
from app.schemas.common import BBox, GeometryTypeName
from app.services.container import get_storage
from app.services.file_service import FileService
from app.services.queue import CeleryJobQueue, JobQueue
from app.utils.pagination import PageParams

SettingsDep = Annotated[Settings, Depends(get_settings)]


def get_db() -> Iterator[Session]:
    session = get_session_factory()()
    try:
        yield session
    finally:
        session.close()


DbDep = Annotated[Session, Depends(get_db)]


def get_queue() -> JobQueue:
    return CeleryJobQueue()


def get_file_service(
    session: DbDep, settings: SettingsDep, queue: Annotated[JobQueue, Depends(get_queue)]
) -> FileService:
    return FileService(session, get_storage(), queue, settings)


FileServiceDep = Annotated[FileService, Depends(get_file_service)]


def page_params(
    settings: SettingsDep,
    page: Annotated[int, Query(description="1-based page number")] = 1,
    limit: Annotated[int | None, Query(description="Items per page")] = None,
) -> PageParams:
    return PageParams.validated(
        page, settings.default_page_size if limit is None else limit, settings.max_page_size
    )


def geojson_page_params(
    settings: SettingsDep,
    page: Annotated[int, Query(description="1-based page number")] = 1,
    limit: Annotated[int | None, Query(description="Features per page")] = None,
) -> PageParams:
    return PageParams.validated(
        page, settings.default_page_size if limit is None else limit, settings.max_geojson_page_size
    )


def feature_filters(
    geometry_type: Annotated[
        GeometryTypeName | None, Query(description="Exact geometry type")
    ] = None,
    bbox: Annotated[
        str | None,
        Query(
            description="WGS 84 `min_lon,min_lat,max_lon,max_lat`. Returns features that "
            "intersect the box (PostGIS ST_Intersects, GiST-assisted). Antimeridian-crossing "
            "boxes are rejected.",
            examples=["78.0,10.8,78.2,11.0"],
        ),
    ] = None,
) -> FeatureFilters:
    parsed: BBox | None = None
    if bbox:
        try:
            parsed = BBox.parse(bbox)
        except ValidationError as exc:
            message = str(exc.errors()[0]["msg"]).removeprefix("Value error, ")
            raise InvalidQueryError(f"Invalid bbox: {message}") from exc
        except ValueError as exc:
            raise InvalidQueryError(f"Invalid bbox: {exc}") from exc
    return FeatureFilters(geometry_type=geometry_type, bbox=parsed)


PageDep = Annotated[PageParams, Depends(page_params)]
GeoJsonPageDep = Annotated[PageParams, Depends(geojson_page_params)]
FiltersDep = Annotated[FeatureFilters, Depends(feature_filters)]
