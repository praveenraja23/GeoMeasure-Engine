from __future__ import annotations

from typing import Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

GeometryTypeName = Literal[
    "Point",
    "MultiPoint",
    "LineString",
    "MultiLineString",
    "Polygon",
    "MultiPolygon",
    "GeometryCollection",
    "Null",
]


class BBox(BaseModel):
    """WGS 84 bounding box ``min_lon,min_lat,max_lon,max_lat``.

    Boxes crossing the antimeridian (min_lon >= max_lon) are rejected in v1; query the
    two halves separately.
    """

    model_config = ConfigDict(frozen=True)

    min_lon: float = Field(ge=-180, le=180)
    min_lat: float = Field(ge=-90, le=90)
    max_lon: float = Field(ge=-180, le=180)
    max_lat: float = Field(ge=-90, le=90)

    @model_validator(mode="after")
    def _ordered(self) -> Self:
        if not self.min_lon < self.max_lon:
            raise ValueError(
                "min_lon must be less than max_lon (antimeridian-crossing boxes are not supported)"
            )
        if not self.min_lat < self.max_lat:
            raise ValueError("min_lat must be less than max_lat")
        return self

    @classmethod
    def parse(cls, raw: str) -> BBox:
        parts = [p.strip() for p in raw.split(",")]
        if len(parts) != 4:
            raise ValueError("bbox must have exactly four comma-separated numbers")
        try:
            min_lon, min_lat, max_lon, max_lat = (float(p) for p in parts)
        except ValueError as exc:
            raise ValueError("bbox values must be numbers") from exc
        return cls(min_lon=min_lon, min_lat=min_lat, max_lon=max_lon, max_lat=max_lat)


class ProblemDetails(BaseModel):
    """RFC 9457 problem details (``application/problem+json``)."""

    type: str = Field(examples=["https://geo-measure.example/problems/crs-unknown"])
    title: str = Field(examples=["Coordinate reference system could not be determined"])
    status: int = Field(examples=[422])
    detail: str | None = Field(
        default=None, examples=["The Shapefile does not contain a .prj file."]
    )
    instance: str | None = Field(default=None, examples=["/api/v1/files/"])
    error_code: str = Field(examples=["CRS_UNKNOWN"])
    request_id: str | None = None
    errors: list[dict[str, Any]] | None = None
