from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.db.models import FileRecord, ProcessingJob
from app.domain.enums import FileStatus, FileType


class FileUploadResponse(BaseModel):
    """Returned with 202 Accepted: processing continues asynchronously."""

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "id": "6f1c0a52-3c1e-4b0f-9d6e-0d2f2f6b6a11",
                    "filename": "sample.kml",
                    "file_type": "KML",
                    "file_size_bytes": 2759,
                    "sha256": "9b0c…",
                    "status": "QUEUED",
                    "job_id": "0c1d6f34-8a0e-4a39-8d36-5e2b1f9a7c42",
                }
            ]
        }
    )

    id: uuid.UUID
    filename: str = Field(description="Original upload name (metadata only).")
    file_type: FileType
    file_size_bytes: int
    sha256: str
    status: FileStatus
    job_id: uuid.UUID


class FileResponse(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "id": "6f1c0a52-3c1e-4b0f-9d6e-0d2f2f6b6a11",
                    "filename": "sample.kml",
                    "file_type": "KML",
                    "file_size_bytes": 2759,
                    "sha256": "9b0c…",
                    "status": "COMPLETED",
                    "feature_count": 7,
                    "successful_feature_count": 7,
                    "failed_feature_count": 0,
                    "crs": "EPSG:4326",
                    "source_crs": "EPSG:4326",
                    "source_crs_name": "WGS 84",
                    "measurement_crs": "EPSG:32644",
                    "measurement_crs_name": "WGS 84 / UTM zone 44N",
                    "measurement_units": "metre",
                    "crs_selection_reason": "Source CRS EPSG:4326 is geographic (angular units); estimated local UTM CRS EPSG:32644 from dataset bounds",
                    "created_at": "2026-10-08T10:00:00Z",
                    "processing_duration_ms": 842,
                }
            ]
        }
    )

    id: uuid.UUID
    filename: str = Field(description="Original upload name.")
    file_type: FileType
    file_size_bytes: int
    sha256: str
    status: FileStatus
    feature_count: int
    successful_feature_count: int
    failed_feature_count: int
    crs: str | None = Field(description="Alias of source_crs (assignment-compatible field).")
    source_crs: str | None
    source_crs_name: str | None
    measurement_crs: str | None
    measurement_crs_name: str | None
    measurement_units: str | None
    crs_selection_reason: str | None
    created_at: datetime
    updated_at: datetime
    processing_started_at: datetime | None
    processing_completed_at: datetime | None
    processing_duration_ms: int | None
    error_code: str | None
    error_message: str | None
    job_id: uuid.UUID | None

    @classmethod
    def from_record(cls, record: FileRecord, job: ProcessingJob | None) -> FileResponse:
        duration = None
        if record.processing_started_at and record.processing_completed_at:
            delta = record.processing_completed_at - record.processing_started_at
            duration = int(delta.total_seconds() * 1000)
        return cls(
            id=record.id,
            filename=record.original_filename,
            file_type=record.file_type,
            file_size_bytes=record.file_size_bytes,
            sha256=record.sha256,
            status=record.status,
            feature_count=record.feature_count,
            successful_feature_count=record.successful_feature_count,
            failed_feature_count=record.failed_feature_count,
            crs=record.source_crs,
            source_crs=record.source_crs,
            source_crs_name=record.source_crs_name,
            measurement_crs=record.measurement_crs,
            measurement_crs_name=record.measurement_crs_name,
            measurement_units=record.measurement_units,
            crs_selection_reason=record.crs_selection_reason,
            created_at=record.created_at,
            updated_at=record.updated_at,
            processing_started_at=record.processing_started_at,
            processing_completed_at=record.processing_completed_at,
            processing_duration_ms=duration,
            error_code=record.error_code,
            error_message=record.error_message,
            job_id=job.id if job else None,
        )
