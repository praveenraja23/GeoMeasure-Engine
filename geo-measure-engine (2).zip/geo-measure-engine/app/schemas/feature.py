from __future__ import annotations

import uuid
from typing import Any, Literal

from pydantic import BaseModel, Field

from app.repositories.feature_repository import FeatureRow


class FeatureItem(BaseModel):
    feature_id: int = Field(description="Zero-based feature index within the file.")
    geometry_type: str
    source_geometry_type: str | None
    source_crs: str | None
    storage_crs: str = Field(description="CRS of `geometry` (always EPSG:4326, lon/lat).")
    properties: dict[str, Any]
    geometry: dict[str, Any] | None = Field(description="GeoJSON geometry in WGS 84, or null.")
    is_valid_before: bool | None
    is_valid_after: bool | None
    was_repaired: bool
    repair_method: str | None

    @classmethod
    def from_row(cls, row: FeatureRow) -> FeatureItem:
        f = row.feature
        return cls(
            feature_id=f.feature_index,
            geometry_type=f.geometry_type,
            source_geometry_type=f.source_geometry_type,
            source_crs=f.source_crs,
            storage_crs=f.storage_crs,
            properties=f.properties,
            geometry=row.geometry_geojson,
            is_valid_before=f.is_valid_before,
            is_valid_after=f.is_valid_after,
            was_repaired=f.was_repaired,
            repair_method=f.repair_method,
        )


class FeatureListResponse(BaseModel):
    file_id: uuid.UUID
    items: list[FeatureItem]
    page: int
    limit: int
    total: int
    has_next: bool


class GeoJSONFeature(BaseModel):
    type: Literal["Feature"] = "Feature"
    id: int
    geometry: dict[str, Any] | None
    properties: dict[str, Any]


class GeoJSONLink(BaseModel):
    rel: str
    href: str
    type: str = "application/geo+json"


class GeoJSONFeatureCollection(BaseModel):
    """GeoJSON (RFC 7946) FeatureCollection in WGS 84 lon/lat.

    ``numberMatched`` / ``numberReturned`` / ``links`` are foreign members inspired by
    OGC API - Features. This is *not* an OGC-conformant implementation.
    """

    type: Literal["FeatureCollection"] = "FeatureCollection"
    features: list[GeoJSONFeature]
    numberMatched: int
    numberReturned: int
    links: list[GeoJSONLink]
