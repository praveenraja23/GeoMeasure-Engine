from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict

from app.db.models import ProcessingJob
from app.domain.enums import JobStatus


class JobProgress(BaseModel):
    processed_features: int
    total_features: int


class JobResponse(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "id": "0c1d6f34-8a0e-4a39-8d36-5e2b1f9a7c42",
                    "file_id": "6f1c0a52-3c1e-4b0f-9d6e-0d2f2f6b6a11",
                    "status": "PROCESSING",
                    "attempt": 1,
                    "progress": {"processed_features": 1000, "total_features": 5000},
                }
            ]
        }
    )

    id: uuid.UUID
    file_id: uuid.UUID
    status: JobStatus
    attempt: int
    started_at: datetime | None
    completed_at: datetime | None
    duration_ms: int | None
    error_code: str | None
    error_message: str | None
    progress: JobProgress | None = None  # only when real batch counts exist

    @classmethod
    def from_record(cls, job: ProcessingJob) -> JobResponse:
        progress = None
        if job.total_features is not None and job.processed_features is not None:
            progress = JobProgress(
                processed_features=job.processed_features, total_features=job.total_features
            )
        return cls(
            id=job.id,
            file_id=job.file_id,
            status=job.status,
            attempt=job.attempt,
            started_at=job.started_at,
            completed_at=job.completed_at,
            duration_ms=job.duration_ms,
            error_code=job.error_code,
            error_message=job.error_message,
            progress=progress,
        )
