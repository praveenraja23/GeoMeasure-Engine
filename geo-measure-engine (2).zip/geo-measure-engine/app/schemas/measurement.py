from __future__ import annotations

import uuid

from pydantic import BaseModel, ConfigDict, Field

from app.domain.enums import MeasurementStatus, ValidityStatus
from app.repositories.measurement_repository import MeasurementRow


class MeasurementItem(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "feature_id": 2,
                    "geometry_type": "Polygon",
                    "measurement_status": "COMPLETED",
                    "area_m2": 1211395.131,
                    "area_hectares": 121.1395131,
                    "length_m": None,
                    "length_km": None,
                    "measurement_crs": "EPSG:32644",
                    "calculation_method": "projected_crs",
                    "validity_status": "VALID",
                    "was_geometry_repaired": False,
                    "warning": None,
                    "error_code": None,
                }
            ]
        }
    )

    feature_id: int = Field(description="Zero-based feature index within the file.")
    geometry_type: str
    measurement_status: MeasurementStatus
    area_m2: float | None
    area_hectares: float | None
    length_m: float | None
    length_km: float | None
    measurement_crs: str | None
    calculation_method: str | None
    validity_status: ValidityStatus
    was_geometry_repaired: bool
    warning: str | None
    error_code: str | None

    @classmethod
    def from_row(cls, row: MeasurementRow) -> MeasurementItem:
        m = row.measurement
        return cls(
            feature_id=row.feature_index,
            geometry_type=row.geometry_type,
            measurement_status=m.measurement_status,
            area_m2=m.area_m2,
            area_hectares=m.area_hectares,
            length_m=m.length_m,
            length_km=m.length_km,
            measurement_crs=m.measurement_crs,
            calculation_method=m.calculation_method,
            validity_status=m.validity_status,
            was_geometry_repaired=row.was_repaired,
            warning=m.warning,
            error_code=m.error_code,
        )


class MeasurementListResponse(BaseModel):
    file_id: uuid.UUID
    items: list[MeasurementItem]
    page: int
    limit: int
    total: int
    has_next: bool
