from __future__ import annotations

import uuid

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.db.models import ProcessingJob
from app.domain.enums import JobStatus


class JobRepository:
    def __init__(self, session: Session) -> None:
        self._s = session

    def create(self, file_id: uuid.UUID) -> ProcessingJob:
        job = ProcessingJob(id=uuid.uuid4(), file_id=file_id, status=JobStatus.QUEUED, attempt=0)
        self._s.add(job)
        self._s.flush()
        return job

    def get(self, job_id: uuid.UUID) -> ProcessingJob | None:
        return self._s.get(ProcessingJob, job_id)

    def latest_for_file(self, file_id: uuid.UUID) -> ProcessingJob | None:
        return self._s.scalars(
            select(ProcessingJob)
            .where(ProcessingJob.file_id == file_id)
            .order_by(ProcessingJob.created_at.desc())
            .limit(1)
        ).first()

    def update(self, job_id: uuid.UUID, **values: object) -> None:
        self._s.execute(update(ProcessingJob).where(ProcessingJob.id == job_id).values(**values))
