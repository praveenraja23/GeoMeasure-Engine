from __future__ import annotations

import json
import uuid
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

from geoalchemy2.shape import from_shape
from sqlalchemy import Select, func, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from app.db.models import FeatureRecord
from app.geospatial.pipeline import ProcessedFeature
from app.schemas.common import BBox
from app.utils.pagination import Page, PageParams

_UPDATABLE = (
    "geometry_type",
    "source_geometry_type",
    "properties",
    "source_crs",
    "storage_crs",
    "geometry",
    "is_valid_before",
    "is_valid_after",
    "was_repaired",
    "repair_method",
)


def feature_uuid(file_id: uuid.UUID, feature_index: int) -> uuid.UUID:
    """Deterministic id: re-processing the same file yields the same primary keys."""
    return uuid.uuid5(file_id, f"feature:{feature_index}")


@dataclass(frozen=True, slots=True)
class FeatureFilters:
    geometry_type: str | None = None
    bbox: BBox | None = None


@dataclass(frozen=True, slots=True)
class FeatureRow:
    feature: FeatureRecord
    geometry_geojson: dict[str, Any] | None


class FeatureRepository:
    def __init__(self, session: Session) -> None:
        self._s = session

    def upsert_batch(self, file_id: uuid.UUID, items: Sequence[ProcessedFeature]) -> None:
        """Idempotent bulk write keyed on (file_id, feature_index)."""
        if not items:
            return
        rows = [
            {
                "id": feature_uuid(file_id, item.feature_index),
                "file_id": file_id,
                "feature_index": item.feature_index,
                "geometry_type": item.geometry_type,
                "source_geometry_type": item.source_geometry_type,
                "properties": item.properties,
                "source_crs": item.source_crs,
                "storage_crs": item.storage_crs,
                "geometry": from_shape(item.geometry, srid=4326)
                if item.geometry is not None
                else None,
                "is_valid_before": item.is_valid_before,
                "is_valid_after": item.is_valid_after,
                "was_repaired": item.was_repaired,
                "repair_method": item.repair_method,
            }
            for item in items
        ]
        stmt = pg_insert(FeatureRecord)
        stmt = stmt.on_conflict_do_update(
            constraint="uq_features_file_id_feature_index",
            set_={col: stmt.excluded[col] for col in _UPDATABLE},
        )
        self._s.execute(stmt, rows)

    # ------------------------------------------------------------------ queries
    def _filtered(
        self, stmt: Select[*tuple[Any, ...]], file_id: uuid.UUID, filters: FeatureFilters
    ) -> Select[*tuple[Any, ...]]:
        stmt = stmt.where(FeatureRecord.file_id == file_id)
        if filters.geometry_type:
            stmt = stmt.where(FeatureRecord.geometry_type == filters.geometry_type)
        if filters.bbox:
            b = filters.bbox
            # ST_Intersects against an envelope is index-assisted (&& on the GiST index).
            stmt = stmt.where(
                func.ST_Intersects(
                    FeatureRecord.geometry,
                    func.ST_MakeEnvelope(b.min_lon, b.min_lat, b.max_lon, b.max_lat, 4326),
                )
            )
        return stmt

    def page(
        self,
        file_id: uuid.UUID,
        filters: FeatureFilters,
        params: PageParams,
        include_geometry: bool,
    ) -> Page[FeatureRow]:
        total = (
            self._s.scalar(
                self._filtered(select(func.count()).select_from(FeatureRecord), file_id, filters)
            )
            or 0
        )
        # ST_ForcePolygonCCW: RFC 7946 expects counter-clockwise exterior rings.
        geojson = func.ST_AsGeoJSON(func.ST_ForcePolygonCCW(FeatureRecord.geometry), 9)
        columns: list[Any] = [FeatureRecord]
        if include_geometry:
            columns.append(geojson.label("geojson"))
        stmt = (
            self._filtered(select(*columns), file_id, filters)
            .order_by(FeatureRecord.feature_index)
            .offset(params.offset)
            .limit(params.limit)
        )
        rows = self._s.execute(stmt).all()
        items = [
            FeatureRow(r[0], json.loads(r[1]) if include_geometry and r[1] else None) for r in rows
        ]
        return Page(items, total, params)

    def get_by_index(self, file_id: uuid.UUID, feature_index: int) -> FeatureRow | None:
        geojson = func.ST_AsGeoJSON(func.ST_ForcePolygonCCW(FeatureRecord.geometry), 9)
        row = self._s.execute(
            select(FeatureRecord, geojson.label("geojson")).where(
                FeatureRecord.file_id == file_id, FeatureRecord.feature_index == feature_index
            )
        ).first()
        if row is None:
            return None
        return FeatureRow(row[0], json.loads(row[1]) if row[1] else None)
