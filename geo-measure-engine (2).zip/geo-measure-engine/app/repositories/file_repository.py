from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import delete, select, update
from sqlalchemy.orm import Session

from app.db.models import FileRecord, ProcessingJob


class FileRepository:
    def __init__(self, session: Session) -> None:
        self._s = session

    def add(self, record: FileRecord) -> FileRecord:
        self._s.add(record)
        self._s.flush()
        return record

    def get(self, file_id: uuid.UUID) -> FileRecord | None:
        return self._s.get(FileRecord, file_id)

    def get_with_latest_job(
        self, file_id: uuid.UUID
    ) -> tuple[FileRecord, ProcessingJob | None] | None:
        record = self.get(file_id)
        if record is None:
            return None
        job = self._s.scalars(
            select(ProcessingJob)
            .where(ProcessingJob.file_id == file_id)
            .order_by(ProcessingJob.created_at.desc())
            .limit(1)
        ).first()
        return record, job

    def update(self, file_id: uuid.UUID, **values: object) -> None:
        self._s.execute(update(FileRecord).where(FileRecord.id == file_id).values(**values))

    def delete(self, file_id: uuid.UUID) -> None:
        # ON DELETE CASCADE removes jobs, features and measurements in one statement.
        self._s.execute(delete(FileRecord).where(FileRecord.id == file_id))

    def older_than(self, cutoff: datetime, limit: int = 1000) -> list[FileRecord]:
        return list(
            self._s.scalars(
                select(FileRecord)
                .where(FileRecord.created_at < cutoff)
                .order_by(FileRecord.created_at)
                .limit(limit)
            )
        )
