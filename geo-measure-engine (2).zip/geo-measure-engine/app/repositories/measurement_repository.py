from __future__ import annotations

import uuid
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

from sqlalchemy import Select, func, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from app.db.models import FeatureRecord, MeasurementRecord
from app.domain.enums import SUCCESSFUL_MEASUREMENT_STATUSES, MeasurementStatus
from app.geospatial.pipeline import ProcessedFeature
from app.repositories.feature_repository import feature_uuid
from app.utils.pagination import Page, PageParams

_UPDATABLE = (
    "file_id",
    "measurement_status",
    "area_m2",
    "area_hectares",
    "length_m",
    "length_km",
    "measurement_crs",
    "calculation_method",
    "validity_status",
    "warning",
    "error_code",
)


@dataclass(frozen=True, slots=True)
class MeasurementRow:
    measurement: MeasurementRecord
    feature_index: int
    geometry_type: str
    was_repaired: bool


@dataclass(frozen=True, slots=True)
class FeatureCounts:
    total: int
    successful: int
    failed: int
    top_error_code: str | None


class MeasurementRepository:
    def __init__(self, session: Session) -> None:
        self._s = session

    def upsert_batch(self, file_id: uuid.UUID, items: Sequence[ProcessedFeature]) -> None:
        if not items:
            return
        rows = []
        for item in items:
            m = item.measurement
            feature_id = feature_uuid(file_id, item.feature_index)
            rows.append(
                {
                    "id": uuid.uuid5(file_id, f"measurement:{item.feature_index}"),
                    "feature_id": feature_id,
                    "file_id": file_id,
                    "measurement_status": m.status,
                    "area_m2": m.area_m2,
                    "area_hectares": m.area_hectares,
                    "length_m": m.length_m,
                    "length_km": m.length_km,
                    "measurement_crs": m.measurement_crs,
                    "calculation_method": m.calculation_method.value
                    if m.calculation_method
                    else None,
                    "validity_status": item.validity_status,
                    "warning": m.warning,
                    "error_code": m.error_code.value if m.error_code else None,
                }
            )
        stmt = pg_insert(MeasurementRecord)
        stmt = stmt.on_conflict_do_update(
            index_elements=[MeasurementRecord.feature_id],
            set_={col: stmt.excluded[col] for col in _UPDATABLE},
        )
        self._s.execute(stmt, rows)

    def _filtered(
        self,
        stmt: Select[*tuple[Any, ...]],
        file_id: uuid.UUID,
        status: MeasurementStatus | None,
        geometry_type: str | None,
    ) -> Select[*tuple[Any, ...]]:
        stmt = stmt.where(MeasurementRecord.file_id == file_id)
        if status:
            stmt = stmt.where(MeasurementRecord.measurement_status == status)
        if geometry_type:
            stmt = stmt.where(FeatureRecord.geometry_type == geometry_type)
        return stmt

    def page(
        self,
        file_id: uuid.UUID,
        params: PageParams,
        status: MeasurementStatus | None = None,
        geometry_type: str | None = None,
    ) -> Page[MeasurementRow]:
        join = MeasurementRecord.feature_id == FeatureRecord.id
        count_stmt = select(func.count()).select_from(MeasurementRecord).join(FeatureRecord, join)
        total = self._s.scalar(self._filtered(count_stmt, file_id, status, geometry_type)) or 0
        stmt = (
            select(
                MeasurementRecord,
                FeatureRecord.feature_index,
                FeatureRecord.geometry_type,
                FeatureRecord.was_repaired,
            )
            .join(FeatureRecord, join)
            .order_by(FeatureRecord.feature_index)
            .offset(params.offset)
            .limit(params.limit)
        )
        rows = self._s.execute(self._filtered(stmt, file_id, status, geometry_type)).all()
        return Page([MeasurementRow(r[0], r[1], r[2], r[3]) for r in rows], total, params)

    def counts(self, file_id: uuid.UUID) -> FeatureCounts:
        """Authoritative counters, derived from persisted rows (never from in-memory tallies)."""
        by_status = dict(
            self._s.execute(
                select(MeasurementRecord.measurement_status, func.count())
                .where(MeasurementRecord.file_id == file_id)
                .group_by(MeasurementRecord.measurement_status)
            ).all()
        )
        total = sum(by_status.values())
        successful = sum(n for s, n in by_status.items() if s in SUCCESSFUL_MEASUREMENT_STATUSES)
        top = self._s.execute(
            select(MeasurementRecord.error_code, func.count().label("n"))
            .where(MeasurementRecord.file_id == file_id, MeasurementRecord.error_code.is_not(None))
            .group_by(MeasurementRecord.error_code)
            .order_by(func.count().desc())
            .limit(1)
        ).first()
        return FeatureCounts(total, successful, total - successful, top[0] if top else None)
