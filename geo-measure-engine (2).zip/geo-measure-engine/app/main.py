from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api.errors import register_exception_handlers
from app.api.router import api_router
from app.api.v1 import health
from app.core.config import get_settings
from app.core.logging import configure_logging
from app.core.middleware import RequestContextMiddleware
from app.core.telemetry import setup_tracing
from app.db.session import reset_engine

DESCRIPTION = """
**GeoMeasure Engine** ingests Shapefile (`.zip`) and KML files, resolves a *metric* coordinate
system, and returns per-feature area/length.

### Try it
1. `POST /api/v1/files/` — choose a file (e.g. `sample_data/sample.kml`) → **202**, copy the `id`.
2. `GET /api/v1/files/{id}/` — wait for `status` = `COMPLETED`.
3. `GET /api/v1/files/{id}/measurements/` — areas (m², ha) and lengths (m, km).
4. `GET /api/v1/files/{id}/features` or `/geojson` — geometry and attributes (WGS 84).

Areas and lengths are **never** computed from latitude/longitude degrees.
Errors are RFC 9457 `application/problem+json` with a stable `error_code`.
"""

TAGS = [
    {"name": "Files", "description": "Upload and inspect geospatial files"},
    {"name": "Measurements", "description": "Per-feature area and length"},
    {"name": "Features", "description": "Geometry, attributes, spatial filtering, GeoJSON"},
    {"name": "Jobs", "description": "Asynchronous processing jobs"},
    {"name": "Health", "description": "Liveness, readiness and metrics"},
]


@asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    yield
    reset_engine()


def create_app() -> FastAPI:
    settings = get_settings()
    configure_logging(settings.log_level)
    app = FastAPI(
        title=settings.app_name,
        version="1.0.0",
        description=DESCRIPTION,
        openapi_tags=TAGS,
        debug=settings.debug,
        lifespan=lifespan,
    )
    app.add_middleware(RequestContextMiddleware)
    register_exception_handlers(app)
    app.include_router(health.router)
    app.include_router(api_router)
    setup_tracing(settings, service="api", app=app)
    return app


app = create_app()
