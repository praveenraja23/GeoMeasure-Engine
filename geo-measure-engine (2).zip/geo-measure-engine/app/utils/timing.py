from __future__ import annotations

import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass


@dataclass(slots=True)
class Stopwatch:
    started: float
    elapsed_ms: int = 0


@contextmanager
def stopwatch() -> Iterator[Stopwatch]:
    watch = Stopwatch(time.perf_counter())
    try:
        yield watch
    finally:
        watch.elapsed_ms = int((time.perf_counter() - watch.started) * 1000)
