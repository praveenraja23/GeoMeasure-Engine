"""Validation of untrusted uploads: names, ZIP structure, KML content.

Everything here operates on files already streamed to disk. Nothing is executed or
resolved over the network; XML is parsed with defusedxml with DTDs/entities forbidden.
"""

from __future__ import annotations

import re
import stat
import struct
import zipfile
from dataclasses import dataclass
from pathlib import Path

from defusedxml import DefusedXmlException
from defusedxml import ElementTree as SafeET

from app.core.exceptions import (
    CorruptGeodataError,
    InvalidArchiveError,
    MissingShapefileComponentError,
    MultipleShapefilesError,
    UnsafeArchiveError,
    UnsafeContentError,
    UnsupportedFileTypeError,
)
from app.domain.enums import FileType

ALLOWED_CONTENT_TYPES: dict[FileType, frozenset[str]] = {
    FileType.SHAPEFILE: frozenset(
        {
            "application/zip",
            "application/x-zip-compressed",
            "application/x-zip",
            "application/octet-stream",
        }
    ),
    FileType.KML: frozenset(
        {
            "application/vnd.google-earth.kml+xml",
            "application/xml",
            "text/xml",
            "application/octet-stream",
        }
    ),
}
_EXTENSIONS = {".zip": FileType.SHAPEFILE, ".kml": FileType.KML}

REQUIRED_SHAPEFILE_PARTS = ("shp", "shx", "dbf")
ALLOWED_SHAPEFILE_PARTS = frozenset(
    {"shp", "shx", "dbf", "prj", "cpg", "qpj", "sbn", "sbx", "shp.xml"}
)
_IGNORED_BASENAMES = frozenset({".ds_store", "thumbs.db"})
_RATIO_CHECK_MIN_BYTES = 1024 * 1024  # tiny entries legitimately compress very well
_SHP_FILE_CODE = 9994
_WINDOWS_DRIVE = re.compile(r"^[A-Za-z]:")


def detect_file_type(filename: str, content_type: str | None) -> FileType:
    """Extension decides the candidate type; Content-Type may only contradict, never confirm."""
    suffix = Path(filename.replace("\\", "/")).suffix.lower()
    file_type = _EXTENSIONS.get(suffix)
    if file_type is None:
        raise UnsupportedFileTypeError("Only .zip (Shapefile) and .kml uploads are supported")
    declared = (content_type or "").split(";")[0].strip().lower()
    if declared and declared not in ALLOWED_CONTENT_TYPES[file_type]:
        raise UnsupportedFileTypeError(
            f"Content-Type '{declared}' is not valid for a {suffix} upload"
        )
    return file_type


@dataclass(frozen=True, slots=True)
class ArchiveLimits:
    max_entries: int
    max_extracted_bytes: int
    max_compression_ratio: int


@dataclass(frozen=True, slots=True)
class ShapefileArchive:
    members: dict[str, str]  # component extension -> archive member name


def _split_ext(basename: str) -> tuple[str, str]:
    lower = basename.lower()
    if lower.endswith(".shp.xml"):
        return lower[: -len(".shp.xml")], "shp.xml"
    stem, dot, ext = lower.rpartition(".")
    return (stem, ext) if dot else (lower, "")


def _safe_parts(name: str) -> list[str]:
    if "\x00" in name:
        raise UnsafeArchiveError("Archive entry name contains a NUL byte")
    normalised = name.replace("\\", "/")
    if normalised.startswith("/") or _WINDOWS_DRIVE.match(normalised):
        raise UnsafeArchiveError("Archive contains an absolute path")
    parts = [p for p in normalised.split("/") if p not in ("", ".")]
    if ".." in parts:
        raise UnsafeArchiveError("Archive contains a path-traversal entry ('..')")
    return parts


def _check_entry_with_limits(
    info: zipfile.ZipInfo, seen: set[str], limits: ArchiveLimits
) -> tuple[list[str], str, str] | None:
    """Validate one entry. Returns ``(parts, stem, ext)`` for Shapefile members, else None."""
    parts = _safe_parts(info.filename)
    if (info.external_attr >> 16) & 0o170000 == stat.S_IFLNK:
        raise UnsafeArchiveError("Archive contains a symbolic link")
    if info.flag_bits & 0x1:
        raise InvalidArchiveError("Encrypted archives are not supported")
    if info.is_dir() or not parts:
        if len(parts) > 1:
            raise UnsafeArchiveError("Archive nesting deeper than one directory is not allowed")
        return None
    if parts[0] == "__MACOSX" or parts[-1].lower() in _IGNORED_BASENAMES:
        return None  # OS metadata, ignored (never extracted)
    if len(parts) > 2:
        raise UnsafeArchiveError("Archive nesting deeper than one directory is not allowed")

    key = "/".join(parts).lower()
    if key in seen:
        raise InvalidArchiveError(f"Archive contains duplicate entry '{parts[-1]}'")
    seen.add(key)

    stem, ext = _split_ext(parts[-1])
    if ext not in ALLOWED_SHAPEFILE_PARTS:
        raise InvalidArchiveError(
            f"Unexpected file '{parts[-1]}': only Shapefile components "
            f"({', '.join(sorted(ALLOWED_SHAPEFILE_PARTS))}) are allowed"
        )
    if (
        info.file_size >= _RATIO_CHECK_MIN_BYTES
        and info.file_size / max(info.compress_size, 1) > limits.max_compression_ratio
    ):
        raise UnsafeArchiveError("Suspicious compression ratio (possible ZIP bomb)")
    return parts, stem, ext


def _scan_entries(
    infos: list[zipfile.ZipInfo], limits: ArchiveLimits
) -> dict[tuple[str, str], dict[str, str]]:
    """Check every entry and group Shapefile components by (directory, stem)."""
    if len(infos) > limits.max_entries:
        raise UnsafeArchiveError(f"Archive has more than {limits.max_entries} entries")
    total_size = total_compressed = 0
    seen: set[str] = set()
    datasets: dict[tuple[str, str], dict[str, str]] = {}
    for info in infos:
        checked = _check_entry_with_limits(info, seen, limits)
        if checked is None:
            continue
        parts, stem, ext = checked
        total_size += info.file_size
        total_compressed += info.compress_size
        directory = parts[0] if len(parts) == 2 else ""
        datasets.setdefault((directory, stem), {})[ext] = info.filename

    if total_size > limits.max_extracted_bytes:
        raise UnsafeArchiveError("Declared uncompressed size exceeds the configured limit")
    if (
        total_size >= _RATIO_CHECK_MIN_BYTES
        and total_size / max(total_compressed, 1) > limits.max_compression_ratio
    ):
        raise UnsafeArchiveError("Suspicious overall compression ratio (possible ZIP bomb)")
    return datasets


def _select_dataset(datasets: dict[tuple[str, str], dict[str, str]]) -> dict[str, str]:
    """Pick the single Shapefile; refuse ambiguity instead of guessing."""
    shapefiles = {k: v for k, v in datasets.items() if "shp" in v}
    if not shapefiles:
        raise MissingShapefileComponentError("Archive does not contain a .shp file")
    if len(shapefiles) > 1:
        raise MultipleShapefilesError(
            "Archive contains multiple Shapefiles; upload one Shapefile per archive"
        )
    if any("shp" not in v for v in datasets.values()):
        raise MissingShapefileComponentError(
            "Archive contains sidecar files without a matching .shp"
        )
    (members,) = shapefiles.values()
    missing = [p for p in REQUIRED_SHAPEFILE_PARTS if p not in members]
    if missing:
        raise MissingShapefileComponentError(
            "Shapefile is missing required component(s): " + ", ".join(f".{m}" for m in missing)
        )
    return members


def _check_shp_header(zf: zipfile.ZipFile, member: str) -> None:
    with zf.open(member) as shp:
        header = shp.read(4)
    if len(header) < 4 or struct.unpack(">i", header)[0] != _SHP_FILE_CODE:
        raise CorruptGeodataError("The .shp file does not have a valid Shapefile header")


def inspect_shapefile_archive(path: Path, limits: ArchiveLimits) -> ShapefileArchive:
    """Validate ZIP structure *without extracting*; return the single Shapefile's members."""
    try:
        zf = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError) as exc:
        raise InvalidArchiveError("File is not a valid ZIP archive") from exc
    with zf:
        members = _select_dataset(_scan_entries(zf.infolist(), limits))
        _check_shp_header(zf, members["shp"])
        return ShapefileArchive(members)


def extract_shapefile(zip_path: Path, dest: Path, limits: ArchiveLimits) -> Path:
    """Extract the validated Shapefile into ``dest`` under fixed names (``dataset.<ext>``).

    Archive-supplied names are never used for output paths, and the *actual* number of
    decompressed bytes is enforced (declared sizes in ZIP headers can lie).
    """
    archive = inspect_shapefile_archive(zip_path, limits)
    budget = limits.max_extracted_bytes
    with zipfile.ZipFile(zip_path) as zf:
        for ext, member in archive.members.items():
            target = dest / f"dataset.{ext}"
            try:
                with zf.open(member) as src, target.open("wb") as out:
                    while chunk := src.read(1024 * 1024):
                        budget -= len(chunk)
                        if budget < 0:
                            raise UnsafeArchiveError(
                                "Decompressed data exceeds the configured limit"
                            )
                        out.write(chunk)
            except zipfile.BadZipFile as exc:
                raise InvalidArchiveError(
                    "Archive is corrupt (bad CRC or truncated entry)"
                ) from exc
    return dest / "dataset.shp"


def validate_kml(path: Path) -> None:
    """Structural KML check: well-formed XML, ``<kml>`` root, no DTD/entities/externals."""
    with path.open("rb") as fh:
        head = fh.read(4096)
    if not head.strip():
        raise CorruptGeodataError("File is empty")
    if head.startswith(b"PK"):
        raise UnsupportedFileTypeError("KMZ (zipped KML) is not supported; upload a plain .kml")
    if not head.lstrip(b"\xef\xbb\xbf \t\r\n").startswith(b"<"):
        raise CorruptGeodataError("File content is not XML")
    try:
        root_checked = False
        for event, element in SafeET.iterparse(
            str(path),
            events=("start", "end"),
            forbid_dtd=True,
            forbid_entities=True,
            forbid_external=True,
        ):
            if event == "start" and not root_checked:
                root_checked = True
                if element.tag.rsplit("}", 1)[-1] != "kml":
                    raise CorruptGeodataError("XML root element is not <kml>")
            elif event == "end":
                element.clear()  # constant memory for large files
    except DefusedXmlException as exc:
        raise UnsafeContentError(
            "KML uses DTDs, entities or external references, which are rejected"
        ) from exc
    except SafeET.ParseError as exc:
        raise CorruptGeodataError("KML is not well-formed XML") from exc
