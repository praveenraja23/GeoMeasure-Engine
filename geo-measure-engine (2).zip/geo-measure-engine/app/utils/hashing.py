from __future__ import annotations

import hashlib


class StreamingSha256:
    """Incremental SHA-256 (the integrity/identity hash; MD5 is deliberately not used)."""

    def __init__(self) -> None:
        self._hash = hashlib.sha256()

    def update(self, chunk: bytes) -> None:
        self._hash.update(chunk)

    def hexdigest(self) -> str:
        return self._hash.hexdigest()
