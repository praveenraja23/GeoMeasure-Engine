"""Reusable page/limit pagination."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, TypeVar

from app.core.exceptions import InvalidQueryError

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class PageParams:
    page: int
    limit: int

    @classmethod
    def validated(cls, page: int, limit: int, max_limit: int) -> PageParams:
        if page < 1:
            raise InvalidQueryError("'page' must be >= 1")
        if limit < 1 or limit > max_limit:
            raise InvalidQueryError(f"'limit' must be between 1 and {max_limit}")
        return cls(page, limit)

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.limit


@dataclass(frozen=True, slots=True)
class Page(Generic[T]):
    items: list[T]
    total: int
    params: PageParams

    @property
    def has_next(self) -> bool:
        return self.params.offset + len(self.items) < self.total
