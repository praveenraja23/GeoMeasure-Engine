"""Initial schema: PostGIS, files, processing_jobs, features, measurements.

Revision ID: 0001
Revises:
Create Date: 2026-10-08
"""
from __future__ import annotations

import geoalchemy2
import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

FILE_STATUSES = "'UPLOADED', 'QUEUED', 'PROCESSING', 'COMPLETED', 'PARTIALLY_COMPLETED', 'FAILED'"
JOB_STATUSES = "'QUEUED', 'PROCESSING', 'COMPLETED', 'PARTIALLY_COMPLETED', 'FAILED'"
FILE_TYPES = "'KML', 'SHAPEFILE'"
MEASUREMENT_STATUSES = "'COMPLETED', 'NOT_REQUIRED', 'NOT_MEASURABLE', 'UNSUPPORTED', 'FAILED'"
VALIDITY_STATUSES = "'VALID', 'REPAIRED', 'INVALID', 'NOT_CHECKED'"


def _ts(name: str, nullable: bool = False, default: bool = True) -> sa.Column:  # type: ignore[type-arg]
    return sa.Column(
        name,
        sa.DateTime(timezone=True),
        nullable=nullable,
        server_default=sa.func.now() if default else None,
    )


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS postgis")

    op.create_table(
        "files",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("filename", sa.String(80), nullable=False),
        sa.Column("original_filename", sa.String(255), nullable=False),
        sa.Column("file_type", sa.String(32), nullable=False),
        sa.Column("file_size_bytes", sa.BigInteger(), nullable=False),
        sa.Column("sha256", sa.String(64), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("source_crs", sa.String(255)),
        sa.Column("source_crs_name", sa.String(255)),
        sa.Column("measurement_crs", sa.String(255)),
        sa.Column("measurement_crs_name", sa.String(255)),
        sa.Column("measurement_units", sa.String(32)),
        sa.Column("crs_selection_reason", sa.Text()),
        sa.Column("feature_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("successful_feature_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("failed_feature_count", sa.Integer(), nullable=False, server_default="0"),
        _ts("created_at"),
        _ts("updated_at"),
        _ts("processing_started_at", nullable=True, default=False),
        _ts("processing_completed_at", nullable=True, default=False),
        sa.Column("error_code", sa.String(64)),
        sa.Column("error_message", sa.Text()),
        sa.Column("storage_path", sa.String(255), nullable=False),
        sa.CheckConstraint(f"status IN ({FILE_STATUSES})", name="ck_files_status"),
        sa.CheckConstraint(f"file_type IN ({FILE_TYPES})", name="ck_files_file_type"),
        sa.CheckConstraint(
            "feature_count >= 0 AND successful_feature_count >= 0 AND failed_feature_count >= 0",
            name="ck_files_counts_non_negative",
        ),
        sa.CheckConstraint(
            "status NOT IN ('COMPLETED', 'PARTIALLY_COMPLETED', 'FAILED') "
            "OR feature_count = successful_feature_count + failed_feature_count",
            name="ck_files_counts_consistent",
        ),
    )
    op.create_index("ix_files_status", "files", ["status"])
    op.create_index("ix_files_created_at", "files", ["created_at"])
    op.create_index("ix_files_sha256", "files", ["sha256"])

    op.create_table(
        "processing_jobs",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("file_id", sa.Uuid(), sa.ForeignKey("files.id", ondelete="CASCADE"), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("attempt", sa.Integer(), nullable=False, server_default="0"),
        _ts("started_at", nullable=True, default=False),
        _ts("completed_at", nullable=True, default=False),
        sa.Column("duration_ms", sa.Integer()),
        sa.Column("error_code", sa.String(64)),
        sa.Column("error_message", sa.Text()),
        sa.Column("processed_features", sa.Integer()),
        sa.Column("total_features", sa.Integer()),
        _ts("created_at"),
        sa.CheckConstraint(f"status IN ({JOB_STATUSES})", name="ck_processing_jobs_status"),
    )
    op.create_index("ix_processing_jobs_file_id", "processing_jobs", ["file_id"])
    op.create_index("ix_processing_jobs_status", "processing_jobs", ["status"])

    op.create_table(
        "features",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column("file_id", sa.Uuid(), sa.ForeignKey("files.id", ondelete="CASCADE"), nullable=False),
        sa.Column("feature_index", sa.Integer(), nullable=False),
        sa.Column("geometry_type", sa.String(32), nullable=False),
        sa.Column("source_geometry_type", sa.String(32)),
        sa.Column("properties", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("source_crs", sa.String(255)),
        sa.Column("storage_crs", sa.String(32), nullable=False),
        sa.Column(
            "geometry",
            geoalchemy2.Geometry(geometry_type="GEOMETRY", srid=4326, spatial_index=False),
        ),
        sa.Column("is_valid_before", sa.Boolean()),
        sa.Column("is_valid_after", sa.Boolean()),
        sa.Column("was_repaired", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("repair_method", sa.String(64)),
        _ts("created_at"),
        sa.UniqueConstraint("file_id", "feature_index", name="uq_features_file_id_feature_index"),
    )
    op.create_index("ix_features_file_id_geometry_type", "features", ["file_id", "geometry_type"])
    # GiST: R-tree-like index over bounding boxes; serves ST_Intersects/&&/ST_DWithin.
    op.create_index("ix_features_geometry_gist", "features", ["geometry"], postgresql_using="gist")

    op.create_table(
        "measurements",
        sa.Column("id", sa.Uuid(), primary_key=True),
        sa.Column(
            "feature_id", sa.Uuid(), sa.ForeignKey("features.id", ondelete="CASCADE"), nullable=False, unique=True
        ),
        sa.Column("file_id", sa.Uuid(), sa.ForeignKey("files.id", ondelete="CASCADE"), nullable=False),
        sa.Column("measurement_status", sa.String(32), nullable=False),
        sa.Column("area_m2", sa.Double()),
        sa.Column("area_hectares", sa.Double()),
        sa.Column("length_m", sa.Double()),
        sa.Column("length_km", sa.Double()),
        sa.Column("measurement_crs", sa.String(255)),
        sa.Column("calculation_method", sa.String(32)),
        sa.Column("validity_status", sa.String(32), nullable=False),
        sa.Column("warning", sa.Text()),
        sa.Column("error_code", sa.String(64)),
        _ts("created_at"),
        sa.CheckConstraint(f"measurement_status IN ({MEASUREMENT_STATUSES})", name="ck_measurements_status"),
        sa.CheckConstraint(f"validity_status IN ({VALIDITY_STATUSES})", name="ck_measurements_validity"),
    )
    op.create_index("ix_measurements_file_id_status", "measurements", ["file_id", "measurement_status"])


def downgrade() -> None:
    op.drop_table("measurements")
    op.drop_table("features")
    op.drop_table("processing_jobs")
    op.drop_table("files")
    # The PostGIS extension is intentionally left installed: it is shared infrastructure.
