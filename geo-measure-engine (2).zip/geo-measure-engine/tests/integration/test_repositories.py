import uuid

from sqlalchemy import text

from app.db.session import get_engine, session_scope
from app.domain.enums import MeasurementStatus
from app.repositories.feature_repository import FeatureRepository, feature_uuid
from app.repositories.measurement_repository import MeasurementRepository
from app.utils.pagination import PageParams
from tests.geospatial.test_pipeline_crs import run


def test_feature_ids_are_deterministic():
    fid = uuid.uuid4()
    assert feature_uuid(fid, 3) == feature_uuid(fid, 3) != feature_uuid(fid, 4)


def test_upsert_is_idempotent_and_updates_in_place(make_file, sample_dir):
    from shapely.geometry import box

    file_id, _ = make_file(sample_dir / "sample.kml")
    first = run([box(78.0, 10.0, 78.01, 10.01)], "EPSG:4326")
    second = run([box(78.0, 10.0, 78.02, 10.02)], "EPSG:4326")  # same index, different geometry
    for batch in (first, first, second):
        with session_scope() as s:
            FeatureRepository(s).upsert_batch(file_id, batch)
            MeasurementRepository(s).upsert_batch(file_id, batch)
    with get_engine().connect() as c:
        assert (
            c.execute(
                text("SELECT count(*) FROM features WHERE file_id=:i"), {"i": file_id}
            ).scalar()
            == 1
        )
        assert (
            c.execute(
                text("SELECT count(*) FROM measurements WHERE file_id=:i"), {"i": file_id}
            ).scalar()
            == 1
        )
    with session_scope() as s:
        counts = MeasurementRepository(s).counts(file_id)
        assert (counts.total, counts.successful, counts.failed) == (1, 1, 0)
        row = MeasurementRepository(s).page(file_id, PageParams(1, 5)).items[0]
        assert row.measurement.measurement_status is MeasurementStatus.COMPLETED
        assert row.measurement.area_m2 > 3_000_000  # reflects the *second* (larger) geometry


def test_full_double_precision_is_stored(make_file, sample_dir):
    from shapely.geometry import box

    file_id, _ = make_file(sample_dir / "sample.kml")
    batch = run([box(78.0, 10.0, 78.0123456789, 10.0123456789)], "EPSG:4326")
    with session_scope() as s:
        FeatureRepository(s).upsert_batch(file_id, batch)
        MeasurementRepository(s).upsert_batch(file_id, batch)
    with session_scope() as s:
        stored = (
            MeasurementRepository(s).page(file_id, PageParams(1, 5)).items[0].measurement.area_m2
        )
    assert stored == batch[0].measurement.area_m2  # no premature rounding
