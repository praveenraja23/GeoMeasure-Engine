import os
import time
from datetime import UTC, datetime, timedelta

from sqlalchemy import text

from app.db.session import get_engine, session_scope
from app.services.cleanup_service import CleanupService
from app.services.container import get_storage


def test_purge_expired_and_sweep_orphans(make_file, service, sample_dir):
    old_id, old_job = make_file(sample_dir / "sample.kml")
    new_id, new_job = make_file(sample_dir / "sample.kml")
    for fid, jid in ((old_id, old_job), (new_id, new_job)):
        service.process(fid, job_id=jid, attempt=1, is_final_attempt=True)
    with get_engine().begin() as c:
        c.execute(
            text("UPDATE files SET created_at = :t WHERE id = :i"),
            {"t": datetime.now(UTC) - timedelta(days=40), "i": old_id},
        )
    storage = get_storage()
    orphan = storage._root / "orphan-without-row.kml"  # type: ignore[attr-defined]
    orphan.write_text("x")
    os.utime(orphan, (time.time() - 7200, time.time() - 7200))
    fresh_orphan = storage._root / "fresh-orphan.kml"  # type: ignore[attr-defined]
    fresh_orphan.write_text("x")

    with session_scope() as s:
        svc = CleanupService(s, storage)
        assert svc.purge_expired(30) == 1
        assert svc.sweep_orphans(min_age_seconds=3600) == 1

    keys = storage.list_keys()
    assert f"{old_id}.kml" not in keys and f"{new_id}.kml" in keys
    assert (
        "orphan-without-row.kml" not in keys and "fresh-orphan.kml" in keys
    )  # recent objects are never swept
    with get_engine().connect() as c:
        assert (
            c.execute(
                text("SELECT count(*) FROM features WHERE file_id=:i"), {"i": old_id}
            ).scalar()
            == 0
        )
    fresh_orphan.unlink()
