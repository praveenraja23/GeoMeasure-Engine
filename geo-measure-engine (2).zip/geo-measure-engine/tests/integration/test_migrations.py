from alembic.autogenerate import compare_metadata
from alembic.migration import MigrationContext
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

from app.db import models  # noqa: F401
from app.db.base import Base
from app.db.session import get_engine


def test_migration_matches_models(migrated_db):
    with get_engine().connect() as conn:
        ctx = MigrationContext.configure(
            conn,
            opts={
                "compare_type": True,
                "include_object": lambda o, n, t, r, c: (
                    not (t == "table" and n == "spatial_ref_sys")
                ),
            },
        )
        assert compare_metadata(ctx, Base.metadata) == []


def test_postgis_enabled_and_gist_index_present(migrated_db):
    with get_engine().connect() as conn:
        assert conn.execute(text("SELECT PostGIS_Lib_Version()")).scalar()
        idx = conn.execute(
            text("SELECT indexdef FROM pg_indexes WHERE indexname = 'ix_features_geometry_gist'")
        ).scalar()
    assert idx and "USING gist" in idx


def test_expected_indexes_exist(migrated_db):
    wanted = {
        "ix_files_status",
        "ix_files_created_at",
        "ix_files_sha256",
        "ix_processing_jobs_file_id",
        "ix_features_file_id_geometry_type",
        "uq_features_file_id_feature_index",
        "ix_measurements_file_id_status",
    }
    with get_engine().connect() as conn:
        names = {
            r[0]
            for r in conn.execute(
                text("SELECT indexname FROM pg_indexes WHERE schemaname = 'public'")
            )
        }
    assert wanted <= names


def test_count_consistency_constraint_enforced(db):
    bad = text(
        "INSERT INTO files (id, filename, original_filename, file_type, file_size_bytes, sha256, status, storage_path,"
        " feature_count, successful_feature_count, failed_feature_count)"
        " VALUES (gen_random_uuid(), 'f', 'f', 'KML', 1, 'x', 'COMPLETED', 'f', 10, 3, 3)"
    )
    with get_engine().connect() as conn:
        try:
            conn.execute(bad)
            raised = False
        except IntegrityError:
            raised = True
    assert raised


def test_invalid_status_rejected_by_check_constraint(db):
    bad = text(
        "INSERT INTO files (id, filename, original_filename, file_type, file_size_bytes, sha256, status, storage_path)"
        " VALUES (gen_random_uuid(), 'f', 'f', 'KML', 1, 'x', 'NOPE', 'f')"
    )
    with get_engine().connect() as conn:
        try:
            conn.execute(bad)
            raised = False
        except IntegrityError:
            raised = True
    assert raised
