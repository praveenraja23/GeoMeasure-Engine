import uuid

import pytest
from sqlalchemy import text

from app.core.config import get_settings
from app.core.exceptions import RetryableProcessingError
from app.db.session import get_engine, session_scope
from app.domain.enums import FileStatus, JobStatus
from app.repositories.feature_repository import FeatureFilters, FeatureRepository
from app.repositories.file_repository import FileRepository
from app.repositories.job_repository import JobRepository
from app.repositories.measurement_repository import MeasurementRepository
from app.services.container import build_processing_service
from app.services.processing_service import classify_exception
from app.utils.pagination import PageParams
from tests.helpers import make_zip, shapefile_entries


def run(service, file_id, job_id, attempt=1, final=True):
    return service.process(file_id, job_id=job_id, attempt=attempt, is_final_attempt=final)


def state(file_id):
    with session_scope() as s:
        f = FileRepository(s).get(file_id)
        return (
            f.status,
            f.feature_count,
            f.successful_feature_count,
            f.failed_feature_count,
            f.error_code,
        )


def row_counts(file_id):
    with get_engine().connect() as c:
        feats = c.execute(
            text("SELECT count(*) FROM features WHERE file_id=:i"), {"i": file_id}
        ).scalar()
        meas = c.execute(
            text("SELECT count(*) FROM measurements WHERE file_id=:i"), {"i": file_id}
        ).scalar()
    return feats, meas


def test_kml_completes_and_counts_are_consistent(make_file, service, sample_dir):
    file_id, job_id = make_file(sample_dir / "sample.kml")
    out = run(service, file_id, job_id)
    assert out.status == "COMPLETED"
    assert state(file_id) == (FileStatus.COMPLETED, 7, 7, 0, None)
    with session_scope() as s:
        f = FileRepository(s).get(file_id)
        assert (f.source_crs, f.measurement_crs, f.measurement_units) == (
            "EPSG:4326",
            "EPSG:32644",
            "metre",
        )
        assert "UTM" in f.crs_selection_reason
        job = JobRepository(s).get(job_id)
        assert (
            job.status is JobStatus.COMPLETED and job.attempt == 1 and job.duration_ms is not None
        )
        assert (job.processed_features, job.total_features) == (7, 7)


def test_reprocessing_is_idempotent_no_duplicates(make_file, service, sample_dir):
    file_id, job_id = make_file(sample_dir / "sample.kml")
    run(service, file_id, job_id)
    before = row_counts(file_id)
    with session_scope() as s:  # simulate a redelivered/retried message after a crash
        FileRepository(s).update(file_id, status=FileStatus.QUEUED)
    run(service, file_id, job_id, attempt=2)
    assert row_counts(file_id) == before == (7, 7)
    assert state(file_id)[0] is FileStatus.COMPLETED


def test_terminal_file_is_not_reprocessed(make_file, service, sample_dir):
    file_id, job_id = make_file(sample_dir / "sample.kml")
    run(service, file_id, job_id)
    again = run(service, file_id, job_id, attempt=2)
    assert again.skipped and again.reason == "already_finished"


def test_multiple_batches_persist_everything(make_file, sample_dir, monkeypatch):
    monkeypatch.setenv("FEATURE_BATCH_SIZE", "2")
    get_settings.cache_clear()
    svc = build_processing_service(get_settings())
    file_id, job_id = make_file(sample_dir / "sample.kml")
    run(svc, file_id, job_id)
    assert row_counts(file_id) == (7, 7)
    with session_scope() as s:
        page = FeatureRepository(s).page(file_id, FeatureFilters(), PageParams(1, 50), False)
        idx = [r.feature.feature_index for r in page.items]
    assert idx == list(range(7))
    monkeypatch.undo()
    get_settings.cache_clear()


def test_partial_completion_when_some_features_fail(make_file, service, tmp_path):
    kml = tmp_path / "mixed.kml"
    good = "78,10,0 78.01,10,0 78.01,10.01,0 78,10.01,0 78,10,0"
    sliver = "78,10,0 79,11,0 80,12,0 78,10,0"  # exactly collinear: zero area, unrepairable
    poly = "<Polygon><outerBoundaryIs><LinearRing><coordinates>{}</coordinates></LinearRing></outerBoundaryIs></Polygon>"
    kml.write_text(
        '<?xml version="1.0"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document>'
        f"<Placemark><name>good</name>{poly.format(good)}</Placemark>"
        f"<Placemark><name>sliver</name>{poly.format(sliver)}</Placemark></Document></kml>"
    )
    file_id, job_id = make_file(kml)
    assert run(service, file_id, job_id).status == "PARTIALLY_COMPLETED"
    assert state(file_id)[:4] == (FileStatus.PARTIALLY_COMPLETED, 2, 1, 1)
    with session_scope() as s:
        items = {
            m.feature_index: m.measurement
            for m in MeasurementRepository(s).page(file_id, PageParams(1, 10)).items
        }
    assert items[0].measurement_status.value == "COMPLETED"
    assert (items[1].measurement_status.value, items[1].error_code) == (
        "FAILED",
        "GEOMETRY_REPAIR_FAILED",
    )


def test_missing_prj_marks_file_failed_with_crs_unknown(make_file, service, sample_dir):
    file_id, job_id = make_file(sample_dir / "sample_shapefile_no_prj.zip")
    assert run(service, file_id, job_id).status == "FAILED"
    status, total, ok, failed, code = state(file_id)
    assert (status, total, ok, failed, code) == (FileStatus.FAILED, 1, 0, 1, "CRS_UNKNOWN")
    assert row_counts(file_id) == (
        1,
        1,
    )  # still persisted, with geometry NULL and a failed measurement


def test_corrupt_data_fails_without_retry(make_file, service, tmp_path):
    corrupt = make_zip(
        tmp_path / "bad.zip", shapefile_entries()
    )  # valid structure, garbage content
    file_id, job_id = make_file(corrupt)
    out = run(service, file_id, job_id, final=False)  # even when retries remain: must not raise
    assert out.status == "FAILED" and out.reason == "CORRUPT_GEODATA"
    assert state(file_id)[0] is FileStatus.FAILED


def test_transient_failure_is_retryable_then_gives_up(make_file, service, sample_dir, monkeypatch):
    file_id, job_id = make_file(sample_dir / "sample.kml")

    def boom(key):
        raise OSError("disk hiccup")

    monkeypatch.setattr(service._storage, "local_path", boom)
    with pytest.raises(RetryableProcessingError):
        run(service, file_id, job_id, attempt=1, final=False)
    assert state(file_id)[0] is FileStatus.QUEUED  # waiting for the retry

    out = run(service, file_id, job_id, attempt=4, final=True)
    assert out.status == "FAILED"
    with session_scope() as s:
        assert "gave up after 4 attempt" in FileRepository(s).get(file_id).error_message


def test_temp_directories_are_cleaned_up_on_success_and_failure(
    make_file, service, sample_dir, tmp_path
):
    tmp_root = get_settings().effective_temp_dir
    ok_id, ok_job = make_file(sample_dir / "sample_shapefile.zip")
    bad_id, bad_job = make_file(make_zip(tmp_path / "bad.zip", shapefile_entries()))
    run(service, ok_id, ok_job)
    run(service, bad_id, bad_job)
    assert [p for p in tmp_root.iterdir() if p.name.startswith("geo-")] == []


def test_concurrent_processing_is_prevented_by_advisory_lock(make_file, service, sample_dir):
    file_id, job_id = make_file(sample_dir / "sample.kml")
    key = file_id.int & 0x7FFF_FFFF_FFFF_FFFF
    with get_engine().connect().execution_options(isolation_level="AUTOCOMMIT") as holder:
        holder.execute(text("SELECT pg_advisory_lock(:k)"), {"k": key})
        out = run(service, file_id, job_id)
        holder.execute(text("SELECT pg_advisory_unlock(:k)"), {"k": key})
    assert out.skipped and out.reason == "locked_by_other_worker"
    assert state(file_id)[0] is FileStatus.QUEUED
    assert run(service, file_id, job_id).status == "COMPLETED"


def test_deleted_file_is_skipped(service, db):
    out = run(service, uuid.uuid4(), None)
    assert out.skipped and out.reason == "file_deleted"


def test_exception_classification():
    from celery.exceptions import SoftTimeLimitExceeded
    from sqlalchemy.exc import OperationalError

    assert classify_exception(OperationalError("s", {}, Exception("x"))).retryable
    assert classify_exception(OSError("x")).retryable
    assert not classify_exception(FileNotFoundError("x")).retryable
    assert not classify_exception(SoftTimeLimitExceeded()).retryable
    assert not classify_exception(ValueError("bug")).retryable


def test_failure_metrics_are_recorded_for_every_failed_outcome(
    make_file, service, sample_dir, tmp_path
):
    from app.core import metrics

    def failed(code):
        return metrics.PROCESSING_JOBS_FAILED.labels("SHAPEFILE", code)._value.get()

    before_crs, before_corrupt = failed("CRS_UNKNOWN"), failed("CORRUPT_GEODATA")
    a, aj = make_file(
        sample_dir / "sample_shapefile_no_prj.zip"
    )  # all features fail -> FAILED via finalise
    b, bj = make_file(
        make_zip(tmp_path / "bad.zip", shapefile_entries())
    )  # parse failure -> FAILED via handler
    run(service, a, aj)
    run(service, b, bj)
    assert failed("CRS_UNKNOWN") == before_crs + 1
    assert failed("CORRUPT_GEODATA") == before_corrupt + 1
