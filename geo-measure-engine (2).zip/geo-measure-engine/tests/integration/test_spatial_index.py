from sqlalchemy import text

from app.db.session import get_engine, session_scope
from app.repositories.feature_repository import FeatureFilters, FeatureRepository
from app.schemas.common import BBox
from app.utils.pagination import PageParams


def test_bbox_filter_returns_only_intersecting_features(make_file, service, sample_dir):
    file_id, job_id = make_file(sample_dir / "sample.kml")
    service.process(file_id, job_id=job_id, attempt=1, is_final_attempt=True)
    with session_scope() as s:
        repo = FeatureRepository(s)
        page = repo.page(
            file_id,
            FeatureFilters(bbox=BBox.parse("78.049,10.899,78.061,10.911")),
            PageParams(1, 50),
            False,
        )
        assert [r.feature.properties["Name"] for r in page.items] == ["Plot A"]
        none = repo.page(
            file_id, FeatureFilters(bbox=BBox.parse("0,0,1,1")), PageParams(1, 50), False
        )
        assert none.total == 0
        lines = repo.page(
            file_id, FeatureFilters(geometry_type="MultiLineString"), PageParams(1, 50), False
        )
        assert lines.total == 1


def test_planner_can_use_gist_index_for_bbox(make_file, service, sample_dir):
    file_id, job_id = make_file(sample_dir / "sample.kml")
    service.process(file_id, job_id=job_id, attempt=1, is_final_attempt=True)
    with get_engine().connect() as conn:
        conn.execute(text("ANALYZE features"))
        conn.execute(
            text("SET enable_seqscan = off")
        )  # tiny table: force the planner to show index availability
        plan = "\n".join(
            r[0]
            for r in conn.execute(
                text(
                    "EXPLAIN SELECT id FROM features WHERE ST_Intersects(geometry, ST_MakeEnvelope(78.0,10.8,78.2,11.0,4326))"
                )
            )
        )
    assert "ix_features_geometry_gist" in plan
