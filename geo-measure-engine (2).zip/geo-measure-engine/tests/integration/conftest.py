from __future__ import annotations

import shutil
import uuid
from collections.abc import Callable
from pathlib import Path

import pytest

from app.core.config import get_settings
from app.db.models import FileRecord
from app.db.session import session_scope
from app.domain.enums import FileStatus, FileType
from app.repositories.file_repository import FileRepository
from app.repositories.job_repository import JobRepository
from app.services.container import build_processing_service, get_storage
from app.services.processing_service import ProcessingService


@pytest.fixture
def make_file(db: None) -> Callable[..., tuple[uuid.UUID, uuid.UUID]]:
    """Register an existing sample file as an uploaded, queued FileRecord."""

    def _make(path: Path, original: str | None = None) -> tuple[uuid.UUID, uuid.UUID]:
        file_type = FileType.KML if path.suffix == ".kml" else FileType.SHAPEFILE
        file_id = uuid.uuid4()
        key = f"{file_id}{path.suffix}"
        storage = get_storage()
        with (
            storage.local_path.__self__._root.joinpath(key).open("wb") as out,
            path.open("rb") as src,
        ):  # type: ignore[attr-defined]
            shutil.copyfileobj(src, out)
        with session_scope() as s:
            FileRepository(s).add(
                FileRecord(
                    id=file_id,
                    filename=key,
                    original_filename=original or path.name,
                    file_type=file_type,
                    file_size_bytes=path.stat().st_size,
                    sha256="0" * 64,
                    status=FileStatus.QUEUED,
                    storage_path=key,
                )
            )
            job = JobRepository(s).create(file_id)
            job_id = job.id
        return file_id, job_id

    return _make


@pytest.fixture
def service() -> ProcessingService:
    return build_processing_service(get_settings())
