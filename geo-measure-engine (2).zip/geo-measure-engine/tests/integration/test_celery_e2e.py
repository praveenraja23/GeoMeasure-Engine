"""Real Celery worker + real Redis broker + PostGIS: upload -> queue -> worker -> API."""

import pytest
import redis

from app.core.config import get_settings
from app.tasks.celery_app import celery_app
from tests.helpers import upload_path, wait_for


@pytest.fixture
def worker(db):
    client = redis.Redis.from_url(get_settings().effective_broker_url, socket_connect_timeout=2)
    try:
        client.ping()
    except redis.exceptions.RedisError as exc:
        pytest.skip(f"Redis unavailable: {exc}")
    client.flushdb()

    from celery.contrib.testing.worker import start_worker

    celery_app.conf.task_always_eager = False
    try:
        with start_worker(
            celery_app,
            pool="solo",
            loglevel="ERROR",
            perform_ping_check=False,
            queues=["geo_measure"],
            shutdown_timeout=30,
        ):
            yield
    finally:
        celery_app.conf.task_always_eager = True


def test_kml_flow_through_real_queue(client, worker, sample_dir):
    up = upload_path(client, sample_dir / "sample.kml")
    assert up.status_code == 202 and up.json()["status"] in {"QUEUED", "PROCESSING", "COMPLETED"}
    info = wait_for(client, up.json()["id"], timeout=60)
    assert info["status"] == "COMPLETED" and info["feature_count"] == 7
    items = client.get(f"/api/v1/files/{up.json()['id']}/measurements/?limit=50").json()["items"]
    assert (
        sum(1 for i in items if i["area_m2"]) == 4 and sum(1 for i in items if i["length_m"]) == 2
    )
    assert client.get(f"/api/v1/jobs/{up.json()['job_id']}").json()["status"] == "COMPLETED"


def test_shapefile_flow_through_real_queue(client, worker, sample_dir):
    up = upload_path(client, sample_dir / "sample_shapefile_lines.zip")
    info = wait_for(client, up.json()["id"], timeout=60)
    assert info["status"] == "COMPLETED"
    items = client.get(f"/api/v1/files/{up.json()['id']}/measurements/").json()["items"]
    assert {i["geometry_type"] for i in items} == {"LineString", "MultiLineString"} and all(
        i["length_m"] > 0 for i in items
    )


def test_failed_file_is_reported_not_retried_forever(client, worker, sample_dir):
    up = upload_path(client, sample_dir / "sample_shapefile_no_prj.zip")
    info = wait_for(client, up.json()["id"], timeout=60)
    assert info["status"] == "FAILED" and info["error_code"] == "CRS_UNKNOWN"
    assert client.get(f"/api/v1/jobs/{up.json()['job_id']}").json()["attempt"] == 1
