from pathlib import Path

import pytest

from app.core.exceptions import CorruptGeodataError
from app.domain.enums import FileType
from app.geospatial.readers.factory import GeoFileReaderFactory
from app.utils.file_validation import ArchiveLimits, extract_shapefile

factory = GeoFileReaderFactory()
LIMITS = ArchiveLimits(50, 50 * 1024 * 1024, 100)


@pytest.fixture
def shp(sample_dir, tmp_path):
    return extract_shapefile(sample_dir / "sample_shapefile.zip", tmp_path, LIMITS)


def test_kml_reader_fixes_crs_to_wgs84_and_reads_attributes(sample_dir):
    reader = factory.for_type(FileType.KML)
    info = reader.inspect(sample_dir / "sample.kml")
    assert info.feature_count == 7
    assert info.crs.to_epsg() == 4326
    frame = reader.read(sample_dir / "sample.kml")
    assert set(frame.geom_type) == {
        "Point",
        "LineString",
        "Polygon",
        "MultiPolygon",
        "MultiLineString",
    }
    assert "owner" in frame.columns and "Name" in frame.columns
    assert not {"icon", "tessellate", "extrude", "visibility", "id"} & set(
        frame.columns
    )  # presentation noise dropped


def test_shapefile_reader_reads_crs_from_prj(shp):
    info = factory.for_type(FileType.SHAPEFILE).inspect(shp)
    assert info.feature_count == 4 and info.crs.to_epsg() == 4326
    assert info.bounds == pytest.approx((78.05, 10.90, 78.33, 10.92), abs=1e-6)


def test_missing_prj_means_unknown_crs_not_wgs84(sample_dir, tmp_path):
    path = extract_shapefile(sample_dir / "sample_shapefile_no_prj.zip", tmp_path, LIMITS)
    assert factory.for_type(FileType.SHAPEFILE).inspect(path).crs is None


def test_batches_cover_every_feature_exactly_once(shp):
    reader = factory.for_type(FileType.SHAPEFILE)
    batches = list(reader.read_batches(shp, batch_size=3))
    assert [(b.start_index, len(b.frame)) for b in batches] == [(0, 3), (3, 1)]
    assert sum(len(b.frame) for b in batches) == reader.inspect(shp).feature_count


def test_multi_folder_kml_has_continuous_indices(tmp_path):
    kml = tmp_path / "m.kml"
    pm = "<Placemark><name>{n}</name><Point><coordinates>78.0,10.0,0</coordinates></Point></Placemark>"
    kml.write_text(
        '<?xml version="1.0"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document>'
        f"<Folder><name>A</name>{pm.format(n='a1')}{pm.format(n='a2')}</Folder>"
        f"<Folder><name>B</name>{pm.format(n='b1')}</Folder></Document></kml>"
    )
    reader = factory.for_type(FileType.KML)
    assert reader.inspect(kml).feature_count == 3
    starts = [(b.start_index, len(b.frame)) for b in reader.read_batches(kml, 10)]
    assert starts == [(0, 2), (2, 1)]


def test_kml_multigeometry_of_polygons_is_readable(tmp_path):
    kml = tmp_path / "mg.kml"
    ring = "78,10,0 78.1,10,0 78.1,10.1,0 78,10,0"
    poly = f"<Polygon><outerBoundaryIs><LinearRing><coordinates>{ring}</coordinates></LinearRing></outerBoundaryIs></Polygon>"
    kml.write_text(
        '<?xml version="1.0"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><Placemark>'
        f"<MultiGeometry>{poly}{poly}</MultiGeometry></Placemark></Document></kml>"
    )
    frame = factory.for_type(FileType.KML).read(kml)
    assert frame.geom_type.iloc[0] in {"MultiPolygon", "GeometryCollection"}


def test_corrupt_shapefile_raises_domain_error(tmp_path):
    for ext in ("shp", "shx", "dbf"):
        (tmp_path / f"dataset.{ext}").write_bytes(b"\x00" * 120)
    with pytest.raises(CorruptGeodataError):
        factory.for_type(FileType.SHAPEFILE).inspect(tmp_path / "dataset.shp")


def test_kml_without_placemarks_is_a_domain_error(tmp_path):
    kml = tmp_path / "e.kml"
    kml.write_text(
        '<?xml version="1.0"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document/></kml>'
    )
    with pytest.raises(CorruptGeodataError):
        factory.for_type(FileType.KML).inspect(kml)


def test_extraction_uses_fixed_names(sample_dir, tmp_path):
    path = extract_shapefile(sample_dir / "sample_shapefile.zip", tmp_path, LIMITS)
    assert path == tmp_path / "dataset.shp"
    assert {p.name for p in Path(tmp_path).iterdir()} >= {
        "dataset.shp",
        "dataset.shx",
        "dataset.dbf",
        "dataset.prj",
    }
