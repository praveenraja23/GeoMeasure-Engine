"""CRS correctness: results must be physical metres, never raw degree arithmetic."""

import geopandas as gpd
import pytest
from pyproj import CRS, Geod, Transformer
from shapely.geometry import LineString, Point, box

from app.core.config import get_settings
from app.core.exceptions import MissingCRSError
from app.domain.enums import MeasurementStatus
from app.geospatial.crs.resolver import MeasurementCRSResolver
from app.services.container import build_pipeline

pipeline = build_pipeline(get_settings())
resolver = MeasurementCRSResolver(6.0)
GEOD = Geod(ellps="WGS84")


def run(geoms, crs):
    frame = gpd.GeoDataFrame({"n": range(len(geoms))}, geometry=geoms, crs=crs)
    source = CRS.from_user_input(crs) if crs else None
    bounds = tuple(frame.total_bounds)
    if any(b != b for b in bounds):  # NaN extent: the readers report this as None
        bounds = None
    plan = error = None
    try:
        plan = resolver.resolve(source, bounds)
    except MissingCRSError as exc:
        error = exc
    return pipeline.process_batch(frame, 0, source, plan, error)


def test_epsg4326_area_is_in_square_metres_not_degrees():
    square = box(78.05, 10.90, 78.06, 10.91)  # 0.01 deg x 0.01 deg
    (f,) = run([square], "EPSG:4326")
    reference = abs(GEOD.geometry_area_perimeter(square)[0])
    assert f.measurement.area_m2 != pytest.approx(square.area)  # raw degree area is 1e-4
    assert f.measurement.area_m2 > 1e6
    assert f.measurement.area_m2 == pytest.approx(reference, rel=3e-3)
    assert f.measurement.measurement_crs == "EPSG:32644"
    assert f.measurement.area_hectares == pytest.approx(f.measurement.area_m2 / 10_000)


def test_degree_square_area_depends_on_latitude():
    eq, high = (
        run([box(10, 0, 10.01, 0.01)], "EPSG:4326")[0],
        run([box(10, 60, 10.01, 60.01)], "EPSG:4326")[0],
    )
    ratio = eq.measurement.area_m2 / high.measurement.area_m2
    assert ratio == pytest.approx(2.0, rel=0.02)  # cos(60 deg) = 0.5; equal degrees != equal area


def test_epsg4326_line_length_matches_geodesic_reference():
    line = LineString([(78.00, 10.90), (78.02, 10.91), (78.04, 10.90)])
    (f,) = run([line], "EPSG:4326")
    assert f.measurement.length_m == pytest.approx(GEOD.geometry_length(line), rel=3e-3)
    assert f.measurement.length_km == pytest.approx(f.measurement.length_m / 1000)


def test_projected_metre_crs_measures_directly():
    (f,) = run([box(500_000, 1_200_000, 500_100, 1_200_200)], "EPSG:32644")
    assert f.measurement.area_m2 == pytest.approx(20_000)
    assert f.measurement.measurement_crs == "EPSG:32644"
    assert f.source_crs == "EPSG:32644"


def test_projected_feet_crs_yields_metric_output():
    (f,) = run(
        [box(1_000_000, 200_000, 1_000_100, 200_100)], "EPSG:2263"
    )  # 100 x 100 US survey feet
    expected = (100 * 1200 / 3937) ** 2  # US survey foot = 1200/3937 m
    assert f.measurement.area_m2 == pytest.approx(expected, rel=2e-3)
    assert f.measurement.area_m2 != pytest.approx(10_000)  # not the raw foot value
    assert f.measurement.measurement_crs == "EPSG:32618"


def test_web_mercator_area_is_not_inflated():
    x, y = Transformer.from_crs(4326, 3857, always_xy=True).transform(0.0, 60.0)
    (f,) = run([box(x, y, x + 1000, y + 1000)], "EPSG:3857")
    # Naive Mercator area would be 1,000,000; true ground area is ~ 1e6 * cos^2(60 deg)
    assert f.measurement.area_m2 == pytest.approx(250_000, rel=0.02)


def test_missing_crs_fails_safely_without_numbers():
    poly, line, pt = run([box(0, 0, 1, 1), LineString([(0, 0), (1, 1)]), Point(0, 0)], None)
    for f in (poly, line):
        assert f.measurement.status is MeasurementStatus.FAILED
        assert f.measurement.error_code.value == "CRS_UNKNOWN"
        assert f.measurement.area_m2 is None and f.measurement.length_m is None
        assert f.geometry is None  # cannot be placed on the globe
    assert pt.measurement.status is MeasurementStatus.NOT_REQUIRED


def test_broad_extent_uses_equal_area_and_geodesic_length():
    big = box(-100, 0, -99, 1)
    far = LineString([(39.0, 0.0), (40.0, 0.0)])
    area, length = run([big, far], "EPSG:4326")
    assert area.measurement.measurement_crs == "EPSG:6933"
    assert area.measurement.area_m2 == pytest.approx(
        abs(GEOD.geometry_area_perimeter(big)[0]), rel=2e-3
    )
    assert length.measurement.calculation_method.value == "geodesic_wgs84"
    assert length.measurement.length_m == pytest.approx(GEOD.geometry_length(far), rel=1e-6)


def test_coordinate_order_is_lon_lat():
    (f,) = run([Point(78.0, 10.0)], "EPSG:4326")
    assert (f.geometry.x, f.geometry.y) == (78.0, 10.0)
    # swapped (lat, lon) would be outside valid latitude range and must not silently pass
    (g,) = run([box(10.0, 78.0, 10.1, 78.1)], "EPSG:4326")  # lat 78 is valid; lon 10 -> still sane
    assert g.measurement.status is MeasurementStatus.COMPLETED


def test_invalid_polygon_is_repaired_and_flag_recorded():
    bowtie = gpd.GeoSeries.from_wkt(
        ["POLYGON((78 10, 78.01 10.01, 78.01 10, 78 10.01, 78 10))"]
    ).iloc[0]
    (f,) = run([bowtie], "EPSG:4326")
    assert f.was_repaired and f.is_valid_before is False and f.is_valid_after is True
    assert (
        f.repair_method
        and f.geometry_type == "MultiPolygon"
        and f.source_geometry_type == "Polygon"
    )
    assert f.measurement.area_m2 > 0


def test_empty_and_null_geometries_never_crash():
    results = run(
        [None, LineString(), box(0, 0, 0, 0).boundary.difference(box(0, 0, 0, 0).boundary)],
        "EPSG:4326",
    )
    assert all(r.measurement.status is MeasurementStatus.NOT_MEASURABLE for r in results)
    assert results[0].geometry_type == "Null"
