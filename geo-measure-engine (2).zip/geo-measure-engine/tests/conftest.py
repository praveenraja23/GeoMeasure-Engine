"""Test configuration. Must set the environment *before* the app is imported."""

from __future__ import annotations

import os
import tempfile
from collections.abc import Iterator
from pathlib import Path

import pytest

_TMP = Path(tempfile.mkdtemp(prefix="geo-tests-"))
# Never touch a developer database: tests use their own database and storage.
os.environ["DATABASE_URL"] = os.environ.get(
    "TEST_DATABASE_URL", "postgresql+psycopg://geo:geo@localhost:5432/geo_test"
)
os.environ["APP_ENV"] = "test"
os.environ["CELERY_TASK_ALWAYS_EAGER"] = "true"
os.environ["FILE_STORAGE_PATH"] = str(_TMP / "uploads")
os.environ["TEMP_DIR"] = str(_TMP / "tmp")
os.environ["LOG_LEVEL"] = "WARNING"
os.environ["REDIS_URL"] = os.environ.get("TEST_REDIS_URL", "redis://localhost:6379/15")
os.environ.pop("PROMETHEUS_MULTIPROC_DIR", None)
os.environ["WORKER_METRICS_PORT"] = "0"

from sqlalchemy import create_engine, text  # noqa: E402

from app.core.config import get_settings  # noqa: E402


@pytest.fixture(scope="session")
def database_ready() -> bool:
    try:
        engine = create_engine(get_settings().database_url, connect_args={"connect_timeout": 3})
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        engine.dispose()
    except Exception as exc:
        pytest.skip(f"PostGIS test database unavailable: {exc}")
    return True


@pytest.fixture(scope="session")
def migrated_db(database_ready: bool) -> bool:
    """Build the schema through the real Alembic migration (also exercises it)."""
    from alembic.config import Config

    from alembic import command

    root = Path(__file__).resolve().parent.parent
    cfg = Config(str(root / "alembic.ini"))
    cfg.set_main_option("script_location", str(root / "alembic"))
    command.upgrade(cfg, "head")
    return True


@pytest.fixture
def db(migrated_db: bool) -> Iterator[None]:
    from app.db.session import get_engine

    with get_engine().begin() as conn:
        conn.execute(
            text("TRUNCATE measurements, features, processing_jobs, files RESTART IDENTITY CASCADE")
        )
    yield


@pytest.fixture
def session(db: None):  # type: ignore[no-untyped-def]
    from app.db.session import get_session_factory

    with get_session_factory()() as s:
        yield s


@pytest.fixture
def client(db: None):  # type: ignore[no-untyped-def]
    from fastapi.testclient import TestClient

    from app.main import app

    with TestClient(app, raise_server_exceptions=False) as c:
        yield c


@pytest.fixture(scope="session")
def sample_dir(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Deterministic sample data, regenerated per test session (not read from the repo)."""
    from scripts.sample_geometries import generate_all

    out = tmp_path_factory.mktemp("samples")
    generate_all(out)
    return out


@pytest.fixture
def settings_env(monkeypatch: pytest.MonkeyPatch):  # type: ignore[no-untyped-def]
    """Override settings for one test and always restore the cached Settings afterwards."""

    def apply(**values: str) -> None:
        for key, value in values.items():
            monkeypatch.setenv(key.upper(), value)
        get_settings.cache_clear()

    yield apply
    monkeypatch.undo()
    get_settings.cache_clear()


@pytest.fixture
def storage_keys():  # type: ignore[no-untyped-def]
    from app.services.container import get_storage

    return lambda: get_storage().list_keys()
