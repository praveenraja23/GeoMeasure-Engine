from __future__ import annotations

import io
import time
import zipfile
from pathlib import Path
from typing import Any

from fastapi.testclient import TestClient

SHP_HEADER = (9994).to_bytes(4, "big") + b"\x00" * 96  # minimal valid .shp file-code header


def make_zip(path: Path, entries: dict[str, bytes], *, symlink: str | None = None) -> Path:
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in entries.items():
            zf.writestr(name, data)
        if symlink:
            info = zipfile.ZipInfo(symlink)
            info.create_system = 3
            info.external_attr = 0o120777 << 16
            zf.writestr(info, "target.shp")
    return path


def shapefile_entries(stem: str = "a") -> dict[str, bytes]:
    return {f"{stem}.shp": SHP_HEADER, f"{stem}.shx": b"x", f"{stem}.dbf": b"d"}


def upload_bytes(
    client: TestClient, name: str, data: bytes, content_type: str | None = None
) -> Any:
    files = {
        "file": (name, io.BytesIO(data), content_type) if content_type else (name, io.BytesIO(data))
    }
    return client.post("/api/v1/files/", files=files)


def upload_path(client: TestClient, path: Path) -> Any:
    ctype = "application/zip" if path.suffix == ".zip" else "application/vnd.google-earth.kml+xml"
    return upload_bytes(client, path.name, path.read_bytes(), ctype)


def wait_for(client: TestClient, file_id: str, timeout: float = 30) -> dict[str, Any]:
    deadline = time.time() + timeout
    while time.time() < deadline:
        body = client.get(f"/api/v1/files/{file_id}/").json()
        if body["status"] in {"COMPLETED", "PARTIALLY_COMPLETED", "FAILED"}:
            return body  # type: ignore[no-any-return]
        time.sleep(0.2)
    raise TimeoutError(file_id)
