import pytest

from scripts.benchmark import run


@pytest.mark.performance
def test_thousand_feature_dataset_processes_completely(db):
    result = run(1000)
    assert result["end_to_end_with_postgis"]["status"] in {"COMPLETED", "PARTIALLY_COMPLETED"}
    assert result["pipeline_only"]["features_per_second"] > 0
