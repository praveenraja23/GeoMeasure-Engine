import zipfile

import pytest

from app.core.exceptions import (
    CorruptGeodataError,
    InvalidArchiveError,
    MissingShapefileComponentError,
    MultipleShapefilesError,
    UnsafeArchiveError,
)
from app.utils.file_validation import ArchiveLimits, extract_shapefile, inspect_shapefile_archive
from tests.helpers import SHP_HEADER, make_zip, shapefile_entries

LIMITS = ArchiveLimits(
    max_entries=12, max_extracted_bytes=100 * 1024 * 1024, max_compression_ratio=100
)


def zip_of(tmp_path, entries, **kw):
    return make_zip(tmp_path / "t.zip", entries, **kw)


def test_valid_archive_accepted(tmp_path):
    arch = inspect_shapefile_archive(
        zip_of(tmp_path, {**shapefile_entries(), "a.prj": b"p", "a.cpg": b"UTF-8"}), LIMITS
    )
    assert set(arch.members) == {"shp", "shx", "dbf", "prj", "cpg"}


def test_single_top_level_folder_is_supported(tmp_path):
    entries = {f"survey/{k}": v for k, v in shapefile_entries().items()}
    assert "shp" in inspect_shapefile_archive(zip_of(tmp_path, entries), LIMITS).members


def test_uppercase_extensions_and_macos_metadata_tolerated(tmp_path):
    entries = {
        "A.SHP": SHP_HEADER,
        "A.SHX": b"x",
        "A.DBF": b"d",
        "__MACOSX/._A.shp": b"junk",
        ".DS_Store": b"x",
    }
    assert "shp" in inspect_shapefile_archive(zip_of(tmp_path, entries), LIMITS).members


@pytest.mark.parametrize(
    "name",
    [
        "../evil.shp",
        "a/../../evil.shp",
        "..\\evil.shp",
        "/etc/passwd.shp",
        "C:\\x\\a.shp",
        "\\\\srv\\share\\a.shp",
    ],
)
def test_path_traversal_and_absolute_paths_rejected(tmp_path, name):
    with pytest.raises(UnsafeArchiveError):
        inspect_shapefile_archive(zip_of(tmp_path, {**shapefile_entries(), name: b"x"}), LIMITS)


def test_symlink_entry_rejected(tmp_path):
    with pytest.raises(UnsafeArchiveError):
        inspect_shapefile_archive(zip_of(tmp_path, shapefile_entries(), symlink="link.shp"), LIMITS)


def test_too_many_entries_rejected(tmp_path):
    entries = {**shapefile_entries(), **{f"x{i}.prj": b"p" for i in range(20)}}
    with pytest.raises(UnsafeArchiveError, match="more than"):
        inspect_shapefile_archive(zip_of(tmp_path, entries), LIMITS)


def test_zip_bomb_ratio_rejected_even_when_size_limit_is_generous(tmp_path):
    entries = {**shapefile_entries(), "a.dbf": b"\x00" * (30 * 1024 * 1024)}  # ~30 KB compressed
    with pytest.raises(UnsafeArchiveError, match="compression ratio"):
        inspect_shapefile_archive(zip_of(tmp_path, entries), LIMITS)


def test_declared_size_over_limit_rejected(tmp_path):
    tiny = ArchiveLimits(12, 1024, 10_000)
    with pytest.raises(UnsafeArchiveError, match="exceeds"):
        inspect_shapefile_archive(
            zip_of(tmp_path, {**shapefile_entries(), "a.dbf": b"d" * 4096}), tiny
        )


def test_actual_decompressed_bytes_are_enforced_during_extraction(tmp_path, monkeypatch):
    # Simulate a header that under-reports sizes: validation passes, extraction must still stop.
    path = zip_of(tmp_path, {**shapefile_entries(), "a.dbf": b"d" * 10_000})
    monkeypatch.setattr(
        "app.utils.file_validation.inspect_shapefile_archive",
        lambda p, limits: inspect_shapefile_archive(p, LIMITS),
    )
    out = tmp_path / "out"
    out.mkdir()
    with pytest.raises(UnsafeArchiveError, match="Decompressed"):
        extract_shapefile(path, out, ArchiveLimits(12, 5_000, 10_000))


def test_unexpected_member_type_rejected(tmp_path):
    with pytest.raises(InvalidArchiveError, match="Unexpected file"):
        inspect_shapefile_archive(
            zip_of(tmp_path, {**shapefile_entries(), "payload.exe": b"MZ"}), LIMITS
        )


def test_deep_nesting_rejected(tmp_path):
    entries = {f"a/b/{k}": v for k, v in shapefile_entries().items()}
    with pytest.raises(UnsafeArchiveError, match="nesting"):
        inspect_shapefile_archive(zip_of(tmp_path, entries), LIMITS)


def test_multiple_shapefiles_are_ambiguous(tmp_path):
    with pytest.raises(MultipleShapefilesError):
        inspect_shapefile_archive(
            zip_of(tmp_path, {**shapefile_entries("a"), **shapefile_entries("b")}), LIMITS
        )


@pytest.mark.parametrize("missing", ["shx", "dbf"])
def test_missing_required_component(tmp_path, missing):
    entries = {k: v for k, v in shapefile_entries().items() if not k.endswith(missing)}
    with pytest.raises(MissingShapefileComponentError, match=missing):
        inspect_shapefile_archive(zip_of(tmp_path, entries), LIMITS)


def test_archive_without_shp_rejected(tmp_path):
    with pytest.raises(MissingShapefileComponentError):
        inspect_shapefile_archive(zip_of(tmp_path, {"a.dbf": b"d", "a.prj": b"p"}), LIMITS)


def test_sidecar_without_matching_shp_rejected(tmp_path):
    with pytest.raises(MissingShapefileComponentError):
        inspect_shapefile_archive(
            zip_of(tmp_path, {**shapefile_entries("a"), "orphan.dbf": b"d"}), LIMITS
        )


def test_not_a_zip(tmp_path):
    p = tmp_path / "x.zip"
    p.write_bytes(b"this is not a zip")
    with pytest.raises(InvalidArchiveError):
        inspect_shapefile_archive(p, LIMITS)


def test_bad_shp_signature_rejected(tmp_path):
    entries = {**shapefile_entries(), "a.shp": b"\x00\x00\x00\x00" + b"\x00" * 96}
    with pytest.raises(CorruptGeodataError, match="header"):
        inspect_shapefile_archive(zip_of(tmp_path, entries), LIMITS)


def test_encrypted_flag_rejected(tmp_path):
    raw = bytearray(zip_of(tmp_path, shapefile_entries()).read_bytes())
    for sig, offset in (
        (b"PK\x03\x04", 6),
        (b"PK\x01\x02", 8),
    ):  # set general-purpose bit 0 everywhere
        pos = raw.find(sig)
        while pos != -1:
            raw[pos + offset] |= 0x1
            pos = raw.find(sig, pos + 4)
    path = tmp_path / "enc.zip"
    path.write_bytes(bytes(raw))
    with pytest.raises(InvalidArchiveError, match="Encrypted"):
        inspect_shapefile_archive(path, LIMITS)


def test_duplicate_entries_rejected(tmp_path):
    import warnings

    path = tmp_path / "dup.zip"
    with zipfile.ZipFile(path, "w") as zf, warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for name, data in {**shapefile_entries(), "A.SHP": SHP_HEADER}.items():
            zf.writestr(name, data)
    with pytest.raises(InvalidArchiveError, match="duplicate"):
        inspect_shapefile_archive(path, LIMITS)
