import pytest

from tests.helpers import make_zip, shapefile_entries, upload_bytes

KML_OK = b'<?xml version="1.0"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document/></kml>'


def assert_problem(r, status, code):
    assert r.status_code == status, r.text
    assert r.json()["error_code"] == code and r.headers["content-type"].startswith(
        "application/problem+json"
    )


def test_unsupported_extension(client, storage_keys):
    before = storage_keys()
    assert_problem(upload_bytes(client, "data.geojson", b"{}"), 415, "INVALID_FILE_TYPE")
    assert storage_keys() == before


def test_wrong_content_type_for_extension(client):
    assert_problem(upload_bytes(client, "a.kml", KML_OK, "image/png"), 415, "INVALID_FILE_TYPE")
    assert_problem(upload_bytes(client, "a.zip", b"PK", "text/html"), 415, "INVALID_FILE_TYPE")


def test_zip_extension_but_not_a_zip(client):
    assert_problem(
        upload_bytes(client, "a.zip", b"<kml/>", "application/zip"), 400, "INVALID_ARCHIVE"
    )


def test_kml_extension_but_zip_content(client):
    assert_problem(
        upload_bytes(client, "a.kml", b"PK\x03\x04abc", "application/xml"), 415, "INVALID_FILE_TYPE"
    )


def test_empty_upload(client):
    assert_problem(upload_bytes(client, "a.kml", b"", "application/xml"), 400, "CORRUPT_GEODATA")


def test_malformed_kml(client, storage_keys):
    before = storage_keys()
    assert_problem(
        upload_bytes(client, "a.kml", b"<kml><Document></kml>", "application/xml"),
        400,
        "CORRUPT_GEODATA",
    )
    assert storage_keys() == before


def test_xxe_external_entity_is_rejected(client):
    xxe = b'<?xml version="1.0"?><!DOCTYPE k [<!ENTITY x SYSTEM "file:///etc/passwd">]><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>&x;</name></Document></kml>'
    assert_problem(upload_bytes(client, "a.kml", xxe, "application/xml"), 400, "UNSAFE_CONTENT")


def test_billion_laughs_is_rejected_without_expansion(client):
    bomb = (
        b'<?xml version="1.0"?><!DOCTYPE l [<!ENTITY a "aaaaaaaaaa"><!ENTITY b "&a;&a;&a;&a;&a;&a;&a;&a;&a;&a;">'
        b'<!ENTITY c "&b;&b;&b;&b;&b;&b;&b;&b;&b;&b;">]><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>&c;</name></Document></kml>'
    )
    assert_problem(upload_bytes(client, "a.kml", bomb, "application/xml"), 400, "UNSAFE_CONTENT")


def test_oversized_upload_rejected_by_content_length_precheck(client, settings_env, storage_keys):
    settings_env(max_upload_size_mb="1")
    before = storage_keys()
    assert_problem(
        upload_bytes(client, "big.kml", b"<" + b"a" * (2 * 1024 * 1024), "application/xml"),
        413,
        "FILE_TOO_LARGE",
    )
    assert storage_keys() == before


def test_oversized_upload_rejected_while_streaming_and_partial_file_removed(
    client, settings_env, storage_keys
):
    settings_env(max_upload_size_mb="1")
    before = storage_keys()
    body = KML_OK + b" " * (
        1024 * 1024 + 10_000
    )  # inside the multipart-overhead allowance, over the file limit
    assert_problem(upload_bytes(client, "big.kml", body, "application/xml"), 413, "FILE_TOO_LARGE")
    assert storage_keys() == before  # no .part or final file left behind


@pytest.mark.parametrize(
    ("entries", "symlink", "code"),
    [
        ({**shapefile_entries(), "../evil.shp": b"x"}, None, "UNSAFE_ARCHIVE"),
        ({**shapefile_entries(), "/abs/evil.shp": b"x"}, None, "UNSAFE_ARCHIVE"),
        (shapefile_entries(), "link.shp", "UNSAFE_ARCHIVE"),
        (
            {k: v for k, v in shapefile_entries().items() if not k.endswith("dbf")},
            None,
            "MISSING_SHAPEFILE_COMPONENT",
        ),
        ({**shapefile_entries("a"), **shapefile_entries("b")}, None, "MULTIPLE_SHAPEFILES"),
        ({**shapefile_entries(), "x.exe": b"MZ"}, None, "INVALID_ARCHIVE"),
    ],
)
def test_malicious_archives_rejected_at_upload(
    client, tmp_path, storage_keys, entries, symlink, code
):
    before = storage_keys()
    path = make_zip(tmp_path / "t.zip", entries, symlink=symlink)
    assert_problem(upload_bytes(client, "t.zip", path.read_bytes(), "application/zip"), 400, code)
    assert storage_keys() == before


def test_zip_bomb_rejected_at_upload(client, tmp_path):
    path = make_zip(
        tmp_path / "bomb.zip", {**shapefile_entries(), "a.dbf": b"\x00" * (30 * 1024 * 1024)}
    )
    assert_problem(
        upload_bytes(client, "bomb.zip", path.read_bytes(), "application/zip"),
        400,
        "UNSAFE_ARCHIVE",
    )


def test_sql_injection_attempts_in_query_parameters_are_inert(client, sample_dir):
    from tests.helpers import upload_path, wait_for

    fid = upload_path(client, sample_dir / "sample.kml").json()["id"]
    wait_for(client, fid)
    for q in (
        "geometry_type=Polygon'%3BDROP TABLE files%3B--",
        "bbox=1,2,3,4); DROP TABLE files;--",
    ):
        assert client.get(f"/api/v1/files/{fid}/features?{q}").status_code == 422
    assert client.get(f"/api/v1/files/{fid}/").status_code == 200
