import itertools
import json
import uuid

import pytest
from sqlalchemy import text

from app.db.session import get_engine
from tests.helpers import upload_path, wait_for


@pytest.fixture
def kml_id(client, sample_dir):
    fid = upload_path(client, sample_dir / "sample.kml").json()["id"]
    assert wait_for(client, fid)["status"] == "COMPLETED"
    return fid


def test_file_info_is_assignment_compatible(client, kml_id):
    r = client.get(f"/api/v1/files/{kml_id}/")
    b = r.json()
    assert r.status_code == 200
    for key in ("id", "filename", "feature_count", "crs", "status"):
        assert key in b
    assert (b["crs"], b["source_crs"], b["measurement_crs"]) == (
        "EPSG:4326",
        "EPSG:4326",
        "EPSG:32644",
    )
    assert b["measurement_units"] == "metre" and "UTM" in b["measurement_crs_name"]
    assert (b["feature_count"], b["successful_feature_count"], b["failed_feature_count"]) == (
        7,
        7,
        0,
    )
    assert b["processing_duration_ms"] is not None and b["error_code"] is None


def test_trailing_slash_and_plain_paths_both_answer_directly(client, kml_id):
    for suffix in ("", "/"):
        assert (
            client.get(f"/api/v1/files/{kml_id}{suffix}", follow_redirects=False).status_code == 200
        )
        assert (
            client.get(
                f"/api/v1/files/{kml_id}/measurements{suffix}", follow_redirects=False
            ).status_code
            == 200
        )
        assert (
            client.get(
                f"/api/v1/files/{kml_id}/features{suffix}", follow_redirects=False
            ).status_code
            == 200
        )


def test_unknown_and_malformed_ids(client):
    r = client.get(f"/api/v1/files/{uuid.uuid4()}/")
    assert r.status_code == 404 and r.json()["error_code"] == "FILE_NOT_FOUND"
    assert client.get("/api/v1/files/not-a-uuid/").status_code == 422


def test_measurements_pagination(client, kml_id):
    p1 = client.get(f"/api/v1/files/{kml_id}/measurements/?page=1&limit=3").json()
    assert (p1["page"], p1["limit"], p1["total"], p1["has_next"]) == (1, 3, 7, True)
    assert [i["feature_id"] for i in p1["items"]] == [0, 1, 2]
    p3 = client.get(f"/api/v1/files/{kml_id}/measurements/?page=3&limit=3").json()
    assert len(p3["items"]) == 1 and p3["has_next"] is False
    assert client.get(f"/api/v1/files/{kml_id}/measurements/?page=9&limit=3").json()["items"] == []


@pytest.mark.parametrize(
    "query",
    [
        "limit=0",
        "limit=100000",
        "page=0",
        "page=-1",
        "limit=abc",
        "measurement_status=BOGUS",
        "geometry_type=Circle",
    ],
)
def test_measurement_query_validation(client, kml_id, query):
    r = client.get(f"/api/v1/files/{kml_id}/measurements/?{query}")
    assert r.status_code == 422 and r.headers["content-type"].startswith("application/problem+json")


def test_measurement_semantics_per_geometry_type(client, kml_id):
    items = {
        i["geometry_type"]: i
        for i in client.get(f"/api/v1/files/{kml_id}/measurements/?limit=50").json()["items"]
    }
    point, line, poly = items["Point"], items["LineString"], items["Polygon"]
    assert (
        point["measurement_status"] == "NOT_REQUIRED"
        and point["area_m2"] is None
        and point["length_m"] is None
    )
    assert (
        line["length_m"] > 0
        and line["area_m2"] is None
        and line["length_km"] == pytest.approx(line["length_m"] / 1000)
    )
    assert (
        poly["area_m2"] > 0
        and poly["length_m"] is None
        and poly["area_hectares"] == pytest.approx(poly["area_m2"] / 10000)
    )
    assert items["MultiPolygon"]["area_m2"] > 0 and items["MultiLineString"]["length_m"] > 0
    assert all("geometry" not in i for i in items.values())  # measurements stay light


def test_measurement_filters(client, kml_id):
    r = client.get(f"/api/v1/files/{kml_id}/measurements/?geometry_type=Polygon").json()
    assert r["total"] == 2 and {i["geometry_type"] for i in r["items"]} == {"Polygon"}
    r = client.get(f"/api/v1/files/{kml_id}/measurements/?measurement_status=NOT_REQUIRED").json()
    assert r["total"] == 1


def test_repaired_geometry_is_visible_in_measurements_and_features(client, kml_id):
    repaired = [
        i
        for i in client.get(f"/api/v1/files/{kml_id}/measurements/?limit=50").json()["items"]
        if i["was_geometry_repaired"]
    ]
    assert (
        len(repaired) == 1
        and repaired[0]["validity_status"] == "REPAIRED"
        and repaired[0]["geometry_type"] == "MultiPolygon"
    )
    feat = client.get(f"/api/v1/files/{kml_id}/features/{repaired[0]['feature_id']}").json()
    assert (feat["is_valid_before"], feat["is_valid_after"], feat["was_repaired"]) == (
        False,
        True,
        True,
    )
    assert feat["source_geometry_type"] == "Polygon" and feat["repair_method"]


def test_features_listing_and_detail(client, kml_id):
    r = client.get(f"/api/v1/files/{kml_id}/features?limit=100").json()
    assert r["total"] == 7
    first = r["items"][0]
    assert first["feature_id"] == 0 and first["geometry"]["type"] == "Point"
    assert first["geometry"]["coordinates"] == [78.0766, 10.9601]  # lon, lat order preserved
    assert first["source_crs"] == "EPSG:4326" and first["storage_crs"] == "EPSG:4326"
    assert (
        first["properties"]["Name"] == "Survey Marker"
        and first["properties"]["owner"] == "Karur Survey Dept"
    )
    assert client.get(f"/api/v1/files/{kml_id}/features/2").json()["properties"]["Name"] == "Plot A"
    assert client.get(f"/api/v1/files/{kml_id}/features/999").status_code == 404
    slim = client.get(f"/api/v1/files/{kml_id}/features?include_geometry=false").json()["items"][0]
    assert slim["geometry"] is None


def test_feature_filters(client, kml_id):
    base = f"/api/v1/files/{kml_id}/features"
    assert client.get(f"{base}?geometry_type=LineString").json()["total"] == 1
    hit = client.get(f"{base}?bbox=78.049,10.899,78.061,10.911").json()
    assert [i["properties"]["Name"] for i in hit["items"]] == ["Plot A"]
    assert client.get(f"{base}?bbox=0,0,1,1").json()["total"] == 0
    both = client.get(f"{base}?bbox=77,10,79,11&geometry_type=Point").json()
    assert both["total"] == 1


@pytest.mark.parametrize(
    "bbox",
    ["10,10,5,5", "1,2,3", "a,b,c,d", "-200,0,10,10", "0,-95,10,10", "170,0,-170,10", "1,1,1,2"],
)
def test_bbox_validation(client, kml_id, bbox):
    r = client.get(f"/api/v1/files/{kml_id}/features?bbox={bbox}")
    assert r.status_code == 422 and r.json()["error_code"] == "INVALID_QUERY"


def test_geojson_is_valid_wgs84_feature_collection(client, kml_id):
    r = client.get(f"/api/v1/files/{kml_id}/geojson?limit=100")
    assert r.status_code == 200
    fc = r.json()
    assert fc["type"] == "FeatureCollection" and fc["numberMatched"] == fc["numberReturned"] == 7
    for f in fc["features"]:
        assert f["type"] == "Feature" and isinstance(f["id"], int) and "type" in f["geometry"]
        assert "area_m2" not in f["properties"]
        json.dumps(f)
    polygon = next(
        f
        for f in fc["features"]
        if f["geometry"]["type"] == "Polygon" and f["properties"]["Name"] == "Plot A"
    )
    ring = polygon["geometry"]["coordinates"][0]
    signed = sum(x1 * y2 - x2 * y1 for (x1, y1), (x2, y2) in itertools.pairwise(ring))
    assert signed > 0  # RFC 7946: exterior rings counter-clockwise
    assert all(-180 <= x <= 180 and -90 <= y <= 90 for x, y in ring)


def test_geojson_paging_links(client, kml_id):
    fc = client.get(f"/api/v1/files/{kml_id}/geojson?limit=3").json()
    assert fc["numberReturned"] == 3 and fc["numberMatched"] == 7
    assert {link["rel"] for link in fc["links"]} == {"self", "next"}


def test_job_endpoint_reports_real_progress(client, sample_dir):
    up = upload_path(client, sample_dir / "sample.kml").json()
    wait_for(client, up["id"])
    job = client.get(f"/api/v1/jobs/{up['job_id']}").json()
    assert job["status"] == "COMPLETED" and job["attempt"] == 1
    assert job["progress"] == {"processed_features": 7, "total_features": 7}
    assert client.get(f"/api/v1/jobs/{uuid.uuid4()}").status_code == 404


def test_delete_removes_rows_and_stored_object(client, kml_id, storage_keys):
    assert f"{kml_id}.kml" in storage_keys()
    assert client.delete(f"/api/v1/files/{kml_id}").status_code == 204
    assert client.get(f"/api/v1/files/{kml_id}/").status_code == 404
    assert f"{kml_id}.kml" not in storage_keys()
    with get_engine().connect() as c:
        assert (
            c.execute(
                text(
                    "SELECT (SELECT count(*) FROM features)+(SELECT count(*) FROM measurements)+(SELECT count(*) FROM processing_jobs)"
                )
            ).scalar()
            == 0
        )
    assert client.delete(f"/api/v1/files/{kml_id}").status_code == 404


def test_delete_while_processing_conflicts(client, kml_id):
    with get_engine().begin() as c:
        c.execute(
            text(
                "UPDATE files SET status='PROCESSING', feature_count=0, successful_feature_count=0, failed_feature_count=0"
            )
        )
    r = client.delete(f"/api/v1/files/{kml_id}")
    assert r.status_code == 409 and r.json()["error_code"] == "FILE_BUSY"
