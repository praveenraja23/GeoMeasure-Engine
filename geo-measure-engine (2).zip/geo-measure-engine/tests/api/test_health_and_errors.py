import pytest

from app.api.deps import get_db
from app.main import app


def test_liveness_never_touches_dependencies(client):
    assert client.get("/health/live").json() == {"status": "ok"}


def test_readiness_reports_database_and_postgis(client):
    r = client.get("/health/ready")
    assert r.status_code == 200
    checks = r.json()["checks"]
    assert checks["database"] == "ok" and checks["postgis"]


def test_readiness_503_when_database_down_but_liveness_still_ok(client, monkeypatch):
    class Broken:
        def connect(self):
            raise RuntimeError("db down")

    monkeypatch.setattr("app.api.v1.health.get_engine", lambda: Broken())
    r = client.get("/health/ready")
    assert r.status_code == 503 and r.json()["checks"]["database"] == "unavailable"
    assert client.get("/health/live").status_code == 200


def test_metrics_endpoint_exposes_prometheus_text(client, sample_dir):
    from tests.helpers import upload_path

    upload_path(client, sample_dir / "sample.kml")
    body = client.get("/metrics").text
    assert 'uploaded_files_total{format="KML",outcome="accepted"}' in body
    assert "api_request_duration_seconds_bucket" in body
    assert "processing_duration_seconds" in body and "features_processed_total" in body


def test_problem_details_shape_for_validation_errors(client):
    r = client.get("/api/v1/files/not-a-uuid/")
    body = r.json()
    assert r.status_code == 422 and r.headers["content-type"].startswith("application/problem+json")
    assert {
        "type",
        "title",
        "status",
        "detail",
        "instance",
        "error_code",
        "request_id",
    } <= body.keys()
    assert (
        body["type"].endswith("/invalid-query") and body["instance"] == "/api/v1/files/not-a-uuid/"
    )


def test_unknown_route_and_method_are_problem_json(client):
    assert client.get("/api/v1/nope").json()["status"] == 404
    r = client.put("/api/v1/files/")
    assert r.status_code == 405 and r.json()["title"] == "Method not allowed"


def test_unexpected_errors_do_not_leak_internals(client):
    def explode():
        raise RuntimeError("secret connection string postgresql://user:pw@host")

    app.dependency_overrides[get_db] = explode
    try:
        r = client.get("/api/v1/files/00000000-0000-0000-0000-000000000000/")
    finally:
        app.dependency_overrides.pop(get_db, None)
    assert r.status_code == 500
    text = r.text
    assert "secret" not in text and "Traceback" not in text and "postgresql://" not in text
    assert r.json()["error_code"] == "INTERNAL_ERROR" and r.json()["request_id"]


@pytest.mark.parametrize("path", ["/docs", "/openapi.json"])
def test_openapi_and_docs_available(client, path):
    assert client.get(path).status_code == 200


def test_openapi_documents_core_endpoints_with_tags_and_errors(client):
    spec = client.get("/openapi.json").json()
    paths = spec["paths"]
    for p in (
        "/api/v1/files/",
        "/api/v1/files/{file_id}/",
        "/api/v1/files/{file_id}/measurements/",
        "/api/v1/files/{file_id}/features",
        "/api/v1/files/{file_id}/geojson",
        "/api/v1/jobs/{job_id}",
        "/health/live",
        "/health/ready",
    ):
        assert p in paths, p
    upload = paths["/api/v1/files/"]["post"]
    assert (
        upload["tags"] == ["Files"]
        and "202" in upload["responses"]
        and {"400", "413", "415"} <= upload["responses"].keys()
    )
    assert {t["name"] for t in spec["tags"]} == {
        "Files",
        "Measurements",
        "Features",
        "Jobs",
        "Health",
    }
