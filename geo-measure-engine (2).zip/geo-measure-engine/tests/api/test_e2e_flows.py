"""Upload -> process -> query, asserted against independent geodesic references."""

import json

import pytest

from tests.helpers import upload_path, wait_for

TOLERANCE = 0.005  # UTM scale-factor distortion at ~3 deg from the central meridian is ~0.2%


@pytest.mark.parametrize(
    "sample",
    [
        "sample.kml",
        "sample_shapefile.zip",
        "sample_shapefile_lines.zip",
        "sample_shapefile_points.zip",
    ],
)
def test_sample_matches_reference_values(client, sample_dir, sample):
    expected = json.loads((sample_dir / "expected.json").read_text())[sample]
    fid = upload_path(client, sample_dir / sample).json()["id"]
    info = wait_for(client, fid)
    assert info["status"] == "COMPLETED" and info["measurement_crs"] == "EPSG:32644"

    measurements = {
        m["feature_id"]: m
        for m in client.get(f"/api/v1/files/{fid}/measurements/?limit=100").json()["items"]
    }
    features = client.get(f"/api/v1/files/{fid}/features?limit=100").json()["items"]
    by_name = {
        (f["properties"].get("Name") or f["properties"].get("name")): measurements[f["feature_id"]]
        for f in features
    }
    assert len(by_name) == len(expected)
    for exp in expected:
        got = by_name[exp["name"]]
        assert got["geometry_type"] == exp["geometry_type"]
        assert got["was_geometry_repaired"] is exp["was_repaired"]
        if "expected_area_m2" in exp:
            assert got["area_m2"] == pytest.approx(exp["expected_area_m2"], rel=TOLERANCE)
        elif "expected_length_m" in exp:
            assert got["length_m"] == pytest.approx(exp["expected_length_m"], rel=TOLERANCE)
        else:
            assert got["measurement_status"] == "NOT_REQUIRED"


def test_shapefile_without_prj_reports_crs_unknown(client, sample_dir):
    fid = upload_path(client, sample_dir / "sample_shapefile_no_prj.zip").json()["id"]
    info = wait_for(client, fid)
    assert (
        info["status"] == "FAILED" and info["error_code"] == "CRS_UNKNOWN" and info["crs"] is None
    )
    item = client.get(f"/api/v1/files/{fid}/measurements/").json()["items"][0]
    assert (
        item["measurement_status"] == "FAILED"
        and item["error_code"] == "CRS_UNKNOWN"
        and item["area_m2"] is None
    )
