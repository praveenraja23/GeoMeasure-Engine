import hashlib
import uuid

from app.api.deps import get_queue
from app.core.exceptions import ServiceUnavailableError
from app.main import app
from tests.helpers import upload_bytes, upload_path, wait_for

ACCEPTED = {"QUEUED", "PROCESSING", "COMPLETED", "PARTIALLY_COMPLETED", "FAILED"}


def test_kml_upload_returns_202_with_location_and_hash(client, sample_dir, storage_keys):
    path = sample_dir / "sample.kml"
    r = upload_path(client, path)
    assert r.status_code == 202
    body = r.json()
    assert body["filename"] == "sample.kml" and body["file_type"] == "KML"
    assert body["status"] in ACCEPTED
    assert body["sha256"] == hashlib.sha256(path.read_bytes()).hexdigest()
    assert body["file_size_bytes"] == path.stat().st_size
    assert r.headers["location"] == f"/api/v1/files/{body['id']}/"
    uuid.UUID(body["job_id"])
    assert f"{body['id']}.kml" in storage_keys()  # stored under a UUID name, not the upload name


def test_shapefile_zip_upload(client, sample_dir):
    r = upload_path(client, sample_dir / "sample_shapefile.zip")
    assert r.status_code == 202 and r.json()["file_type"] == "SHAPEFILE"


def test_request_id_is_generated_echoed_and_sanitised(client, sample_dir):
    assert len(client.get("/health/live").headers["x-request-id"]) >= 8
    assert (
        client.get("/health/live", headers={"X-Request-ID": "trace-12345678"}).headers[
            "x-request-id"
        ]
        == "trace-12345678"
    )
    evil = client.get("/health/live", headers={"X-Request-ID": "bad id\r\nX: y"}).headers[
        "x-request-id"
    ]
    assert evil != "bad id" and " " not in evil


def test_duplicate_uploads_are_allowed_and_share_a_hash(client, sample_dir):
    a, b = (upload_path(client, sample_dir / "sample.kml").json() for _ in range(2))
    assert a["id"] != b["id"] and a["sha256"] == b["sha256"]


def test_uploaded_name_is_metadata_only(client, sample_dir, storage_keys):
    data = (sample_dir / "sample.kml").read_bytes()
    r = upload_bytes(client, "../../etc/evil\x00name.kml", data, "application/xml")
    assert r.status_code == 202
    body = r.json()
    assert "/" not in body["filename"] and "\x00" not in body["filename"]
    assert all(
        k.startswith(
            ("a", "b", "c", "d", "e", "f", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9")
        )
        for k in storage_keys()
    )


def test_queue_outage_returns_503_and_leaves_no_residue(client, sample_dir, storage_keys):
    class DownQueue:
        def enqueue(self, *a, **k):
            raise ServiceUnavailableError("queue down")

    app.dependency_overrides[get_queue] = lambda: DownQueue()
    try:
        before = storage_keys()
        r = upload_path(client, sample_dir / "sample.kml")
        assert r.status_code == 503 and r.json()["error_code"] == "QUEUE_UNAVAILABLE"
        assert storage_keys() == before
    finally:
        app.dependency_overrides.pop(get_queue, None)


def test_processing_completes_after_upload(client, sample_dir):
    fid = upload_path(client, sample_dir / "sample.kml").json()["id"]
    assert wait_for(client, fid)["status"] == "COMPLETED"
