import numpy as np
import pytest
from shapely.geometry import LineString, MultiPolygon, Point, Polygon, box

from app.domain.enums import ErrorCode
from app.geospatial.geometry.validator import REPAIR_METHOD, GeometryValidator

v = GeometryValidator()
BOWTIE = Polygon([(0, 0), (2, 2), (2, 0), (0, 2), (0, 0)])


def test_valid_geometry_is_untouched():
    check = v.check(box(0, 0, 1, 1))
    assert (check.is_valid_before, check.is_valid_after, check.was_repaired) == (True, True, False)
    assert check.repair_method is None


def test_bowtie_is_repaired_and_recorded():
    check = v.check(BOWTIE)
    assert (check.is_valid_before, check.is_valid_after, check.was_repaired) == (False, True, True)
    assert check.repair_method == REPAIR_METHOD
    assert isinstance(check.geometry, MultiPolygon)
    assert check.geometry.area == pytest.approx(2.0)  # two triangles of area 1


def test_repair_discards_zero_area_remnants():
    sliver = Polygon([(0, 0), (1, 1), (2, 2), (0, 0)])  # collinear: no area
    check = v.check(sliver)
    assert check.geometry is None
    assert check.error_code is ErrorCode.GEOMETRY_REPAIR_FAILED
    assert not check.was_repaired


def test_nan_coordinates_rejected_not_repaired():
    check = v.check(Point(np.nan, 1))
    assert check.geometry is None
    assert check.error_code is ErrorCode.INVALID_GEOMETRY


def test_degenerate_line_fails_repair():
    check = v.check(LineString([(0, 0), (0, 0)]))
    assert check.error_code is ErrorCode.GEOMETRY_REPAIR_FAILED
