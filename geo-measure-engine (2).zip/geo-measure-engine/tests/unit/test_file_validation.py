import pytest

from app.core.exceptions import (
    CorruptGeodataError,
    UnsupportedFileTypeError,
)
from app.domain.enums import FileType
from app.utils.file_validation import detect_file_type, validate_kml

KML = '<?xml version="1.0"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document/></kml>'


@pytest.mark.parametrize(
    ("name", "ctype", "expected"),
    [
        ("a.kml", "application/vnd.google-earth.kml+xml", FileType.KML),
        ("A.KML", "text/xml", FileType.KML),
        ("a.kml", "application/octet-stream", FileType.KML),
        ("a.zip", "application/zip", FileType.SHAPEFILE),
        ("a.zip", None, FileType.SHAPEFILE),
        ("dir\\a.ZIP", "application/x-zip-compressed", FileType.SHAPEFILE),
    ],
)
def test_detect_accepts(name, ctype, expected):
    assert detect_file_type(name, ctype) is expected


@pytest.mark.parametrize(
    ("name", "ctype"),
    [
        ("a.txt", None),
        ("a.shp", None),
        ("a", None),
        ("a.kmz", None),
        ("a.zip", "image/png"),
        ("a.kml", "application/zip"),
    ],
)
def test_detect_rejects(name, ctype):
    with pytest.raises(UnsupportedFileTypeError):
        detect_file_type(name, ctype)


def write(tmp_path, content: bytes):
    p = tmp_path / "f.kml"
    p.write_bytes(content)
    return p


def test_valid_kml_passes(tmp_path):
    validate_kml(write(tmp_path, KML.encode()))


def test_bom_prefixed_kml_passes(tmp_path):
    validate_kml(write(tmp_path, b"\xef\xbb\xbf" + KML.encode()))


@pytest.mark.parametrize(
    "content",
    [b"", b"   \n", b"not xml at all", b"<kml><Document></kml>", b"<html><body/></html>"],
)
def test_malformed_kml_rejected(tmp_path, content):
    with pytest.raises(CorruptGeodataError):
        validate_kml(write(tmp_path, content))


def test_kmz_rejected_with_clear_type_error(tmp_path):
    with pytest.raises(UnsupportedFileTypeError):
        validate_kml(write(tmp_path, b"PK\x03\x04rest"))
