import pytest
from pyproj import CRS

from app.core.exceptions import CRSTransformationError, MissingCRSError
from app.geospatial.crs.resolver import MeasurementCRSResolver, crs_code

resolver = MeasurementCRSResolver(6.0)


def test_missing_crs_is_never_guessed():
    with pytest.raises(MissingCRSError) as err:
        resolver.resolve(None, (0, 0, 1, 1))
    assert err.value.code.value == "CRS_UNKNOWN"


def test_geographic_crs_resolves_local_utm():
    plan = resolver.resolve(CRS.from_epsg(4326), (78.05, 10.90, 78.07, 10.92))
    assert crs_code(plan.area_crs) == "EPSG:32644"  # UTM 44N (Tamil Nadu)
    assert plan.strategy == "local_utm"
    assert plan.units == "metre"
    assert "geographic" in plan.reason


def test_southern_hemisphere_utm():
    plan = resolver.resolve(CRS.from_epsg(4326), (151.1, -33.9, 151.3, -33.8))
    assert crs_code(plan.area_crs) == "EPSG:32756"  # UTM 56S (Sydney)


def test_projected_metre_crs_is_used_directly():
    plan = resolver.resolve(CRS.from_epsg(32644), (0, 0, 1, 1))
    assert plan.strategy == "source_projected_metre"
    assert plan.area_crs == CRS.from_epsg(32644)


def test_projected_feet_crs_is_normalised_to_metric_utm():
    plan = resolver.resolve(
        CRS.from_epsg(2263), (980000, 190000, 981000, 191000)
    )  # NY Long Island, US ft
    assert plan.area_crs != CRS.from_epsg(2263)
    assert crs_code(plan.area_crs) == "EPSG:32618"
    assert "not in metres" in plan.reason


def test_web_mercator_is_not_trusted_for_measurement():
    plan = resolver.resolve(CRS.from_epsg(3857), (8688000, 1215000, 8690000, 1217000))
    assert crs_code(plan.area_crs) == "EPSG:32644"
    assert "Mercator" in plan.reason


def test_broad_extent_uses_equal_area_and_geodesic_length():
    plan = resolver.resolve(CRS.from_epsg(4326), (-120, 30, 40, 60))
    assert crs_code(plan.area_crs) == "EPSG:6933"
    assert plan.length_crs is None
    assert plan.length_method.value == "geodesic_wgs84"


def test_antimeridian_extent_falls_back_to_broad_strategy():
    plan = resolver.resolve(CRS.from_epsg(4326), (170, -10, -170, -5))
    assert plan.strategy == "global_equal_area_geodesic"


def test_polar_extent_falls_back_to_broad_strategy():
    plan = resolver.resolve(CRS.from_epsg(4326), (10, 85, 12, 86))
    assert plan.strategy == "global_equal_area_geodesic"


def test_out_of_range_geographic_extent_is_rejected():
    with pytest.raises(CRSTransformationError):
        resolver.resolve(CRS.from_epsg(4326), (200, 0, 201, 1))


def test_no_extent_uses_global_fallback():
    assert resolver.resolve(CRS.from_epsg(4326), None).strategy == "global_equal_area_geodesic"
