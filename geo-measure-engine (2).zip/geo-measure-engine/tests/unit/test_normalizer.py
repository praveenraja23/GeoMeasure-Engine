import datetime as dt
import decimal
import math

import geopandas as gpd
import numpy as np
import pandas as pd
from shapely.geometry import GeometryCollection, Point, box

from app.geospatial.geometry.normalizer import FeatureNormalizer, json_safe, unique_columns

norm = FeatureNormalizer(max_properties_bytes=2000, max_property_value_chars=20)


def frame(geoms, **cols):
    return gpd.GeoDataFrame(cols, geometry=geoms, crs="EPSG:4326")


def test_homogeneous_collection_collapses_to_multipolygon():
    gc = GeometryCollection([box(0, 0, 1, 1), box(2, 0, 3, 1)])
    (f,) = norm.normalize_frame(frame([gc], a=[1]), 0)
    assert f.geometry_type == "MultiPolygon" and f.source_geometry_type == "GeometryCollection"


def test_single_member_collection_unwraps():
    (f,) = norm.normalize_frame(frame([GeometryCollection([Point(1, 1)])], a=[1]), 0)
    assert f.geometry_type == "Point"


def test_mixed_collection_kept_with_warning():
    gc = GeometryCollection([Point(0, 0), box(0, 0, 1, 1)])
    (f,) = norm.normalize_frame(frame([gc], a=[1]), 0)
    assert f.geometry_type == "GeometryCollection" and any("Mixed" in w for w in f.warnings)


def test_z_dropped_and_null_geometry_kept():
    feats = list(norm.normalize_frame(frame([Point(1, 2, 3), None], a=[1, 2]), 10))
    assert [f.feature_index for f in feats] == [10, 11]
    assert feats[0].geometry.has_z is False
    assert feats[1].geometry is None and feats[1].geometry_type == "Null"


def test_json_safety_matrix():
    assert json_safe(np.int64(5), 50) == (5, False)
    assert json_safe(np.float32(1.5), 50) == (1.5, False)
    assert json_safe(float("nan"), 50) == (None, False)
    assert json_safe(float("inf"), 50) == (None, False)
    assert json_safe(pd.NaT, 50) == (None, False)
    assert json_safe("   ", 50) == (None, False)
    assert json_safe("", 50) == (None, False)
    assert json_safe(decimal.Decimal("1.25"), 50) == (1.25, False)
    assert json_safe(dt.date(2026, 1, 2), 50) == ("2026-01-02", False)
    assert json_safe(pd.Timestamp("2026-01-02T03:04:05"), 50)[0] == "2026-01-02T03:04:05"
    assert json_safe(b"caf\xc3\xa9", 50) == ("café", False)
    assert json_safe("x" * 30, 20) == ("x" * 20, True)
    assert json_safe("a\x00b", 50) == ("ab", False)


def test_unserialisable_object_never_raises():
    class Weird:
        def __str__(self):
            raise RuntimeError("boom")

    assert json_safe(Weird(), 10) == (None, False)


def test_truncation_is_reported_not_silent():
    (f,) = norm.normalize_frame(frame([Point(0, 0)], name=["y" * 100]), 0)
    assert len(f.properties["name"]) == 20
    assert any("truncated" in w for w in f.warnings)


def test_oversized_properties_dropped_with_warning():
    small = FeatureNormalizer(max_properties_bytes=256, max_property_value_chars=4096)
    cols = {f"c{i}": ["v" * 100] for i in range(10)}
    (f,) = small.normalize_frame(frame([Point(0, 0)], **cols), 0)
    assert all(v is None for v in f.properties.values())
    assert any("exceed" in w for w in f.warnings)


def test_nan_attribute_becomes_null_and_json_roundtrips():
    import json

    (f,) = norm.normalize_frame(frame([Point(0, 0)], n=[math.nan], s=[""]), 0)
    assert json.loads(json.dumps(f.properties)) == {"n": None, "s": None}


def test_unique_columns():
    assert unique_columns(["a", "a", "b", "a"]) == ["a", "a_2", "b", "a_3"]
