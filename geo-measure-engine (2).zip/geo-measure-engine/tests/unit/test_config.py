import re
from pathlib import Path

import pytest
from pydantic import ValidationError

from app.core.config import Settings

ROOT = Path(__file__).resolve().parents[2]


def test_every_setting_is_documented_in_env_example():
    documented = set(
        re.findall(r"^#?\s*([A-Z][A-Z0-9_]+)=", (ROOT / ".env.example").read_text(), re.M)
    )
    missing = {name.upper() for name in Settings.model_fields} - documented
    assert not missing, f"undocumented settings: {sorted(missing)}"


def test_env_example_has_no_unknown_settings():
    keys = set(re.findall(r"^#?\s*([A-Z][A-Z0-9_]+)=", (ROOT / ".env.example").read_text(), re.M))
    known = {n.upper() for n in Settings.model_fields}
    compose_only = {"POSTGRES_USER", "POSTGRES_PASSWORD", "POSTGRES_DB", "API_PORT"}
    assert not (keys - known - compose_only)


def test_production_rejects_debug_and_placeholder_credentials():
    with pytest.raises(ValidationError):
        Settings(database_url="postgresql+psycopg://u:p@h/d", app_env="production", debug=True)
    with pytest.raises(ValidationError):
        Settings(database_url="postgresql+psycopg://u:change-me@h/d", app_env="production")


def test_settings_are_immutable():
    s = Settings(database_url="postgresql+psycopg://u:p@h/d")
    with pytest.raises(ValidationError):
        s.debug = True  # type: ignore[misc]


def test_derived_limits():
    s = Settings(database_url="postgresql+psycopg://u:p@h/d", max_upload_size_mb=2)
    assert s.max_upload_size_bytes == 2 * 1024 * 1024
    assert s.effective_broker_url == s.redis_url


def test_inconsistent_time_limits_rejected():
    with pytest.raises(ValidationError):
        Settings(database_url="x", task_soft_time_limit_seconds=100, task_time_limit_seconds=100)


def test_env_example_loads_cleanly_and_empty_values_mean_unset(monkeypatch):
    for name in Settings.model_fields:  # isolate from the test process environment
        monkeypatch.delenv(name.upper(), raising=False)
    s = Settings(_env_file=ROOT / ".env.example")  # type: ignore[call-arg]
    assert (
        s.temp_dir is None and s.celery_broker_url is None and s.otel_exporter_otlp_endpoint is None
    )
    assert s.effective_temp_dir == s.file_storage_path.parent / "tmp"
    assert s.max_upload_size_mb == 100 and s.debug is False
