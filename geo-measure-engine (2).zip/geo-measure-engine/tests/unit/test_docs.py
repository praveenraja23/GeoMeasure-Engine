"""Keep the README honest: documented facts must match the code."""

import re
from pathlib import Path

from app.domain.enums import ErrorCode

README = (Path(__file__).resolve().parents[2] / "README.md").read_text()


def test_every_error_code_is_documented():
    missing = [c.value for c in ErrorCode if f"`{c.value}`" not in README]
    assert not missing, f"undocumented error codes: {missing}"


def test_every_make_target_mentioned_exists():
    makefile = (Path(__file__).resolve().parents[2] / "Makefile").read_text()
    targets = set(re.findall(r"^([a-z][a-z-]*):", makefile, re.M))
    mentioned = set(re.findall(r"`make ([a-z-]+)", README)) | set(
        re.findall(r"^make ([a-z-]+)", README, re.M)
    )
    assert mentioned <= targets, mentioned - targets


def test_no_placeholder_markers_in_repository():
    root = Path(__file__).resolve().parents[2]
    markers = ("TODO", "FIXME", "implement later", "NotImplementedError")
    offenders = []
    for path in (
        list((root / "app").rglob("*.py"))
        + list((root / "scripts").rglob("*.py"))
        + [root / "README.md"]
    ):
        text = path.read_text()
        offenders += [f"{path.name}:{m}" for m in markers if m in text]
    assert not offenders, offenders
