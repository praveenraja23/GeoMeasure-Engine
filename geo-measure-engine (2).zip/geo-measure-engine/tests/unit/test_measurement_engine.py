import math

import pytest
from shapely.geometry import (
    GeometryCollection,
    LineString,
    MultiLineString,
    MultiPoint,
    MultiPolygon,
    Point,
    Polygon,
    box,
)

from app.domain.enums import CalculationMethod, MeasurementStatus
from app.geospatial.measurements.base import MeasurementContext
from app.geospatial.measurements.engine import MeasurementEngine

CTX = MeasurementContext("EPSG:32644")
engine = MeasurementEngine()


def test_polygon_area_and_hectares():
    r = engine.measure(box(0, 0, 100, 200), CTX)
    assert r.status is MeasurementStatus.COMPLETED
    assert r.area_m2 == pytest.approx(20_000)
    assert r.area_hectares == pytest.approx(2.0)  # 1 ha = 10,000 m2
    assert r.length_m is None and r.length_km is None
    assert r.measurement_crs == "EPSG:32644"


def test_polygon_with_hole():
    poly = Polygon(box(0, 0, 10, 10).exterior.coords, [box(2, 2, 4, 4).exterior.coords])
    assert engine.measure(poly, CTX).area_m2 == pytest.approx(96)


def test_multipolygon_area_is_sum():
    mp = MultiPolygon([box(0, 0, 10, 10), box(20, 0, 25, 10)])
    assert engine.measure(mp, CTX).area_m2 == pytest.approx(150)


def test_linestring_length():
    r = engine.measure(LineString([(0, 0), (3, 4), (3, 14)]), CTX)
    assert r.length_m == pytest.approx(15)
    assert r.length_km == pytest.approx(0.015)
    assert r.area_m2 is None


def test_multilinestring_total_length():
    ml = MultiLineString([[(0, 0), (0, 10)], [(5, 5), (5, 15)]])
    assert engine.measure(ml, CTX).length_m == pytest.approx(20)


def test_point_has_no_fabricated_zero():
    r = engine.measure(Point(1, 2), CTX)
    assert r.status is MeasurementStatus.NOT_REQUIRED
    assert r.area_m2 is None and r.length_m is None and r.warning is None


def test_multipoint_not_required_with_warning():
    r = engine.measure(MultiPoint([(0, 0), (1, 1)]), CTX)
    assert r.status is MeasurementStatus.NOT_REQUIRED
    assert "No measurement is defined" in (r.warning or "")


def test_empty_line_is_not_measurable():
    assert engine.measure(LineString(), CTX).status is MeasurementStatus.NOT_MEASURABLE


def test_unsupported_geometry_is_graceful():
    r = engine.measure(GeometryCollection([Point(0, 0), box(0, 0, 1, 1)]), CTX)
    assert r.status is MeasurementStatus.UNSUPPORTED
    assert r.error_code.value == "UNSUPPORTED_GEOMETRY"


def test_geodesic_line_length_uses_ellipsoid():
    ctx = MeasurementContext("EPSG:4326", CalculationMethod.GEODESIC)
    r = engine.measure(LineString([(0, 0), (1, 0)]), ctx)  # 1 degree of longitude at the equator
    assert r.length_m == pytest.approx(111_319.49, rel=1e-4)


def test_dimensions():
    assert engine.dimension_of("Polygon") == 2
    assert engine.dimension_of("MultiLineString") == 1
    assert engine.dimension_of("Point") == 0
    assert engine.dimension_of("GeometryCollection") is None


def test_duplicate_registration_rejected():
    from app.geospatial.measurements.point import PointMeasurementCalculator

    with pytest.raises(ValueError):
        MeasurementEngine([PointMeasurementCalculator(), PointMeasurementCalculator()])


def test_results_are_deterministic():
    g = box(0, 0, 1.2345, 6.789)
    assert math.isclose(engine.measure(g, CTX).area_m2, engine.measure(g, CTX).area_m2)
