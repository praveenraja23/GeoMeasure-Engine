import pytest

from app.core.exceptions import InvalidQueryError
from app.utils.pagination import Page, PageParams


def test_offset_and_has_next():
    p = PageParams.validated(3, 10, max_limit=100)
    assert p.offset == 20
    assert Page(list(range(10)), 35, p).has_next
    assert not Page(list(range(5)), 25, p).has_next


@pytest.mark.parametrize(("page", "limit"), [(0, 10), (-1, 10), (1, 0), (1, 101)])
def test_invalid_values_rejected(page, limit):
    with pytest.raises(InvalidQueryError):
        PageParams.validated(page, limit, max_limit=100)
