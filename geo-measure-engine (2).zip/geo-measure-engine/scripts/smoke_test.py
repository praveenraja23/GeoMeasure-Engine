"""End-to-end smoke test against a running stack (stdlib only).

    python -m scripts.smoke_test [--base-url http://localhost:8000] [--sample-dir sample_data]

Exit code 0 means: health OK, KML and Shapefile samples processed, measurements match the
independent geodesic references in sample_data/expected.json within tolerance.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any

AREA_TOLERANCE = 0.005  # UTM scale-factor distortion near zone edges is ~0.1-0.2%
LENGTH_TOLERANCE = 0.005


class SmokeTestError(AssertionError):
    """A smoke-test expectation was not met."""


def ensure(condition: object, message: object) -> None:
    if not condition:
        raise SmokeTestError(str(message))


def request(
    method: str, url: str, body: bytes | None = None, headers: dict[str, str] | None = None
) -> tuple[int, Any]:
    if not url.startswith(("http://", "https://")):
        raise SmokeTestError(f"unsupported URL scheme: {url}")
    # The URL scheme is restricted to http(s) above, which is why B310 is safe here.
    req = urllib.request.Request(url, data=body, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:  # nosec B310
            raw = resp.read()
            return resp.status, json.loads(raw) if raw else None
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read() or b"null")


def upload(base: str, path: Path) -> dict[str, Any]:
    boundary = uuid.uuid4().hex
    content_type = (
        "application/zip" if path.suffix == ".zip" else "application/vnd.google-earth.kml+xml"
    )
    body = (
        (
            f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{path.name}"\r\n'
            f"Content-Type: {content_type}\r\n\r\n"
        ).encode()
        + path.read_bytes()
        + f"\r\n--{boundary}--\r\n".encode()
    )
    status, data = request(
        "POST",
        f"{base}/api/v1/files/",
        body,
        {"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    ensure(status == 202, f"upload of {path.name} returned {status}: {data}")
    return data  # type: ignore[no-any-return]


def wait_done(base: str, file_id: str, timeout: float = 120) -> dict[str, Any]:
    deadline = time.time() + timeout
    while time.time() < deadline:
        _, info = request("GET", f"{base}/api/v1/files/{file_id}/")
        if info["status"] in {"COMPLETED", "PARTIALLY_COMPLETED", "FAILED"}:
            return info  # type: ignore[no-any-return]
        time.sleep(0.5)
    raise TimeoutError(f"file {file_id} did not finish within {timeout}s")


def check(base: str, sample: Path, expected: list[dict[str, Any]]) -> None:
    uploaded = upload(base, sample)
    info = wait_done(base, uploaded["id"])
    ensure(info["status"] in {"COMPLETED", "PARTIALLY_COMPLETED"}, info)
    _, page = request("GET", f"{base}/api/v1/files/{uploaded['id']}/measurements/?limit=100")
    items = {i["feature_id"]: i for i in page["items"]}
    ensure(
        len(items) == len(expected),
        (f"{sample.name}: {len(items)} measurements, expected {len(expected)}"),
    )
    _, feats = request("GET", f"{base}/api/v1/files/{uploaded['id']}/features?limit=100")
    names = {
        f["feature_id"]: f["properties"].get("Name") or f["properties"].get("name")
        for f in feats["items"]
    }
    by_name = {v: items[k] for k, v in names.items()}
    for exp in expected:
        got = by_name[exp["name"]]
        ensure(got["geometry_type"] == exp["geometry_type"], (exp, got))
        if "expected_area_m2" in exp:
            rel = abs(got["area_m2"] - exp["expected_area_m2"]) / exp["expected_area_m2"]
            ensure(rel < AREA_TOLERANCE, f"{exp['name']}: area off by {rel:.4%}")
        elif "expected_length_m" in exp:
            rel = abs(got["length_m"] - exp["expected_length_m"]) / exp["expected_length_m"]
            ensure(rel < LENGTH_TOLERANCE, f"{exp['name']}: length off by {rel:.4%}")
        else:
            ensure(got["measurement_status"] == "NOT_REQUIRED", got)
    print(
        f"OK  {sample.name}: {info['status']}  measurement_crs={info['measurement_crs']}  "
        f"features={info['feature_count']}"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://localhost:8000")
    parser.add_argument("--sample-dir", default="sample_data")
    args = parser.parse_args()
    base, sample_dir = args.base_url.rstrip("/"), Path(args.sample_dir)

    status, _ = request("GET", f"{base}/health/live")
    ensure(status == 200, "liveness failed")
    status, ready = request("GET", f"{base}/health/ready")
    ensure(status == 200, f"readiness failed: {ready}")
    print("OK  health/live + health/ready")

    expected = json.loads((sample_dir / "expected.json").read_text())
    for name, exp in expected.items():
        check(base, sample_dir / name, exp)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (AssertionError, TimeoutError) as err:
        print(f"SMOKE TEST FAILED: {err}", file=sys.stderr)
        sys.exit(1)
