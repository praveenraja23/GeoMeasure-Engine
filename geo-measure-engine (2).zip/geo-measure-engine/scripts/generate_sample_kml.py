"""Generate sample_data/sample.kml (deterministic)."""

from __future__ import annotations

import sys
from pathlib import Path

from scripts.sample_geometries import kml_features, write_kml


def main(out_dir: str = "sample_data") -> None:
    target = Path(out_dir)
    target.mkdir(parents=True, exist_ok=True)
    write_kml(target / "sample.kml", kml_features())
    print(f"wrote {target / 'sample.kml'}")


if __name__ == "__main__":
    main(*sys.argv[1:2])
