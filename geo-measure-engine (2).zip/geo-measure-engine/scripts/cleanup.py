"""Apply the retention policy and sweep orphaned uploads.

python -m scripts.cleanup            # uses RETENTION_DAYS
python -m scripts.cleanup --days 7
"""

from __future__ import annotations

import argparse

from app.core.config import get_settings
from app.db.session import session_scope
from app.services.cleanup_service import CleanupService
from app.services.container import get_storage


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--days", type=int, default=None, help="retention in days (default: RETENTION_DAYS)"
    )
    args = parser.parse_args()
    days = args.days or get_settings().retention_days
    with session_scope() as session:
        service = CleanupService(session, get_storage())
        purged = service.purge_expired(days)
        orphans = service.sweep_orphans()
    print(
        f"purged {purged} expired file(s) older than {days} day(s); removed {orphans} orphaned object(s)"
    )


if __name__ == "__main__":
    main()
