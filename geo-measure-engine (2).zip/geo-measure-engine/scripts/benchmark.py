"""Benchmark the processing pipeline on a generated dataset.

    python -m scripts.benchmark --features 5000 [--output benchmarks/result.json]

Reports (a) pure geospatial pipeline throughput (read + validate + project + measure, no
database) and (b) end-to-end ``ProcessingService`` throughput including bulk upserts into
PostGIS. Numbers are environment-dependent measurements, not guarantees. Uses DATABASE_URL.
"""

from __future__ import annotations

import argparse
import json
import platform
import resource
import shutil
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any

from shapely.geometry import box

from app.core.config import get_settings
from app.db.models import FileRecord
from app.db.session import session_scope
from app.domain.enums import FileStatus, FileType
from app.geospatial.crs.resolver import MeasurementCRSResolver
from app.geospatial.readers.factory import GeoFileReaderFactory
from app.repositories.file_repository import FileRepository
from app.repositories.job_repository import JobRepository
from app.services.container import build_pipeline, build_processing_service, get_storage
from app.utils.file_validation import ArchiveLimits, extract_shapefile
from scripts.sample_geometries import write_shapefile_zip


def dataset(n: int) -> list[dict[str, Any]]:
    """Deterministic grid of ~50 m squares near Karur; every 25th polygon is a bow-tie (repaired)."""
    features = []
    for i in range(n):
        lon, lat = 78.0 + (i % 100) * 0.001, 10.0 + (i // 100) * 0.001
        if i % 25 == 0:
            from shapely.geometry import Polygon

            geom = Polygon(
                [(lon, lat), (lon + 0.0005, lat + 0.0005), (lon + 0.0005, lat), (lon, lat + 0.0005)]
            )
        else:
            geom = box(lon, lat, lon + 0.0005, lat + 0.0005)
        features.append({"name": f"cell-{i}", "owner": "bench", "geometry": geom})
    return features


def peak_rss_mb() -> float:
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024  # KB on Linux


def run(n: int) -> dict[str, Any]:
    settings = get_settings()
    work = Path(tempfile.mkdtemp(prefix="geo-bench-"))
    try:
        archive = work / "bench.zip"
        write_shapefile_zip(archive, dataset(n))
        limits = ArchiveLimits(
            settings.max_zip_entries,
            settings.max_extracted_size_bytes,
            settings.max_compression_ratio,
        )
        shp = extract_shapefile(archive, work, limits)

        reader = GeoFileReaderFactory().for_type(FileType.SHAPEFILE)
        pipeline = build_pipeline(settings)
        info = reader.inspect(shp)
        plan = MeasurementCRSResolver(settings.utm_max_lon_span_deg).resolve(info.crs, info.bounds)
        started = time.perf_counter()
        processed = 0
        for batch in reader.read_batches(shp, settings.feature_batch_size):
            processed += len(pipeline.process_batch(batch.frame, batch.start_index, info.crs, plan))
        pipeline_s = time.perf_counter() - started

        file_id, key = uuid.uuid4(), None
        key = f"{file_id}.zip"
        shutil.copy(archive, get_storage()._root / key)  # type: ignore[attr-defined]
        with session_scope() as s:
            FileRepository(s).add(
                FileRecord(
                    id=file_id,
                    filename=key,
                    original_filename="bench.zip",
                    file_type=FileType.SHAPEFILE,
                    file_size_bytes=archive.stat().st_size,
                    sha256="0" * 64,
                    status=FileStatus.QUEUED,
                    storage_path=key,
                )
            )
            job_id = JobRepository(s).create(file_id).id
        started = time.perf_counter()
        outcome = build_processing_service(settings).process(
            file_id, job_id=job_id, attempt=1, is_final_attempt=True
        )
        full_s = time.perf_counter() - started
        with session_scope() as s:
            FileRepository(s).delete(file_id)
        get_storage().delete(key)

        return {
            "features": n,
            "batch_size": settings.feature_batch_size,
            "archive_kb": round(archive.stat().st_size / 1024, 1),
            "pipeline_only": {
                "seconds": round(pipeline_s, 3),
                "features_per_second": round(processed / pipeline_s),
            },
            "end_to_end_with_postgis": {
                "seconds": round(full_s, 3),
                "features_per_second": round(n / full_s),
                "status": outcome.status,
            },
            "peak_rss_mb_process": round(peak_rss_mb(), 1),
            "environment": {
                "python": platform.python_version(),
                "machine": platform.machine(),
                "cpus": __import__("os").cpu_count(),
            },
        }
    finally:
        shutil.rmtree(work, ignore_errors=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--features", type=int, default=5000)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = run(args.features)
    text = json.dumps(result, indent=2)
    print(text)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n")


if __name__ == "__main__":
    main()
