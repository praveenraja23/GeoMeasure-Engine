"""Generate sample Shapefile ZIPs and expected.json (deterministic).

A Shapefile holds exactly one geometry type, so polygons, lines and points are
delivered as three separate archives (an archive with several .shp files is rejected
as ambiguous by the API on purpose).
"""

from __future__ import annotations

import sys
from pathlib import Path

from scripts.sample_geometries import generate_all


def main(out_dir: str = "sample_data") -> None:
    generate_all(Path(out_dir))
    for path in sorted(Path(out_dir).glob("sample*")):
        print(f"wrote {path}")
    print(f"wrote {Path(out_dir) / 'expected.json'}")


if __name__ == "__main__":
    main(*sys.argv[1:2])
