"""Deterministic sample geometries near Karur, Tamil Nadu (UTM zone 44N).

Expected values are computed *independently of the application* with geodesic
mathematics on the WGS 84 ellipsoid (pyproj ``Geod``). The application measures in a
projected CRS, so agreement within a small tolerance is real evidence of correctness.
"""

from __future__ import annotations

import json
import shutil
import tempfile
import warnings
import zipfile
from html import escape
from pathlib import Path
from typing import Any

import geopandas as gpd
import shapely
from pyproj import Geod
from shapely.geometry import LineString, MultiLineString, MultiPolygon, Point, Polygon
from shapely.geometry.base import BaseGeometry

GEOD = Geod(ellps="WGS84")
FIXED_ZIP_TIME = (2020, 1, 1, 0, 0, 0)


def square(lon: float, lat: float, size: float) -> Polygon:
    return Polygon(
        [(lon, lat), (lon + size, lat), (lon + size, lat + size), (lon, lat + size), (lon, lat)]
    )


def polygon_features() -> list[dict[str, Any]]:
    plot_hole = Polygon(
        [(78.10, 10.90), (78.12, 10.90), (78.12, 10.92), (78.10, 10.92), (78.10, 10.90)],
        holes=[
            [
                (78.105, 10.905),
                (78.115, 10.905),
                (78.115, 10.915),
                (78.105, 10.915),
                (78.105, 10.905),
            ]
        ],
    )
    bowtie = Polygon(
        [(78.20, 10.90), (78.21, 10.91), (78.21, 10.90), (78.20, 10.91), (78.20, 10.90)]
    )
    return [
        {"name": "Plot A", "owner": "Karur Survey Dept", "geometry": square(78.05, 10.90, 0.01)},
        {"name": "Plot B (with hole)", "owner": "Karur Survey Dept", "geometry": plot_hole},
        {
            "name": "Twin Plots",
            "owner": "Municipality",
            "geometry": MultiPolygon([square(78.30, 10.90, 0.01), square(78.32, 10.90, 0.01)]),
        },
        {"name": "Bowtie (repairable)", "owner": "Test", "geometry": bowtie},
    ]


def line_features() -> list[dict[str, Any]]:
    return [
        {
            "name": "Canal",
            "owner": "Irrigation Dept",
            "geometry": LineString([(78.00, 10.90), (78.02, 10.91), (78.04, 10.90)]),
        },
        {
            "name": "Road network",
            "owner": "Highways",
            "geometry": MultiLineString(
                [[(78.00, 10.95), (78.01, 10.95)], [(78.00, 10.96), (78.00, 10.97)]]
            ),
        },
    ]


def point_features() -> list[dict[str, Any]]:
    return [
        {"name": "Survey Marker", "owner": "Karur Survey Dept", "geometry": Point(78.0766, 10.9601)}
    ]


def kml_features() -> list[dict[str, Any]]:
    return point_features() + line_features()[:1] + polygon_features() + line_features()[1:]


# ----------------------------------------------------------------------- expectations
def geodesic_area_m2(geom: BaseGeometry) -> float:
    valid = shapely.make_valid(geom) if not shapely.is_valid(geom) else geom
    total = 0.0
    for part in shapely.get_parts(valid):
        if part.geom_type == "Polygon":
            # Geod does not orient/subtract interior rings itself: do it explicitly.
            exterior = abs(GEOD.geometry_area_perimeter(Polygon(part.exterior))[0])
            holes = sum(abs(GEOD.geometry_area_perimeter(Polygon(r))[0]) for r in part.interiors)
            total += exterior - holes
    return total


def geodesic_length_m(geom: BaseGeometry) -> float:
    return float(GEOD.geometry_length(geom))


def expectation(feature: dict[str, Any]) -> dict[str, Any]:
    geom: BaseGeometry = feature["geometry"]
    source_type = geom.geom_type
    if not shapely.is_valid(geom):  # the API reports the post-repair type (bow-tie -> MultiPolygon)
        parts = [p for p in shapely.get_parts(shapely.make_valid(geom)) if p.geom_type == "Polygon"]
        geom = parts[0] if len(parts) == 1 else MultiPolygon(parts)
    entry: dict[str, Any] = {
        "name": feature["name"],
        "geometry_type": geom.geom_type,
        "source_geometry_type": source_type,
    }
    if geom.geom_type in {"Polygon", "MultiPolygon"}:
        entry["expected_area_m2"] = geodesic_area_m2(feature["geometry"])
    elif geom.geom_type in {"LineString", "MultiLineString"}:
        entry["expected_length_m"] = geodesic_length_m(geom)
    entry["was_repaired"] = not shapely.is_valid(feature["geometry"])
    return entry


# ------------------------------------------------------------------------- KML writer
def _coords(line: LineString | shapely.LinearRing) -> str:
    return " ".join(f"{x:.6f},{y:.6f},0" for x, y in line.coords)


def _polygon_kml(poly: Polygon) -> str:
    inner = "".join(
        f"<innerBoundaryIs><LinearRing><coordinates>{_coords(r)}</coordinates></LinearRing></innerBoundaryIs>"
        for r in poly.interiors
    )
    return (
        "<Polygon><outerBoundaryIs><LinearRing><coordinates>"
        f"{_coords(poly.exterior)}</coordinates></LinearRing></outerBoundaryIs>{inner}</Polygon>"
    )


def _geometry_kml(geom: BaseGeometry) -> str:
    if isinstance(geom, Point):
        return f"<Point><coordinates>{geom.x:.6f},{geom.y:.6f},0</coordinates></Point>"
    if isinstance(geom, LineString):
        return f"<LineString><coordinates>{_coords(geom)}</coordinates></LineString>"
    if isinstance(geom, Polygon):
        return _polygon_kml(geom)
    return "<MultiGeometry>" + "".join(_geometry_kml(g) for g in geom.geoms) + "</MultiGeometry>"  # type: ignore[attr-defined]


def write_kml(path: Path, features: list[dict[str, Any]]) -> None:
    placemarks = "".join(
        "<Placemark>"
        f"<name>{escape(f['name'])}</name>"
        f'<ExtendedData><Data name="owner"><value>{escape(f["owner"])}</value></Data></ExtendedData>'
        f"{_geometry_kml(f['geometry'])}</Placemark>"
        for f in features
    )
    path.write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>GeoMeasure sample</name>'
        f"{placemarks}</Document></kml>\n",
        encoding="utf-8",
    )


# ------------------------------------------------------------------ Shapefile writer
def write_shapefile_zip(
    path: Path,
    features: list[dict[str, Any]],
    *,
    crs: str | None = "EPSG:4326",
    stem: str = "dataset",
) -> None:
    with tempfile.TemporaryDirectory() as tmp:
        shp = Path(tmp) / f"{stem}.shp"
        frame = gpd.GeoDataFrame(
            {"name": [f["name"] for f in features], "owner": [f["owner"] for f in features]},
            geometry=[f["geometry"] for f in features],
            crs=crs,
        )
        with warnings.catch_warnings():
            warnings.simplefilter(
                "ignore"
            )  # "crs was not provided" is intentional for the no-.prj sample
            frame.to_file(shp, driver="ESRI Shapefile", encoding="UTF-8")
        if crs is None:
            shp.with_suffix(".prj").unlink(missing_ok=True)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
            for member in sorted(Path(tmp).iterdir()):
                info = zipfile.ZipInfo(member.name, FIXED_ZIP_TIME)
                info.compress_type = zipfile.ZIP_DEFLATED
                zf.writestr(info, member.read_bytes())


def generate_all(out_dir: Path) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    write_kml(out_dir / "sample.kml", kml_features())
    write_shapefile_zip(out_dir / "sample_shapefile.zip", polygon_features())
    write_shapefile_zip(out_dir / "sample_shapefile_lines.zip", line_features())
    write_shapefile_zip(out_dir / "sample_shapefile_points.zip", point_features())
    write_shapefile_zip(out_dir / "sample_shapefile_no_prj.zip", polygon_features()[:1], crs=None)
    expected = {
        "sample.kml": [expectation(f) for f in kml_features()],
        "sample_shapefile.zip": [expectation(f) for f in polygon_features()],
        "sample_shapefile_lines.zip": [expectation(f) for f in line_features()],
        "sample_shapefile_points.zip": [expectation(f) for f in point_features()],
    }
    (out_dir / "expected.json").write_text(json.dumps(expected, indent=2) + "\n", encoding="utf-8")
    return expected


def clean(out_dir: Path) -> None:
    if out_dir.exists():
        shutil.rmtree(out_dir)
